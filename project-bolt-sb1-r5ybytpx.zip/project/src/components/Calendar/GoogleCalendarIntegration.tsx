import React, { useState } from 'react';
import { Calendar, Clock, MapPin, User, Phone, AlertCircle, CheckCircle, Plus, ExternalLink } from 'lucide-react';

interface CalendarEvent {
  id: string;
  title: string;
  type: 'pericia_medica_judicial' | 'pericia_medica_administrativa' | 'avaliacao_social';
  clientName: string;
  clientPhone: string;
  date: string;
  time: string;
  location: string;
  doctor?: string;
  notes?: string;
  status: 'agendado' | 'confirmado' | 'realizado' | 'cancelado';
  googleEventId?: string;
}

interface GoogleCalendarIntegrationProps {
  onEventCreate?: (event: CalendarEvent) => void;
}

const GoogleCalendarIntegration: React.FC<GoogleCalendarIntegrationProps> = ({ onEventCreate }) => {
  const [isConnected, setIsConnected] = useState(true); // Simulating connection status
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [events, setEvents] = useState<CalendarEvent[]>([
    {
      id: '1',
      title: 'Perícia Médica - João Silva',
      type: 'pericia_medica_judicial',
      clientName: 'João Silva',
      clientPhone: '(11) 99999-1111',
      date: '2024-03-05',
      time: '14:00',
      location: 'IMESC - Rua Brigadeiro Tobias, 527 - São Paulo/SP',
      doctor: 'Dr. Roberto Santos',
      status: 'agendado',
      notes: 'Cliente deve levar todos os exames médicos recentes',
      googleEventId: 'google_event_123'
    },
    {
      id: '2',
      title: 'Avaliação Social - Maria Costa',
      type: 'avaliacao_social',
      clientName: 'Maria Costa',
      clientPhone: '(11) 99999-2222',
      date: '2024-03-08',
      time: '09:30',
      location: 'Residência do cliente - Rua das Flores, 123 - São Paulo/SP',
      status: 'confirmado',
      notes: 'Cliente deve estar presente no domicílio. Verificar documentos de renda familiar.',
      googleEventId: 'google_event_124'
    },
    {
      id: '3',
      title: 'Perícia Médica - Ana Pereira',
      type: 'pericia_medica_administrativa',
      clientName: 'Ana Pereira',
      clientPhone: '(11) 99999-3333',
      date: '2024-03-12',
      time: '10:15',
      location: 'APS INSS - Av. Paulista, 1000 - São Paulo/SP',
      doctor: 'Dr. Carlos Lima',
      status: 'agendado',
      notes: 'Perícia para auxílio doença - levar atestados médicos',
      googleEventId: 'google_event_125'
    }
  ]);

  const [newEvent, setNewEvent] = useState<Partial<CalendarEvent>>({
    type: 'pericia_medica_judicial',
    status: 'agendado'
  });

  const eventTypeLabels = {
    pericia_medica_judicial: 'Perícia Médica Judicial',
    pericia_medica_administrativa: 'Perícia Médica Administrativa',
    avaliacao_social: 'Avaliação Social'
  };

  const eventTypeColors = {
    pericia_medica_judicial: 'bg-blue-100 text-blue-800 border-blue-200',
    pericia_medica_administrativa: 'bg-green-100 text-green-800 border-green-200',
    avaliacao_social: 'bg-purple-100 text-purple-800 border-purple-200'
  };

  const statusColors = {
    agendado: 'bg-yellow-100 text-yellow-800',
    confirmado: 'bg-blue-100 text-blue-800',
    realizado: 'bg-green-100 text-green-800',
    cancelado: 'bg-red-100 text-red-800'
  };

  const handleConnectGoogle = () => {
    // Simulate Google Calendar connection
    setIsConnected(true);
    alert('Conectado ao Google Agenda com sucesso!');
  };

  const handleCreateEvent = () => {
    if (newEvent.title && newEvent.clientName && newEvent.date && newEvent.time) {
      const event: CalendarEvent = {
        id: Date.now().toString(),
        title: newEvent.title!,
        type: newEvent.type as CalendarEvent['type'],
        clientName: newEvent.clientName!,
        clientPhone: newEvent.clientPhone || '',
        date: newEvent.date!,
        time: newEvent.time!,
        location: newEvent.location || '',
        doctor: newEvent.doctor,
        notes: newEvent.notes,
        status: 'agendado',
        googleEventId: `google_event_${Date.now()}`
      };

      setEvents([...events, event]);
      onEventCreate?.(event);
      setNewEvent({ type: 'pericia_medica_judicial', status: 'agendado' });
      setShowCreateForm(false);
      alert('Evento criado e sincronizado com Google Agenda!');
    }
  };

  const handleStatusChange = (eventId: string, newStatus: CalendarEvent['status']) => {
    setEvents(events.map(event => 
      event.id === eventId ? { ...event, status: newStatus } : event
    ));
  };

  const getUpcomingEvents = () => {
    const today = new Date();
    return events.filter(event => {
      const eventDate = new Date(event.date);
      return eventDate >= today && event.status !== 'cancelado';
    }).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  };

  const upcomingEvents = getUpcomingEvents();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Calendar className="text-blue-600" size={24} />
          <h3 className="text-lg font-semibold text-gray-900">Google Agenda - Perícias e Avaliações</h3>
        </div>
        <div className="flex items-center space-x-3">
          {isConnected ? (
            <div className="flex items-center space-x-2 px-3 py-1 bg-green-100 text-green-800 rounded-full">
              <CheckCircle size={16} />
              <span className="text-sm font-medium">Conectado</span>
            </div>
          ) : (
            <button
              onClick={handleConnectGoogle}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <Calendar size={16} />
              <span>Conectar Google Agenda</span>
            </button>
          )}
          <button
            onClick={() => setShowCreateForm(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
          >
            <Plus size={16} />
            <span>Novo Agendamento</span>
          </button>
        </div>
      </div>

      {/* Connection Status */}
      {isConnected && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <CheckCircle className="text-green-600" size={20} />
            <div>
              <h4 className="text-sm font-medium text-green-800">
                ✅ Integração Ativa com Google Agenda
              </h4>
              <p className="text-sm text-green-700 mt-1">
                Todos os agendamentos são automaticamente sincronizados com sua agenda do Google. 
                Notificações e lembretes serão enviados conforme configurado.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Create Event Form */}
      {showCreateForm && (
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-md font-medium text-gray-900">Novo Agendamento</h4>
            <button
              onClick={() => setShowCreateForm(false)}
              className="text-gray-400 hover:text-gray-600"
            >
              ✕
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Tipo de Agendamento</label>
              <select
                value={newEvent.type}
                onChange={(e) => setNewEvent({ ...newEvent, type: e.target.value as CalendarEvent['type'] })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                <option value="pericia_medica_judicial">Perícia Médica Judicial</option>
                <option value="pericia_medica_administrativa">Perícia Médica Administrativa</option>
                <option value="avaliacao_social">Avaliação Social</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Título do Evento</label>
              <input
                type="text"
                value={newEvent.title || ''}
                onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                placeholder="Ex: Perícia Médica - João Silva"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nome do Cliente</label>
              <input
                type="text"
                value={newEvent.clientName || ''}
                onChange={(e) => setNewEvent({ ...newEvent, clientName: e.target.value })}
                placeholder="Nome completo do cliente"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Telefone do Cliente</label>
              <input
                type="tel"
                value={newEvent.clientPhone || ''}
                onChange={(e) => setNewEvent({ ...newEvent, clientPhone: e.target.value })}
                placeholder="(11) 99999-9999"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Data</label>
              <input
                type="date"
                value={newEvent.date || ''}
                onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Horário</label>
              <input
                type="time"
                value={newEvent.time || ''}
                onChange={(e) => setNewEvent({ ...newEvent, time: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Local</label>
              <input
                type="text"
                value={newEvent.location || ''}
                onChange={(e) => setNewEvent({ ...newEvent, location: e.target.value })}
                placeholder="Endereço completo do local"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {(newEvent.type === 'pericia_medica_judicial' || newEvent.type === 'pericia_medica_administrativa') && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Médico Perito</label>
                <input
                  type="text"
                  value={newEvent.doctor || ''}
                  onChange={(e) => setNewEvent({ ...newEvent, doctor: e.target.value })}
                  placeholder="Nome do médico perito"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>
            )}

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Observações</label>
              <textarea
                value={newEvent.notes || ''}
                onChange={(e) => setNewEvent({ ...newEvent, notes: e.target.value })}
                placeholder="Instruções especiais, documentos necessários, etc."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-3 mt-6">
            <button
              onClick={() => setShowCreateForm(false)}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              Cancelar
            </button>
            <button
              onClick={handleCreateEvent}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
            >
              Criar e Sincronizar
            </button>
          </div>
        </div>
      )}

      {/* Upcoming Events */}
      <div className="space-y-4">
        <h4 className="text-md font-medium text-gray-900">
          Próximos Agendamentos ({upcomingEvents.length})
        </h4>

        {upcomingEvents.length === 0 ? (
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-8 text-center">
            <Calendar className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <p className="text-gray-600">Nenhum agendamento próximo</p>
          </div>
        ) : (
          <div className="space-y-4">
            {upcomingEvents.map((event) => (
              <div key={event.id} className={`border rounded-lg p-4 ${eventTypeColors[event.type]}`}>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h5 className="font-medium text-gray-900">{event.title}</h5>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[event.status]}`}>
                        {event.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <User size={14} className="text-gray-500" />
                          <span className="text-gray-700">{event.clientName}</span>
                        </div>
                        {event.clientPhone && (
                          <div className="flex items-center space-x-2">
                            <Phone size={14} className="text-gray-500" />
                            <span className="text-gray-700">{event.clientPhone}</span>
                          </div>
                        )}
                        <div className="flex items-center space-x-2">
                          <Calendar size={14} className="text-gray-500" />
                          <span className="text-gray-700">
                            {new Date(event.date).toLocaleDateString('pt-BR')} às {event.time}
                          </span>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <MapPin size={14} className="text-gray-500" />
                          <span className="text-gray-700">{event.location}</span>
                        </div>
                        {event.doctor && (
                          <div className="flex items-center space-x-2">
                            <User size={14} className="text-gray-500" />
                            <span className="text-gray-700">Perito: {event.doctor}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {event.notes && (
                      <div className="mt-3 p-3 bg-white bg-opacity-50 rounded-md">
                        <div className="flex items-start space-x-2">
                          <AlertCircle size={14} className="text-gray-500 mt-0.5" />
                          <p className="text-sm text-gray-700">{event.notes}</p>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex flex-col space-y-2 ml-4">
                    <button
                      onClick={() => window.open(`https://calendar.google.com/calendar/event?eid=${event.googleEventId}`, '_blank')}
                      className="flex items-center space-x-1 text-blue-600 hover:text-blue-800 text-sm"
                      title="Abrir no Google Agenda"
                    >
                      <ExternalLink size={14} />
                      <span>Ver na Agenda</span>
                    </button>

                    {event.status === 'agendado' && (
                      <button
                        onClick={() => handleStatusChange(event.id, 'confirmado')}
                        className="text-green-600 hover:text-green-800 text-sm"
                      >
                        Confirmar
                      </button>
                    )}

                    {event.status === 'confirmado' && (
                      <button
                        onClick={() => handleStatusChange(event.id, 'realizado')}
                        className="text-blue-600 hover:text-blue-800 text-sm"
                      >
                        Marcar Realizado
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h4 className="text-md font-medium text-gray-900 mb-4">Ações Rápidas</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="flex items-center justify-center space-x-2 px-4 py-3 border border-blue-300 text-blue-700 rounded-lg hover:bg-blue-50">
            <Calendar size={20} />
            <span>Sincronizar Agenda</span>
          </button>
          <button className="flex items-center justify-center space-x-2 px-4 py-3 border border-green-300 text-green-700 rounded-lg hover:bg-green-50">
            <Clock size={20} />
            <span>Configurar Lembretes</span>
          </button>
          <button className="flex items-center justify-center space-x-2 px-4 py-3 border border-purple-300 text-purple-700 rounded-lg hover:bg-purple-50">
            <ExternalLink size={20} />
            <span>Abrir Google Agenda</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default GoogleCalendarIntegration;