import React, { useState } from 'react';
import { BarChart3, TrendingUp, Users, Target, Eye, ExternalLink, RefreshCw, Calendar, Filter } from 'lucide-react';
import MetricCard from '../Charts/MetricCard';
import BarChart from '../Charts/BarChart';
import PieChart from '../Charts/PieChart';

interface MetaAdsCampaign {
  id: string;
  name: string;
  status: 'active' | 'paused' | 'completed';
  budget: number;
  spent: number;
  impressions: number;
  clicks: number;
  leads: number;
  ctr: number;
  cpc: number;
  cpl: number;
  startDate: string;
  endDate?: string;
  objective: string;
  platform: 'facebook' | 'instagram' | 'both';
}

interface MetaAdsIntegrationProps {
  onLeadImport?: (leads: any[]) => void;
}

const MetaAdsIntegration: React.FC<MetaAdsIntegrationProps> = ({ onLeadImport }) => {
  const [isConnected, setIsConnected] = useState(true); // Simulating connection
  const [selectedPeriod, setSelectedPeriod] = useState('last_30_days');
  const [selectedCampaign, setSelectedCampaign] = useState('all');
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Mock data for Meta Ads campaigns
  const campaigns: MetaAdsCampaign[] = [
    {
      id: '1',
      name: 'INSS 2024 - Aposentadoria',
      status: 'active',
      budget: 5000,
      spent: 3250,
      impressions: 125000,
      clicks: 2100,
      leads: 85,
      ctr: 1.68,
      cpc: 1.55,
      cpl: 38.24,
      startDate: '2024-03-01',
      objective: 'Lead Generation',
      platform: 'both'
    },
    {
      id: '2',
      name: 'BPC LOAS - Idosos',
      status: 'active',
      budget: 3000,
      spent: 2100,
      impressions: 89000,
      clicks: 1450,
      leads: 62,
      ctr: 1.63,
      cpc: 1.45,
      cpl: 33.87,
      startDate: '2024-03-05',
      objective: 'Lead Generation',
      platform: 'facebook'
    },
    {
      id: '3',
      name: 'Auxílio Doença - Trabalhadores',
      status: 'active',
      budget: 4000,
      spent: 2800,
      impressions: 98000,
      clicks: 1680,
      leads: 71,
      ctr: 1.71,
      cpc: 1.67,
      cpl: 39.44,
      startDate: '2024-02-28',
      objective: 'Lead Generation',
      platform: 'instagram'
    },
    {
      id: '4',
      name: 'Trabalhista - Rescisão',
      status: 'paused',
      budget: 2500,
      spent: 1850,
      impressions: 67000,
      clicks: 980,
      leads: 28,
      ctr: 1.46,
      cpc: 1.89,
      cpl: 66.07,
      startDate: '2024-02-15',
      endDate: '2024-03-15',
      objective: 'Lead Generation',
      platform: 'both'
    },
    {
      id: '5',
      name: 'Revisão Aposentadoria',
      status: 'active',
      budget: 3500,
      spent: 2450,
      impressions: 78000,
      clicks: 1320,
      leads: 54,
      ctr: 1.69,
      cpc: 1.86,
      cpl: 45.37,
      startDate: '2024-03-10',
      objective: 'Lead Generation',
      platform: 'facebook'
    }
  ];

  // Calculate totals
  const totalBudget = campaigns.reduce((sum, c) => sum + c.budget, 0);
  const totalSpent = campaigns.reduce((sum, c) => sum + c.spent, 0);
  const totalLeads = campaigns.reduce((sum, c) => sum + c.leads, 0);
  const totalClicks = campaigns.reduce((sum, c) => sum + c.clicks, 0);
  const totalImpressions = campaigns.reduce((sum, c) => sum + c.impressions, 0);
  const avgCTR = totalImpressions > 0 ? (totalClicks / totalImpressions) * 100 : 0;
  const avgCPL = totalLeads > 0 ? totalSpent / totalLeads : 0;

  // Chart data
  const campaignPerformanceData = campaigns.map(campaign => ({
    label: campaign.name.split(' - ')[0],
    value: campaign.leads,
    color: 'bg-blue-500'
  }));

  const platformDistributionData = [
    { 
      label: 'Facebook', 
      value: campaigns.filter(c => c.platform === 'facebook' || c.platform === 'both').reduce((sum, c) => sum + c.leads, 0),
      color: '#1877F2'
    },
    { 
      label: 'Instagram', 
      value: campaigns.filter(c => c.platform === 'instagram' || c.platform === 'both').reduce((sum, c) => sum + c.leads, 0),
      color: '#E4405F'
    }
  ];

  const dailyLeadsData = [
    { label: 'Seg', value: 12 },
    { label: 'Ter', value: 15 },
    { label: 'Qua', value: 18 },
    { label: 'Qui', value: 14 },
    { label: 'Sex', value: 22 },
    { label: 'Sáb', value: 8 },
    { label: 'Dom', value: 6 }
  ];

  const handleConnect = () => {
    setIsConnected(true);
    alert('Conectado ao Meta Ads com sucesso!');
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsRefreshing(false);
    alert('Dados atualizados com sucesso!');
  };

  const handleImportLeads = () => {
    // Simulate importing leads from Meta Ads
    const mockLeads = campaigns.flatMap(campaign => 
      Array.from({ length: Math.floor(campaign.leads / 10) }, (_, i) => ({
        nome: `Lead ${campaign.id}-${i + 1}`,
        email: `lead${campaign.id}${i + 1}@email.com`,
        telefone: `(11) 9999-${String(Math.floor(Math.random() * 10000)).padStart(4, '0')}`,
        tipoProcesso: campaign.name.includes('INSS') ? 'Aposentadoria por Invalidez' :
                     campaign.name.includes('BPC') ? 'BPC/LOAS' :
                     campaign.name.includes('Auxílio') ? 'Auxílio Doença' :
                     campaign.name.includes('Trabalhista') ? 'Trabalhista - Rescisão' :
                     'Revisão de Benefício',
        status: 'novo',
        origem: 'Meta Ads',
        campanha: campaign.name,
        observacoes: `Lead importado automaticamente da campanha ${campaign.name}`
      }))
    );

    onLeadImport?.(mockLeads);
    alert(`${mockLeads.length} leads importados com sucesso!`);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'paused': return 'bg-yellow-100 text-yellow-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active': return 'Ativa';
      case 'paused': return 'Pausada';
      case 'completed': return 'Concluída';
      default: return status;
    }
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case 'facebook': return '📘';
      case 'instagram': return '📷';
      case 'both': return '📘📷';
      default: return '📱';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-100 rounded-lg">
            <BarChart3 className="text-blue-600" size={20} />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Meta Ads - Análise de Campanhas</h3>
            <p className="text-sm text-gray-600">Integração com Facebook e Instagram Ads</p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          {isConnected ? (
            <div className="flex items-center space-x-2 px-3 py-1 bg-green-100 text-green-800 rounded-full">
              <div className="w-2 h-2 bg-green-600 rounded-full"></div>
              <span className="text-sm font-medium">Conectado</span>
            </div>
          ) : (
            <button
              onClick={handleConnect}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <ExternalLink size={16} />
              <span>Conectar Meta Ads</span>
            </button>
          )}
          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="flex items-center space-x-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 disabled:opacity-50"
          >
            <RefreshCw size={16} className={isRefreshing ? 'animate-spin' : ''} />
            <span>{isRefreshing ? 'Atualizando...' : 'Atualizar'}</span>
          </button>
        </div>
      </div>

      {/* Connection Status */}
      {isConnected && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Target className="text-blue-600" size={20} />
              </div>
              <div>
                <h4 className="text-sm font-medium text-blue-800">
                  ✅ Integração Ativa com Meta Business
                </h4>
                <p className="text-sm text-blue-700 mt-1">
                  Dados sincronizados automaticamente. Última atualização: {new Date().toLocaleString('pt-BR')}
                </p>
              </div>
            </div>
            <button
              onClick={handleImportLeads}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <Users size={16} />
              <span>Importar Leads</span>
            </button>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white border border-gray-200 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <h4 className="text-md font-medium text-gray-900">Filtros de Análise</h4>
          <div className="flex items-center space-x-3">
            <select
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="last_7_days">Últimos 7 dias</option>
              <option value="last_30_days">Últimos 30 dias</option>
              <option value="last_90_days">Últimos 90 dias</option>
              <option value="this_month">Este mês</option>
              <option value="last_month">Mês passado</option>
            </select>
            <select
              value={selectedCampaign}
              onChange={(e) => setSelectedCampaign(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">Todas as campanhas</option>
              {campaigns.map(campaign => (
                <option key={campaign.id} value={campaign.id}>{campaign.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <MetricCard
          title="Total de Leads"
          value={totalLeads}
          icon={Users}
          trend={{ value: 12.5, isPositive: true }}
          color="blue"
        />
        <MetricCard
          title="Investimento Total"
          value={`R$ ${totalSpent.toLocaleString('pt-BR')}`}
          icon={Target}
          color="green"
        />
        <MetricCard
          title="CTR Médio"
          value={`${avgCTR.toFixed(2)}%`}
          icon={Eye}
          trend={{ value: 0.3, isPositive: true }}
          color="purple"
        />
        <MetricCard
          title="Custo por Lead"
          value={`R$ ${avgCPL.toFixed(2)}`}
          icon={TrendingUp}
          trend={{ value: -5.2, isPositive: true }}
          color="yellow"
        />
      </div>

      {/* Campaign Performance Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <BarChart
          title="Leads por Campanha"
          data={campaignPerformanceData}
        />
        <BarChart
          title="Leads por Dia da Semana"
          data={dailyLeadsData}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <PieChart
          title="Distribuição por Plataforma"
          data={platformDistributionData}
        />
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Resumo de Performance</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
              <span className="font-medium text-gray-900">Orçamento Total</span>
              <span className="text-lg font-bold text-blue-600">R$ {totalBudget.toLocaleString('pt-BR')}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
              <span className="font-medium text-gray-900">Valor Gasto</span>
              <span className="text-lg font-bold text-green-600">R$ {totalSpent.toLocaleString('pt-BR')}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
              <span className="font-medium text-gray-900">Taxa de Utilização</span>
              <span className="text-lg font-bold text-purple-600">
                {((totalSpent / totalBudget) * 100).toFixed(1)}%
              </span>
            </div>
            <div className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
              <span className="font-medium text-gray-900">ROI Estimado</span>
              <span className="text-lg font-bold text-yellow-600">
                {totalLeads > 0 ? `${((totalLeads * 3000 - totalSpent) / totalSpent * 100).toFixed(1)}%` : '0%'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Campaign Details Table */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Detalhes das Campanhas</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Campanha
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Plataforma
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Leads
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Gasto
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  CPL
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  CTR
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {campaigns.map((campaign) => (
                <tr key={campaign.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{campaign.name}</div>
                      <div className="text-sm text-gray-500">{campaign.objective}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(campaign.status)}`}>
                      {getStatusLabel(campaign.status)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <span className="flex items-center space-x-1">
                      <span>{getPlatformIcon(campaign.platform)}</span>
                      <span className="capitalize">{campaign.platform === 'both' ? 'Ambas' : campaign.platform}</span>
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {campaign.leads}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    R$ {campaign.spent.toLocaleString('pt-BR')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    R$ {campaign.cpl.toFixed(2)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {campaign.ctr.toFixed(2)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Ações Rápidas</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button 
            onClick={handleImportLeads}
            className="flex items-center justify-center space-x-2 px-4 py-3 border border-blue-300 text-blue-700 rounded-lg hover:bg-blue-50"
          >
            <Users size={20} />
            <span>Importar Todos os Leads</span>
          </button>
          <button className="flex items-center justify-center space-x-2 px-4 py-3 border border-green-300 text-green-700 rounded-lg hover:bg-green-50">
            <BarChart3 size={20} />
            <span>Relatório Detalhado</span>
          </button>
          <button className="flex items-center justify-center space-x-2 px-4 py-3 border border-purple-300 text-purple-700 rounded-lg hover:bg-purple-50">
            <ExternalLink size={20} />
            <span>Abrir Meta Business</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default MetaAdsIntegration;