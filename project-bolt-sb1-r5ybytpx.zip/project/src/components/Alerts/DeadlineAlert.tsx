import React from 'react';
import { AlertTriangle, Clock, Calendar, User, Home, ExternalLink } from 'lucide-react';
import { ProcessDeadline } from '../../types';

interface DeadlineAlertProps {
  deadline: ProcessDeadline;
  clientName: string;
  onMarkComplete?: (deadlineId: string) => void;
  onScheduleAppointment?: (deadline: ProcessDeadline) => void;
}

const DeadlineAlert: React.FC<DeadlineAlertProps> = ({ 
  deadline, 
  clientName, 
  onMarkComplete,
  onScheduleAppointment 
}) => {
  const getDaysUntilDue = () => {
    const today = new Date();
    const dueDate = new Date(deadline.dueDate);
    const diffTime = dueDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const daysUntilDue = getDaysUntilDue();
  const isOverdue = daysUntilDue < 0;
  const isUrgent = daysUntilDue <= 3 && daysUntilDue >= 0;

  const getPriorityColor = () => {
    if (isOverdue) return 'bg-red-50 border-red-200';
    if (isUrgent || deadline.priority === 'critica') return 'bg-orange-50 border-orange-200';
    if (deadline.priority === 'alta') return 'bg-yellow-50 border-yellow-200';
    return 'bg-blue-50 border-blue-200';
  };

  const getPriorityIcon = () => {
    if (deadline.type === 'avaliacao_social') return Home;
    if (isOverdue || deadline.priority === 'critica') return AlertTriangle;
    return Clock;
  };

  const getStatusText = () => {
    if (isOverdue) return `Vencido há ${Math.abs(daysUntilDue)} dia(s)`;
    if (daysUntilDue === 0) return 'Vence hoje';
    if (daysUntilDue === 1) return 'Vence amanhã';
    return `${daysUntilDue} dias restantes`;
  };

  const getTypeLabel = () => {
    const types = {
      recurso: 'Recurso',
      exigencia: 'Exigência',
      complementacao: 'Complementação',
      resposta: 'Resposta',
      pericia: 'Perícia',
      audiencia: 'Audiência',
      avaliacao_social: 'Avaliação Social'
    };
    return types[deadline.type];
  };

  const getTypeColor = () => {
    if (deadline.type === 'avaliacao_social') {
      return isOverdue ? 'text-red-600' : 'text-purple-600';
    }
    return isOverdue ? 'text-red-600' : 
           isUrgent || deadline.priority === 'critica' ? 'text-orange-600' : 
           deadline.priority === 'alta' ? 'text-yellow-600' : 'text-blue-600';
  };

  const requiresScheduling = () => {
    return deadline.type === 'pericia' || deadline.type === 'avaliacao_social';
  };

  const Icon = getPriorityIcon();

  return (
    <div className={`rounded-lg border p-4 ${getPriorityColor()}`}>
      <div className="flex items-start space-x-3">
        <Icon 
          className={`mt-1 ${getTypeColor()}`} 
          size={20} 
        />
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-sm font-medium text-gray-900">
              {getTypeLabel()} - {clientName}
            </h4>
            <span className={`text-xs font-medium px-2 py-1 rounded-full ${
              isOverdue ? 'bg-red-100 text-red-800' :
              isUrgent || deadline.priority === 'critica' ? 'bg-orange-100 text-orange-800' :
              deadline.priority === 'alta' ? 'bg-yellow-100 text-yellow-800' :
              deadline.type === 'avaliacao_social' ? 'bg-purple-100 text-purple-800' :
              'bg-blue-100 text-blue-800'
            }`}>
              {getStatusText()}
            </span>
          </div>
          
          <p className="text-sm text-gray-700 mb-3">
            {deadline.description}
          </p>

          {deadline.notes && (
            <div className="bg-gray-50 rounded-md p-2 mb-3">
              <p className="text-xs text-gray-600">
                <strong>Observações:</strong> {deadline.notes}
              </p>
            </div>
          )}

          {deadline.type === 'avaliacao_social' && (
            <div className="bg-purple-50 rounded-md p-2 mb-3">
              <p className="text-xs text-purple-700">
                <strong>⚠️ Avaliação Social BPC/LOAS:</strong> Cliente deve estar presente no domicílio. 
                Verificar toda documentação de renda familiar e condições de moradia.
              </p>
            </div>
          )}

          {deadline.type === 'pericia' && (
            <div className="bg-blue-50 rounded-md p-2 mb-3">
              <p className="text-xs text-blue-700">
                <strong>🏥 Perícia Médica:</strong> Cliente deve levar todos os exames médicos recentes, 
                laudos e documentos pessoais. Chegar com 30 minutos de antecedência.
              </p>
            </div>
          )}
          
          <div className="flex items-center justify-between text-xs text-gray-500">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                <Calendar size={12} />
                <span>Vencimento: {new Date(deadline.dueDate).toLocaleDateString('pt-BR')}</span>
              </div>
              <div className="flex items-center space-x-1">
                <User size={12} />
                <span>{deadline.responsibleLawyer}</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              {requiresScheduling() && onScheduleAppointment && (
                <button
                  onClick={() => onScheduleAppointment(deadline)}
                  className="flex items-center space-x-1 text-blue-600 hover:text-blue-800 font-medium"
                >
                  <Calendar size={12} />
                  <span>Agendar</span>
                </button>
              )}
              
              {deadline.status === 'pendente' && onMarkComplete && (
                <button
                  onClick={() => onMarkComplete(deadline.id)}
                  className="text-green-600 hover:text-green-800 font-medium"
                >
                  Marcar como concluído
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeadlineAlert;