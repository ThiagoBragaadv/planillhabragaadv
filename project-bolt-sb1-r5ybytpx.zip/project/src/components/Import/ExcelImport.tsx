import React, { useState, useRef } from 'react';
import { Upload, Download, FileSpreadsheet, AlertCircle, CheckCircle, X } from 'lucide-react';
import * as XLSX from 'xlsx';

interface ImportedClient {
  nome: string;
  email: string;
  telefone: string;
  tipoProcesso: string;
  status: string;
  valorContrato?: number;
  dataContrato?: string;
  origem?: string;
  observacoes?: string;
}

interface ExcelImportProps {
  onImport: (clients: ImportedClient[]) => void;
  onClose: () => void;
}

const ExcelImport: React.FC<ExcelImportProps> = ({ onImport, onClose }) => {
  const [dragActive, setDragActive] = useState(false);
  const [importedData, setImportedData] = useState<ImportedClient[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const requiredColumns = [
    'nome',
    'email', 
    'telefone',
    'tipoProcesso',
    'status'
  ];

  const optionalColumns = [
    'valorContrato',
    'dataContrato',
    'origem',
    'observacoes'
  ];

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = async (file: File) => {
    setIsProcessing(true);
    setErrors([]);
    setImportedData([]);

    try {
      // Validate file type
      if (!file.name.match(/\.(xlsx|xls)$/)) {
        throw new Error('Por favor, selecione um arquivo Excel (.xlsx ou .xls)');
      }

      // Read file
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      
      // Convert to JSON
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
      
      if (jsonData.length < 2) {
        throw new Error('O arquivo deve conter pelo menos uma linha de cabeçalho e uma linha de dados');
      }

      // Get headers (first row)
      const headers = (jsonData[0] as string[]).map(h => h?.toLowerCase().trim());
      
      // Validate required columns
      const missingColumns = requiredColumns.filter(col => !headers.includes(col));
      if (missingColumns.length > 0) {
        throw new Error(`Colunas obrigatórias ausentes: ${missingColumns.join(', ')}`);
      }

      // Process data rows
      const processedData: ImportedClient[] = [];
      const validationErrors: string[] = [];

      for (let i = 1; i < jsonData.length; i++) {
        const row = jsonData[i] as any[];
        if (!row || row.every(cell => !cell)) continue; // Skip empty rows

        const client: any = {};
        
        headers.forEach((header, index) => {
          if (header && row[index] !== undefined) {
            client[header] = row[index];
          }
        });

        // Validate required fields
        const rowErrors: string[] = [];
        requiredColumns.forEach(col => {
          if (!client[col] || client[col].toString().trim() === '') {
            rowErrors.push(`Linha ${i + 1}: ${col} é obrigatório`);
          }
        });

        // Validate email format
        if (client.email && !client.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
          rowErrors.push(`Linha ${i + 1}: Email inválido`);
        }

        // Validate phone format (basic)
        if (client.telefone && !client.telefone.toString().match(/[\d\s\(\)\-\+]{8,}/)) {
          rowErrors.push(`Linha ${i + 1}: Telefone inválido`);
        }

        if (rowErrors.length === 0) {
          processedData.push({
            nome: client.nome?.toString().trim(),
            email: client.email?.toString().trim().toLowerCase(),
            telefone: client.telefone?.toString().trim(),
            tipoProcesso: client.tipoprocesso?.toString().trim(),
            status: client.status?.toString().trim(),
            valorContrato: client.valorcontrato ? parseFloat(client.valorcontrato) : undefined,
            dataContrato: client.datacontrato?.toString().trim(),
            origem: client.origem?.toString().trim(),
            observacoes: client.observacoes?.toString().trim()
          });
        } else {
          validationErrors.push(...rowErrors);
        }
      }

      if (validationErrors.length > 0) {
        setErrors(validationErrors);
      } else {
        setImportedData(processedData);
      }

    } catch (error) {
      setErrors([error instanceof Error ? error.message : 'Erro ao processar arquivo']);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleImport = () => {
    onImport(importedData);
    onClose();
  };

  const downloadTemplate = () => {
    const templateData = [
      ['nome', 'email', 'telefone', 'tipoProcesso', 'status', 'valorContrato', 'dataContrato', 'origem', 'observacoes'],
      ['João Silva', 'joao@email.com', '(11) 99999-9999', 'Aposentadoria por Invalidez', 'ativo', '3500', '2024-01-15', 'Google Ads', 'Cliente preferencial'],
      ['Maria Santos', 'maria@email.com', '(11) 88888-8888', 'Auxílio Doença', 'em_andamento', '2800', '2024-02-01', 'Indicação', 'Documentos pendentes'],
      ['Pedro Costa', 'pedro@email.com', '(11) 77777-7777', 'BPC/LOAS', 'novo', '', '', 'Facebook', 'Aguardando contato']
    ];

    const ws = XLSX.utils.aoa_to_sheet(templateData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Clientes');
    XLSX.writeFile(wb, 'template_clientes_braga_advogados.xlsx');
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <FileSpreadsheet className="text-green-600" size={24} />
            <h2 className="text-xl font-semibold text-gray-900">Importar Clientes via Excel</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X size={24} />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Template Download */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium text-blue-900">📋 Baixar Template</h3>
                <p className="text-sm text-blue-700 mt-1">
                  Baixe o modelo Excel com as colunas corretas para importação
                </p>
              </div>
              <button
                onClick={downloadTemplate}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Download size={16} />
                <span>Baixar Template</span>
              </button>
            </div>
          </div>

          {/* Required Columns Info */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="text-sm font-medium text-gray-900 mb-3">📋 Colunas Obrigatórias</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {requiredColumns.map(col => (
                <div key={col} className="flex items-center space-x-2">
                  <CheckCircle className="text-green-500" size={16} />
                  <span className="text-sm text-gray-700">{col}</span>
                </div>
              ))}
            </div>
            <h4 className="text-sm font-medium text-gray-900 mt-4 mb-2">📋 Colunas Opcionais</h4>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {optionalColumns.map(col => (
                <div key={col} className="flex items-center space-x-2">
                  <div className="w-4 h-4 border border-gray-300 rounded-full"></div>
                  <span className="text-sm text-gray-600">{col}</span>
                </div>
              ))}
            </div>
          </div>

          {/* File Upload Area */}
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              dragActive 
                ? 'border-blue-400 bg-blue-50' 
                : 'border-gray-300 hover:border-blue-400'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <p className="text-lg font-medium text-gray-900 mb-2">
              Arraste e solte seu arquivo Excel aqui
            </p>
            <p className="text-sm text-gray-600 mb-4">
              ou clique para selecionar um arquivo (.xlsx, .xls)
            </p>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              disabled={isProcessing}
            >
              {isProcessing ? 'Processando...' : 'Selecionar Arquivo'}
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls"
              onChange={handleFileInput}
              className="hidden"
            />
          </div>

          {/* Errors */}
          {errors.length > 0 && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-3">
                <AlertCircle className="text-red-600" size={20} />
                <h3 className="text-sm font-medium text-red-900">Erros encontrados</h3>
              </div>
              <div className="space-y-1 max-h-32 overflow-y-auto">
                {errors.map((error, index) => (
                  <p key={index} className="text-sm text-red-700">• {error}</p>
                ))}
              </div>
            </div>
          )}

          {/* Preview */}
          {importedData.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium text-gray-900">
                  Preview dos Dados ({importedData.length} clientes)
                </h3>
                <button
                  onClick={handleImport}
                  className="flex items-center space-x-2 px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  <CheckCircle size={16} />
                  <span>Importar {importedData.length} Clientes</span>
                </button>
              </div>
              
              <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                <div className="overflow-x-auto max-h-64">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-2 text-left font-medium text-gray-900">Nome</th>
                        <th className="px-4 py-2 text-left font-medium text-gray-900">Email</th>
                        <th className="px-4 py-2 text-left font-medium text-gray-900">Telefone</th>
                        <th className="px-4 py-2 text-left font-medium text-gray-900">Tipo Processo</th>
                        <th className="px-4 py-2 text-left font-medium text-gray-900">Status</th>
                        <th className="px-4 py-2 text-left font-medium text-gray-900">Valor</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {importedData.slice(0, 10).map((client, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="px-4 py-2 text-gray-900">{client.nome}</td>
                          <td className="px-4 py-2 text-gray-600">{client.email}</td>
                          <td className="px-4 py-2 text-gray-600">{client.telefone}</td>
                          <td className="px-4 py-2 text-gray-600">{client.tipoProcesso}</td>
                          <td className="px-4 py-2">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              client.status === 'ativo' ? 'bg-green-100 text-green-800' :
                              client.status === 'em_andamento' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-blue-100 text-blue-800'
                            }`}>
                              {client.status}
                            </span>
                          </td>
                          <td className="px-4 py-2 text-gray-600">
                            {client.valorContrato ? `R$ ${client.valorContrato.toLocaleString('pt-BR')}` : '-'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {importedData.length > 10 && (
                  <div className="px-4 py-2 bg-gray-50 text-sm text-gray-600 text-center">
                    ... e mais {importedData.length - 10} clientes
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ExcelImport;