import React, { useState } from 'react';
import { X, Save, Scale, User, Calendar, FileText, AlertTriangle, Building, Clock, Target } from 'lucide-react';

interface ManualProcess {
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  clientCpf: string;
  clientAddress: string;
  clientCity: string;
  clientState: string;
  type: 'administrativo' | 'judicial';
  category: string;
  status: 'em_andamento' | 'deferido' | 'negado' | 'judicializado' | 'procedente' | 'improcedente';
  responsibleLawyer: string;
  priority: 'baixa' | 'media' | 'alta' | 'critica';
  description: string;
  expectedValue?: number;
  contractValue?: number;
  startDate: string;
  expectedDuration: number; // em dias
  originProcessId?: string; // Para processos judiciais originados de administrativos
  clientDecision?: 'aceita_judicial' | 'desiste_judicial' | 'pendente';
  judicialDecisionReason?: string;
  observations: string;
  urgentNotes?: string;
  documentsList: string[];
  hasDeadlines: boolean;
  firstDeadlineDate?: string;
  firstDeadlineType?: string;
  firstDeadlineDescription?: string;
}

interface ManualProcessFormProps {
  onSave: (process: ManualProcess) => void;
  onClose: () => void;
  adminProcesses?: any[]; // Para listar processos administrativos negados
}

const ManualProcessForm: React.FC<ManualProcessFormProps> = ({ onSave, onClose, adminProcesses = [] }) => {
  const [formData, setFormData] = useState<ManualProcess>({
    clientName: '',
    clientEmail: '',
    clientPhone: '',
    clientCpf: '',
    clientAddress: '',
    clientCity: '',
    clientState: '',
    type: 'administrativo',
    category: 'Aposentadoria por Invalidez',
    status: 'em_andamento',
    responsibleLawyer: 'Dr. Braga',
    priority: 'media',
    description: '',
    expectedValue: undefined,
    contractValue: undefined,
    startDate: new Date().toISOString().split('T')[0],
    expectedDuration: 90,
    observations: '',
    urgentNotes: '',
    documentsList: [],
    hasDeadlines: false,
    firstDeadlineDate: '',
    firstDeadlineType: 'exigencia',
    firstDeadlineDescription: ''
  });

  const [currentStep, setCurrentStep] = useState(1);
  const [newDocument, setNewDocument] = useState('');
  const totalSteps = 4;

  const processCategories = {
    administrativo: [
      'Aposentadoria por Invalidez',
      'Aposentadoria por Idade',
      'Aposentadoria por Tempo de Contribuição',
      'Aposentadoria Especial',
      'Auxílio Doença',
      'Auxílio Acidente',
      'BPC/LOAS',
      'Pensão por Morte',
      'Salário Maternidade',
      'Auxílio Reclusão',
      'Revisão de Benefício'
    ],
    judicial: [
      'Aposentadoria por Invalidez - Judicial',
      'Aposentadoria por Idade - Judicial',
      'Aposentadoria por Tempo - Judicial',
      'Aposentadoria Especial - Judicial',
      'Auxílio Doença - Judicial',
      'Auxílio Acidente - Judicial',
      'BPC/LOAS - Judicial',
      'Pensão por Morte - Judicial',
      'Trabalhista - Rescisão',
      'Trabalhista - Horas Extras',
      'Trabalhista - Adicional Insalubridade',
      'Trabalhista - FGTS'
    ]
  };

  const lawyers = [
    'Dr. Braga',
    'Dra. Costa',
    'Dr. Roberto Lima',
    'Dra. Patricia Oliveira',
    'Dr. Carlos Santos',
    'Dra. Ana Pereira'
  ];

  const estados = [
    'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA',
    'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN',
    'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'
  ];

  const deadlineTypes = [
    { value: 'exigencia', label: 'Exigência' },
    { value: 'recurso', label: 'Recurso' },
    { value: 'complementacao', label: 'Complementação' },
    { value: 'resposta', label: 'Resposta' },
    { value: 'pericia', label: 'Perícia' },
    { value: 'audiencia', label: 'Audiência' },
    { value: 'avaliacao_social', label: 'Avaliação Social' }
  ];

  const commonDocuments = [
    'RG e CPF',
    'Comprovante de Residência',
    'CTPS (Carteira de Trabalho)',
    'PIS/PASEP',
    'Certidão de Nascimento/Casamento',
    'Comprovante de Renda',
    'Extrato CNIS',
    'Laudo Médico',
    'Atestados Médicos',
    'Exames Médicos',
    'PPP (Perfil Profissiográfico)',
    'Certidão de Tempo de Contribuição',
    'Declaração de Dependentes',
    'Comprovante de Invalidez',
    'Documentos do Empregador'
  ];

  const handleInputChange = (field: keyof ManualProcess, value: string | number | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleAddDocument = () => {
    if (newDocument.trim()) {
      setFormData(prev => ({
        ...prev,
        documentsList: [...prev.documentsList, newDocument.trim()]
      }));
      setNewDocument('');
    }
  };

  const handleRemoveDocument = (index: number) => {
    setFormData(prev => ({
      ...prev,
      documentsList: prev.documentsList.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = () => {
    // Validação básica
    if (!formData.clientName || !formData.clientEmail || !formData.description) {
      alert('Por favor, preencha os campos obrigatórios: Nome do Cliente, Email e Descrição do Processo');
      return;
    }

    onSave(formData);
    onClose();
  };

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderStepIndicator = () => (
    <div className="flex items-center justify-center mb-6">
      {[1, 2, 3, 4].map((step) => (
        <div key={step} className="flex items-center">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
            step <= currentStep ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
          }`}>
            {step}
          </div>
          {step < totalSteps && (
            <div className={`w-12 h-1 mx-2 ${
              step < currentStep ? 'bg-blue-600' : 'bg-gray-200'
            }`} />
          )}
        </div>
      ))}
    </div>
  );

  const renderStep1 = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-medium text-gray-900 mb-4">👤 Dados do Cliente</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Nome Completo do Cliente *
          </label>
          <input
            type="text"
            value={formData.clientName}
            onChange={(e) => handleInputChange('clientName', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Nome completo do cliente"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            CPF do Cliente
          </label>
          <input
            type="text"
            value={formData.clientCpf}
            onChange={(e) => handleInputChange('clientCpf', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="000.000.000-00"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Email do Cliente *
          </label>
          <input
            type="email"
            value={formData.clientEmail}
            onChange={(e) => handleInputChange('clientEmail', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="cliente@email.com"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Telefone do Cliente
          </label>
          <input
            type="tel"
            value={formData.clientPhone}
            onChange={(e) => handleInputChange('clientPhone', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="(11) 99999-9999"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Endereço
          </label>
          <input
            type="text"
            value={formData.clientAddress}
            onChange={(e) => handleInputChange('clientAddress', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Rua, número, complemento"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Cidade
          </label>
          <input
            type="text"
            value={formData.clientCity}
            onChange={(e) => handleInputChange('clientCity', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Nome da cidade"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Estado
          </label>
          <select
            value={formData.clientState}
            onChange={(e) => handleInputChange('clientState', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Selecione o estado</option>
            {estados.map(estado => (
              <option key={estado} value={estado}>{estado}</option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-medium text-gray-900 mb-4">⚖️ Dados do Processo</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Tipo de Processo
          </label>
          <select
            value={formData.type}
            onChange={(e) => {
              const newType = e.target.value as 'administrativo' | 'judicial';
              handleInputChange('type', newType);
              // Reset category when type changes
              handleInputChange('category', processCategories[newType][0]);
            }}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            <option value="administrativo">Administrativo</option>
            <option value="judicial">Judicial</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Categoria do Processo
          </label>
          <select
            value={formData.category}
            onChange={(e) => handleInputChange('category', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            {processCategories[formData.type].map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Status Inicial
          </label>
          <select
            value={formData.status}
            onChange={(e) => handleInputChange('status', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            <option value="em_andamento">Em Andamento</option>
            {formData.type === 'administrativo' && (
              <>
                <option value="deferido">Deferido</option>
                <option value="negado">Negado</option>
              </>
            )}
            {formData.type === 'judicial' && (
              <>
                <option value="procedente">Procedente</option>
                <option value="improcedente">Improcedente</option>
              </>
            )}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Advogado Responsável
          </label>
          <select
            value={formData.responsibleLawyer}
            onChange={(e) => handleInputChange('responsibleLawyer', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            {lawyers.map(lawyer => (
              <option key={lawyer} value={lawyer}>{lawyer}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Prioridade
          </label>
          <select
            value={formData.priority}
            onChange={(e) => handleInputChange('priority', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            <option value="baixa">Baixa</option>
            <option value="media">Média</option>
            <option value="alta">Alta</option>
            <option value="critica">Crítica</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Data de Início
          </label>
          <input
            type="date"
            value={formData.startDate}
            onChange={(e) => handleInputChange('startDate', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Duração Esperada (dias)
          </label>
          <input
            type="number"
            value={formData.expectedDuration}
            onChange={(e) => handleInputChange('expectedDuration', parseInt(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            min="1"
            max="365"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Valor Esperado (R$)
          </label>
          <input
            type="number"
            value={formData.expectedValue || ''}
            onChange={(e) => handleInputChange('expectedValue', parseFloat(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="0,00"
            step="0.01"
          />
        </div>

        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Descrição do Processo *
          </label>
          <textarea
            value={formData.description}
            onChange={(e) => handleInputChange('description', e.target.value)}
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Descreva detalhadamente o processo, situação do cliente, histórico médico, etc."
          />
        </div>

        {/* Processo Judicial originado de Administrativo */}
        {formData.type === 'judicial' && adminProcesses.length > 0 && (
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Processo Administrativo de Origem (opcional)
            </label>
            <select
              value={formData.originProcessId || ''}
              onChange={(e) => handleInputChange('originProcessId', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Selecione se este processo judicial originou de um administrativo negado</option>
              {adminProcesses.filter(p => p.status === 'negado').map(process => (
                <option key={process.id} value={process.id}>
                  {process.clientName} - {process.category}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-medium text-gray-900 mb-4">📋 Documentos e Prazos</h3>
      
      {/* Lista de Documentos */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Documentos Necessários
        </label>
        
        {/* Documentos Comuns */}
        <div className="mb-4">
          <p className="text-sm text-gray-600 mb-2">Documentos comuns (clique para adicionar):</p>
          <div className="flex flex-wrap gap-2">
            {commonDocuments.map(doc => (
              <button
                key={doc}
                type="button"
                onClick={() => {
                  if (!formData.documentsList.includes(doc)) {
                    setFormData(prev => ({
                      ...prev,
                      documentsList: [...prev.documentsList, doc]
                    }));
                  }
                }}
                className={`px-3 py-1 text-xs rounded-full border ${
                  formData.documentsList.includes(doc)
                    ? 'bg-blue-100 text-blue-800 border-blue-300'
                    : 'bg-gray-100 text-gray-700 border-gray-300 hover:bg-gray-200'
                }`}
              >
                {doc}
              </button>
            ))}
          </div>
        </div>

        {/* Adicionar Documento Personalizado */}
        <div className="flex space-x-2 mb-3">
          <input
            type="text"
            value={newDocument}
            onChange={(e) => setNewDocument(e.target.value)}
            placeholder="Digite um documento personalizado"
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            onKeyPress={(e) => e.key === 'Enter' && handleAddDocument()}
          />
          <button
            type="button"
            onClick={handleAddDocument}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Adicionar
          </button>
        </div>

        {/* Lista de Documentos Selecionados */}
        {formData.documentsList.length > 0 && (
          <div className="border border-gray-200 rounded-lg p-3">
            <p className="text-sm font-medium text-gray-700 mb-2">Documentos selecionados:</p>
            <div className="space-y-2">
              {formData.documentsList.map((doc, index) => (
                <div key={index} className="flex items-center justify-between bg-gray-50 px-3 py-2 rounded">
                  <span className="text-sm text-gray-700">{doc}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveDocument(index)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <X size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Prazos */}
      <div className="border-t pt-4">
        <label className="flex items-center space-x-2 mb-4">
          <input
            type="checkbox"
            checked={formData.hasDeadlines}
            onChange={(e) => handleInputChange('hasDeadlines', e.target.checked)}
            className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
          />
          <span className="text-sm font-medium text-gray-700">Este processo possui prazos importantes</span>
        </label>

        {formData.hasDeadlines && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-yellow-50 p-4 rounded-lg">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Tipo do Primeiro Prazo
              </label>
              <select
                value={formData.firstDeadlineType || ''}
                onChange={(e) => handleInputChange('firstDeadlineType', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                {deadlineTypes.map(type => (
                  <option key={type.value} value={type.value}>{type.label}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Data do Prazo
              </label>
              <input
                type="date"
                value={formData.firstDeadlineDate || ''}
                onChange={(e) => handleInputChange('firstDeadlineDate', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Descrição do Prazo
              </label>
              <input
                type="text"
                value={formData.firstDeadlineDescription || ''}
                onChange={(e) => handleInputChange('firstDeadlineDescription', e.target.value)}
                placeholder="Ex: Responder exigência do INSS sobre documentos médicos"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-medium text-gray-900 mb-4">📝 Observações e Finalização</h3>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Valor do Contrato (R$)
          </label>
          <input
            type="number"
            value={formData.contractValue || ''}
            onChange={(e) => handleInputChange('contractValue', parseFloat(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="0,00"
            step="0.01"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Observações Gerais
          </label>
          <textarea
            value={formData.observations}
            onChange={(e) => handleInputChange('observations', e.target.value)}
            rows={4}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Observações importantes sobre o processo, histórico do cliente, particularidades do caso, etc."
          />
        </div>

        {formData.priority === 'critica' && (
          <div>
            <label className="block text-sm font-medium text-red-700 mb-1">
              Notas Urgentes (Prioridade Crítica)
            </label>
            <textarea
              value={formData.urgentNotes || ''}
              onChange={(e) => handleInputChange('urgentNotes', e.target.value)}
              rows={3}
              className="w-full px-3 py-2 border border-red-300 rounded-lg focus:ring-2 focus:ring-red-500 bg-red-50"
              placeholder="Descreva por que este processo é de prioridade crítica e quais ações urgentes são necessárias"
            />
          </div>
        )}

        {/* Decisão sobre Judicialização (para processos judiciais com origem) */}
        {formData.type === 'judicial' && formData.originProcessId && (
          <div className="bg-blue-50 rounded-lg p-4">
            <h4 className="text-md font-medium text-blue-900 mb-3">Decisão sobre Judicialização</h4>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-blue-700 mb-1">
                  Decisão do Cliente
                </label>
                <select
                  value={formData.clientDecision || 'aceita_judicial'}
                  onChange={(e) => handleInputChange('clientDecision', e.target.value)}
                  className="w-full px-3 py-2 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="aceita_judicial">Aceitou prosseguir com ação judicial</option>
                  <option value="desiste_judicial">Desistiu da ação judicial</option>
                  <option value="pendente">Decisão pendente</option>
                </select>
              </div>

              {formData.clientDecision === 'desiste_judicial' && (
                <div>
                  <label className="block text-sm font-medium text-blue-700 mb-1">
                    Motivo da Desistência
                  </label>
                  <input
                    type="text"
                    value={formData.judicialDecisionReason || ''}
                    onChange={(e) => handleInputChange('judicialDecisionReason', e.target.value)}
                    placeholder="Ex: Cliente não quer arcar com custos judiciais"
                    className="w-full px-3 py-2 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              )}
            </div>
          </div>
        )}

        {/* Resumo dos dados */}
        <div className="bg-gray-50 rounded-lg p-4 mt-6">
          <h4 className="text-md font-medium text-gray-900 mb-3">📋 Resumo do Processo</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
            <div>
              <span className="font-medium text-gray-700">Cliente:</span> {formData.clientName || 'Não informado'}
            </div>
            <div>
              <span className="font-medium text-gray-700">Email:</span> {formData.clientEmail || 'Não informado'}
            </div>
            <div>
              <span className="font-medium text-gray-700">Tipo:</span> {formData.type}
            </div>
            <div>
              <span className="font-medium text-gray-700">Categoria:</span> {formData.category}
            </div>
            <div>
              <span className="font-medium text-gray-700">Advogado:</span> {formData.responsibleLawyer}
            </div>
            <div>
              <span className="font-medium text-gray-700">Prioridade:</span> 
              <span className={`ml-1 px-2 py-1 rounded-full text-xs ${
                formData.priority === 'critica' ? 'bg-red-100 text-red-800' :
                formData.priority === 'alta' ? 'bg-orange-100 text-orange-800' :
                formData.priority === 'media' ? 'bg-yellow-100 text-yellow-800' :
                'bg-gray-100 text-gray-800'
              }`}>
                {formData.priority}
              </span>
            </div>
            <div>
              <span className="font-medium text-gray-700">Documentos:</span> {formData.documentsList.length} selecionados
            </div>
            <div>
              <span className="font-medium text-gray-700">Prazos:</span> {formData.hasDeadlines ? 'Sim' : 'Não'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-5xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <Scale className="text-blue-600" size={24} />
            <h2 className="text-xl font-semibold text-gray-900">Cadastro Manual de Processo</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X size={24} />
          </button>
        </div>

        <div className="p-6">
          {renderStepIndicator()}

          <div className="min-h-[500px]">
            {currentStep === 1 && renderStep1()}
            {currentStep === 2 && renderStep2()}
            {currentStep === 3 && renderStep3()}
            {currentStep === 4 && renderStep4()}
          </div>

          <div className="flex justify-between mt-8 pt-6 border-t border-gray-200">
            <button
              onClick={prevStep}
              disabled={currentStep === 1}
              className={`px-4 py-2 rounded-lg ${
                currentStep === 1
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              Anterior
            </button>

            <div className="flex space-x-3">
              <button
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancelar
              </button>
              
              {currentStep === totalSteps ? (
                <button
                  onClick={handleSubmit}
                  className="flex items-center space-x-2 px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  <Save size={16} />
                  <span>Salvar Processo</span>
                </button>
              ) : (
                <button
                  onClick={nextStep}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Próximo
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManualProcessForm;