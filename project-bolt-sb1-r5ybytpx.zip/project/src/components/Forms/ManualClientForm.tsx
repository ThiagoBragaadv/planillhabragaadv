import React, { useState } from 'react';
import { X, Save, User, Mail, Phone, MapPin, Calendar, FileText, DollarSign, Tag, Users } from 'lucide-react';

interface ManualClient {
  nome: string;
  email: string;
  telefone: string;
  cpf: string;
  endereco: string;
  cidade: string;
  estado: string;
  cep: string;
  dataNascimento: string;
  estadoCivil: string;
  profissao: string;
  tipoProcesso: string;
  status: string;
  origem: string;
  campanha?: string;
  valorContrato?: number;
  dataContrato?: string;
  observacoes?: string;
  vendedorResponsavel: string;
  prioridade: 'baixa' | 'media' | 'alta';
  comoConheceu: string;
  interesseEspecifico: string;
}

interface ManualClientFormProps {
  onSave: (client: ManualClient) => void;
  onClose: () => void;
}

const ManualClientForm: React.FC<ManualClientFormProps> = ({ onSave, onClose }) => {
  const [formData, setFormData] = useState<ManualClient>({
    nome: '',
    email: '',
    telefone: '',
    cpf: '',
    endereco: '',
    cidade: '',
    estado: '',
    cep: '',
    dataNascimento: '',
    estadoCivil: 'solteiro',
    profissao: '',
    tipoProcesso: 'Aposentadoria por Invalidez',
    status: 'novo',
    origem: 'Manual',
    campanha: '',
    valorContrato: undefined,
    dataContrato: '',
    observacoes: '',
    vendedorResponsavel: 'Maria Silva',
    prioridade: 'media',
    comoConheceu: '',
    interesseEspecifico: ''
  });

  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 4;

  const tiposProcesso = [
    'Aposentadoria por Invalidez',
    'Aposentadoria por Idade',
    'Aposentadoria por Tempo de Contribuição',
    'Aposentadoria Especial',
    'Auxílio Doença',
    'Auxílio Acidente',
    'BPC/LOAS',
    'Pensão por Morte',
    'Salário Maternidade',
    'Auxílio Reclusão',
    'Revisão de Benefício',
    'Trabalhista - Rescisão',
    'Trabalhista - Horas Extras',
    'Trabalhista - Adicional Insalubridade',
    'Trabalhista - FGTS',
    'Outros'
  ];

  const vendedores = [
    'Maria Silva',
    'João Santos',
    'Ana Costa',
    'Carlos Braga',
    'Paulo Lima',
    'Fernanda Souza'
  ];

  const estados = [
    'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA',
    'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN',
    'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'
  ];

  const origens = [
    'Manual',
    'Google Ads',
    'Facebook Ads',
    'Instagram Ads',
    'Meta Ads',
    'Indicação',
    'Site',
    'WhatsApp',
    'Telefone',
    'Presencial',
    'Outros'
  ];

  const handleInputChange = (field: keyof ManualClient, value: string | number) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = () => {
    // Validação básica
    if (!formData.nome || !formData.email || !formData.telefone) {
      alert('Por favor, preencha os campos obrigatórios: Nome, Email e Telefone');
      return;
    }

    onSave(formData);
    onClose();
  };

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderStepIndicator = () => (
    <div className="flex items-center justify-center mb-6">
      {[1, 2, 3, 4].map((step) => (
        <div key={step} className="flex items-center">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
            step <= currentStep ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
          }`}>
            {step}
          </div>
          {step < totalSteps && (
            <div className={`w-12 h-1 mx-2 ${
              step < currentStep ? 'bg-blue-600' : 'bg-gray-200'
            }`} />
          )}
        </div>
      ))}
    </div>
  );

  const renderStep1 = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-medium text-gray-900 mb-4">📋 Dados Pessoais</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Nome Completo *
          </label>
          <input
            type="text"
            value={formData.nome}
            onChange={(e) => handleInputChange('nome', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Nome completo do cliente"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            CPF
          </label>
          <input
            type="text"
            value={formData.cpf}
            onChange={(e) => handleInputChange('cpf', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="000.000.000-00"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Email *
          </label>
          <input
            type="email"
            value={formData.email}
            onChange={(e) => handleInputChange('email', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="email@exemplo.com"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Telefone *
          </label>
          <input
            type="tel"
            value={formData.telefone}
            onChange={(e) => handleInputChange('telefone', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="(11) 99999-9999"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Data de Nascimento
          </label>
          <input
            type="date"
            value={formData.dataNascimento}
            onChange={(e) => handleInputChange('dataNascimento', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Estado Civil
          </label>
          <select
            value={formData.estadoCivil}
            onChange={(e) => handleInputChange('estadoCivil', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            <option value="solteiro">Solteiro(a)</option>
            <option value="casado">Casado(a)</option>
            <option value="divorciado">Divorciado(a)</option>
            <option value="viuvo">Viúvo(a)</option>
            <option value="uniao_estavel">União Estável</option>
          </select>
        </div>

        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Profissão
          </label>
          <input
            type="text"
            value={formData.profissao}
            onChange={(e) => handleInputChange('profissao', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Profissão atual ou anterior"
          />
        </div>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-medium text-gray-900 mb-4">📍 Endereço</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Endereço Completo
          </label>
          <input
            type="text"
            value={formData.endereco}
            onChange={(e) => handleInputChange('endereco', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Rua, número, complemento"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Cidade
          </label>
          <input
            type="text"
            value={formData.cidade}
            onChange={(e) => handleInputChange('cidade', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Nome da cidade"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Estado
          </label>
          <select
            value={formData.estado}
            onChange={(e) => handleInputChange('estado', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Selecione o estado</option>
            {estados.map(estado => (
              <option key={estado} value={estado}>{estado}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            CEP
          </label>
          <input
            type="text"
            value={formData.cep}
            onChange={(e) => handleInputChange('cep', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="00000-000"
          />
        </div>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-medium text-gray-900 mb-4">⚖️ Informações do Processo</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Tipo de Processo
          </label>
          <select
            value={formData.tipoProcesso}
            onChange={(e) => handleInputChange('tipoProcesso', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            {tiposProcesso.map(tipo => (
              <option key={tipo} value={tipo}>{tipo}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Status
          </label>
          <select
            value={formData.status}
            onChange={(e) => handleInputChange('status', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            <option value="novo">Novo</option>
            <option value="contato">Em Contato</option>
            <option value="proposta">Proposta Enviada</option>
            <option value="ativo">Ativo</option>
            <option value="em_andamento">Em Andamento</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Origem
          </label>
          <select
            value={formData.origem}
            onChange={(e) => handleInputChange('origem', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            {origens.map(origem => (
              <option key={origem} value={origem}>{origem}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Campanha
          </label>
          <input
            type="text"
            value={formData.campanha || ''}
            onChange={(e) => handleInputChange('campanha', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Nome da campanha (se aplicável)"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Vendedor Responsável
          </label>
          <select
            value={formData.vendedorResponsavel}
            onChange={(e) => handleInputChange('vendedorResponsavel', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            {vendedores.map(vendedor => (
              <option key={vendedor} value={vendedor}>{vendedor}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Prioridade
          </label>
          <select
            value={formData.prioridade}
            onChange={(e) => handleInputChange('prioridade', e.target.value as 'baixa' | 'media' | 'alta')}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            <option value="baixa">Baixa</option>
            <option value="media">Média</option>
            <option value="alta">Alta</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Valor do Contrato (R$)
          </label>
          <input
            type="number"
            value={formData.valorContrato || ''}
            onChange={(e) => handleInputChange('valorContrato', parseFloat(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="0,00"
            step="0.01"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Data do Contrato
          </label>
          <input
            type="date"
            value={formData.dataContrato || ''}
            onChange={(e) => handleInputChange('dataContrato', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-medium text-gray-900 mb-4">📝 Informações Adicionais</h3>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Como conheceu nosso escritório?
          </label>
          <input
            type="text"
            value={formData.comoConheceu}
            onChange={(e) => handleInputChange('comoConheceu', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Ex: Indicação de amigo, pesquisa no Google, etc."
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Interesse Específico
          </label>
          <input
            type="text"
            value={formData.interesseEspecifico}
            onChange={(e) => handleInputChange('interesseEspecifico', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Ex: Revisão de aposentadoria, auxílio negado, etc."
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Observações
          </label>
          <textarea
            value={formData.observacoes || ''}
            onChange={(e) => handleInputChange('observacoes', e.target.value)}
            rows={4}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Informações adicionais, histórico médico, situação específica, etc."
          />
        </div>

        {/* Resumo dos dados */}
        <div className="bg-gray-50 rounded-lg p-4 mt-6">
          <h4 className="text-md font-medium text-gray-900 mb-3">📋 Resumo dos Dados</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
            <div>
              <span className="font-medium text-gray-700">Nome:</span> {formData.nome || 'Não informado'}
            </div>
            <div>
              <span className="font-medium text-gray-700">Email:</span> {formData.email || 'Não informado'}
            </div>
            <div>
              <span className="font-medium text-gray-700">Telefone:</span> {formData.telefone || 'Não informado'}
            </div>
            <div>
              <span className="font-medium text-gray-700">Tipo de Processo:</span> {formData.tipoProcesso}
            </div>
            <div>
              <span className="font-medium text-gray-700">Origem:</span> {formData.origem}
            </div>
            <div>
              <span className="font-medium text-gray-700">Vendedor:</span> {formData.vendedorResponsavel}
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <User className="text-blue-600" size={24} />
            <h2 className="text-xl font-semibold text-gray-900">Cadastro Manual de Cliente</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X size={24} />
          </button>
        </div>

        <div className="p-6">
          {renderStepIndicator()}

          <div className="min-h-[400px]">
            {currentStep === 1 && renderStep1()}
            {currentStep === 2 && renderStep2()}
            {currentStep === 3 && renderStep3()}
            {currentStep === 4 && renderStep4()}
          </div>

          <div className="flex justify-between mt-8 pt-6 border-t border-gray-200">
            <button
              onClick={prevStep}
              disabled={currentStep === 1}
              className={`px-4 py-2 rounded-lg ${
                currentStep === 1
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              Anterior
            </button>

            <div className="flex space-x-3">
              <button
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancelar
              </button>
              
              {currentStep === totalSteps ? (
                <button
                  onClick={handleSubmit}
                  className="flex items-center space-x-2 px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  <Save size={16} />
                  <span>Salvar Cliente</span>
                </button>
              ) : (
                <button
                  onClick={nextStep}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Próximo
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManualClientForm;