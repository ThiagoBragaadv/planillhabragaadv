import React, { useState } from 'react';
import { X, Save, FileText, Calendar, User, AlertTriangle, CheckCircle, Clock, Eye } from 'lucide-react';

interface Document {
  id: string;
  name: string;
  status: 'pendente' | 'completo' | 'revisado';
  uploadedAt?: string;
  processId: string;
  clientName?: string;
  processType?: string;
  processCategory?: string;
  reviewedBy?: string;
  reviewedAt?: string;
  notes?: string;
  priority?: 'baixa' | 'media' | 'alta' | 'critica';
  expirationDate?: string;
  fileSize?: string;
  fileType?: string;
  version?: number;
  tags?: string[];
}

interface DocumentEditFormProps {
  document: Document;
  onSave: (document: Document) => void;
  onClose: () => void;
}

const DocumentEditForm: React.FC<DocumentEditFormProps> = ({ document, onSave, onClose }) => {
  const [formData, setFormData] = useState<Document>({
    ...document,
    reviewedBy: document.reviewedBy || '',
    reviewedAt: document.reviewedAt || '',
    notes: document.notes || '',
    priority: document.priority || 'media',
    expirationDate: document.expirationDate || '',
    fileSize: document.fileSize || '',
    fileType: document.fileType || 'PDF',
    version: document.version || 1,
    tags: document.tags || []
  });

  const [newTag, setNewTag] = useState('');

  const statusOptions = [
    { value: 'pendente', label: 'Pendente', color: 'bg-yellow-100 text-yellow-800', icon: Clock },
    { value: 'completo', label: 'Completo', color: 'bg-green-100 text-green-800', icon: CheckCircle },
    { value: 'revisado', label: 'Revisado', color: 'bg-blue-100 text-blue-800', icon: Eye }
  ];

  const priorityOptions = [
    { value: 'baixa', label: 'Baixa', color: 'bg-gray-100 text-gray-800' },
    { value: 'media', label: 'Média', color: 'bg-yellow-100 text-yellow-800' },
    { value: 'alta', label: 'Alta', color: 'bg-orange-100 text-orange-800' },
    { value: 'critica', label: 'Crítica', color: 'bg-red-100 text-red-800' }
  ];

  const fileTypeOptions = [
    'PDF', 'DOC', 'DOCX', 'JPG', 'PNG', 'JPEG', 'XLS', 'XLSX', 'TXT', 'ZIP', 'RAR'
  ];

  const commonTags = [
    'Urgente', 'Médico', 'Trabalhista', 'INSS', 'Judicial', 'Administrativo',
    'Perícia', 'Laudo', 'Atestado', 'Comprovante', 'Certidão', 'Declaração'
  ];

  const reviewers = [
    'Dr. Braga',
    'Dra. Costa',
    'Dr. Roberto Lima',
    'Dra. Patricia Oliveira',
    'Fernanda Souza',
    'Lucas Pereira'
  ];

  const handleInputChange = (field: keyof Document, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleStatusChange = (newStatus: 'pendente' | 'completo' | 'revisado') => {
    const updates: Partial<Document> = { status: newStatus };
    
    if (newStatus === 'completo' && !formData.uploadedAt) {
      updates.uploadedAt = new Date().toISOString().split('T')[0];
    }
    
    if (newStatus === 'revisado') {
      updates.reviewedAt = new Date().toISOString().split('T')[0];
      if (!formData.reviewedBy) {
        updates.reviewedBy = 'Dr. Braga'; // Default reviewer
      }
    }

    setFormData(prev => ({ ...prev, ...updates }));
  };

  const handleAddTag = () => {
    if (newTag.trim() && !formData.tags?.includes(newTag.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...(prev.tags || []), newTag.trim()]
      }));
      setNewTag('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags?.filter(tag => tag !== tagToRemove) || []
    }));
  };

  const handleSubmit = () => {
    // Validação básica
    if (!formData.name.trim()) {
      alert('Nome do documento é obrigatório');
      return;
    }

    onSave(formData);
    onClose();
  };

  const getCurrentStatusConfig = () => {
    return statusOptions.find(option => option.value === formData.status) || statusOptions[0];
  };

  const getCurrentPriorityConfig = () => {
    return priorityOptions.find(option => option.value === formData.priority) || priorityOptions[1];
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <FileText className="text-blue-600" size={24} />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Editar Documento</h2>
              <p className="text-sm text-gray-600">{document.clientName} - {document.processCategory}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X size={24} />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Status e Informações Básicas */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">📋 Informações Básicas</h3>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nome do Documento
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="Nome do documento"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Status do Documento
                </label>
                <div className="space-y-2">
                  {statusOptions.map((option) => {
                    const Icon = option.icon;
                    return (
                      <label key={option.value} className="flex items-center space-x-3 cursor-pointer">
                        <input
                          type="radio"
                          name="status"
                          value={option.value}
                          checked={formData.status === option.value}
                          onChange={() => handleStatusChange(option.value as any)}
                          className="text-blue-600 focus:ring-blue-500"
                        />
                        <div className="flex items-center space-x-2">
                          <Icon size={16} className={
                            option.value === 'pendente' ? 'text-yellow-600' :
                            option.value === 'completo' ? 'text-green-600' :
                            'text-blue-600'
                          } />
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${option.color}`}>
                            {option.label}
                          </span>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Prioridade
                </label>
                <select
                  value={formData.priority}
                  onChange={(e) => handleInputChange('priority', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  {priorityOptions.map(option => (
                    <option key={option.value} value={option.value}>{option.label}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tipo de Arquivo
                </label>
                <select
                  value={formData.fileType}
                  onChange={(e) => handleInputChange('fileType', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  {fileTypeOptions.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">📅 Datas e Controle</h3>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Data de Upload
                </label>
                <input
                  type="date"
                  value={formData.uploadedAt || ''}
                  onChange={(e) => handleInputChange('uploadedAt', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {formData.status === 'revisado' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Revisado por
                    </label>
                    <select
                      value={formData.reviewedBy || ''}
                      onChange={(e) => handleInputChange('reviewedBy', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">Selecione o revisor</option>
                      {reviewers.map(reviewer => (
                        <option key={reviewer} value={reviewer}>{reviewer}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Data da Revisão
                    </label>
                    <input
                      type="date"
                      value={formData.reviewedAt || ''}
                      onChange={(e) => handleInputChange('reviewedAt', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Data de Expiração (opcional)
                </label>
                <input
                  type="date"
                  value={formData.expirationDate || ''}
                  onChange={(e) => handleInputChange('expirationDate', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Tamanho do Arquivo
                  </label>
                  <input
                    type="text"
                    value={formData.fileSize || ''}
                    onChange={(e) => handleInputChange('fileSize', e.target.value)}
                    placeholder="Ex: 2.5 MB"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Versão
                  </label>
                  <input
                    type="number"
                    value={formData.version || 1}
                    onChange={(e) => handleInputChange('version', parseInt(e.target.value))}
                    min="1"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Tags */}
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-4">🏷️ Tags e Categorização</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tags Comuns (clique para adicionar)
                </label>
                <div className="flex flex-wrap gap-2">
                  {commonTags.map(tag => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => {
                        if (!formData.tags?.includes(tag)) {
                          setFormData(prev => ({
                            ...prev,
                            tags: [...(prev.tags || []), tag]
                          }));
                        }
                      }}
                      className={`px-3 py-1 text-xs rounded-full border ${
                        formData.tags?.includes(tag)
                          ? 'bg-blue-100 text-blue-800 border-blue-300'
                          : 'bg-gray-100 text-gray-700 border-gray-300 hover:bg-gray-200'
                      }`}
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex space-x-2">
                <input
                  type="text"
                  value={newTag}
                  onChange={(e) => setNewTag(e.target.value)}
                  placeholder="Digite uma tag personalizada"
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
                />
                <button
                  type="button"
                  onClick={handleAddTag}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Adicionar Tag
                </button>
              </div>

              {formData.tags && formData.tags.length > 0 && (
                <div className="border border-gray-200 rounded-lg p-3">
                  <p className="text-sm font-medium text-gray-700 mb-2">Tags selecionadas:</p>
                  <div className="flex flex-wrap gap-2">
                    {formData.tags.map((tag, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center space-x-1 px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs"
                      >
                        <span>{tag}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveTag(tag)}
                          className="text-blue-600 hover:text-blue-800"
                        >
                          <X size={12} />
                        </button>
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Observações */}
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-4">📝 Observações e Notas</h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Observações sobre o documento
              </label>
              <textarea
                value={formData.notes || ''}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder="Adicione observações importantes sobre este documento, como qualidade, legibilidade, informações relevantes, etc."
              />
            </div>
          </div>

          {/* Resumo das Alterações */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="text-md font-medium text-gray-900 mb-3">📋 Resumo das Informações</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Status:</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCurrentStatusConfig().color}`}>
                    {getCurrentStatusConfig().label}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Prioridade:</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCurrentPriorityConfig().color}`}>
                    {getCurrentPriorityConfig().label}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Tipo:</span>
                  <span className="text-sm font-medium text-gray-900">{formData.fileType}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Versão:</span>
                  <span className="text-sm font-medium text-gray-900">v{formData.version}</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Upload:</span>
                  <span className="text-sm font-medium text-gray-900">
                    {formData.uploadedAt ? new Date(formData.uploadedAt).toLocaleDateString('pt-BR') : 'Não definido'}
                  </span>
                </div>
                {formData.status === 'revisado' && (
                  <>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Revisor:</span>
                      <span className="text-sm font-medium text-gray-900">{formData.reviewedBy || 'Não definido'}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Revisão:</span>
                      <span className="text-sm font-medium text-gray-900">
                        {formData.reviewedAt ? new Date(formData.reviewedAt).toLocaleDateString('pt-BR') : 'Não definido'}
                      </span>
                    </div>
                  </>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Tags:</span>
                  <span className="text-sm font-medium text-gray-900">{formData.tags?.length || 0} tag(s)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Alertas baseados no status */}
          {formData.status === 'pendente' && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="text-yellow-600" size={20} />
                <div>
                  <h4 className="text-sm font-medium text-yellow-800">Documento Pendente</h4>
                  <p className="text-sm text-yellow-700 mt-1">
                    Este documento ainda não foi enviado. Lembre-se de solicitar o envio ao cliente ou responsável.
                  </p>
                </div>
              </div>
            </div>
          )}

          {formData.expirationDate && new Date(formData.expirationDate) < new Date() && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="text-red-600" size={20} />
                <div>
                  <h4 className="text-sm font-medium text-red-800">Documento Expirado</h4>
                  <p className="text-sm text-red-700 mt-1">
                    Este documento expirou em {new Date(formData.expirationDate).toLocaleDateString('pt-BR')}. 
                    Solicite uma versão atualizada.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="flex justify-end space-x-3 p-6 border-t border-gray-200">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            Cancelar
          </button>
          <button
            onClick={handleSubmit}
            className="flex items-center space-x-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Save size={16} />
            <span>Salvar Alterações</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default DocumentEditForm;