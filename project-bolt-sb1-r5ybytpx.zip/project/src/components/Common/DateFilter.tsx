import React from 'react';
import { Calendar, Filter } from 'lucide-react';

interface DateFilterProps {
  startDate: string;
  endDate: string;
  onStartDateChange: (date: string) => void;
  onEndDateChange: (date: string) => void;
  onPresetSelect: (preset: string) => void;
  className?: string;
}

const DateFilter: React.FC<DateFilterProps> = ({
  startDate,
  endDate,
  onStartDateChange,
  onEndDateChange,
  onPresetSelect,
  className = ''
}) => {
  const presets = [
    { id: 'today', label: 'Hoje' },
    { id: 'yesterday', label: 'Ontem' },
    { id: 'last_7_days', label: 'Últimos 7 dias' },
    { id: 'last_30_days', label: 'Últimos 30 dias' },
    { id: 'this_month', label: 'Este mês' },
    { id: 'last_month', label: 'Mês passado' },
    { id: 'this_quarter', label: 'Este trimestre' },
    { id: 'this_year', label: 'Este ano' },
    { id: 'custom', label: 'Personalizado' }
  ];

  const handlePresetChange = (presetId: string) => {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    
    const startOfLastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
    const endOfLastMonth = new Date(today.getFullYear(), today.getMonth(), 0);
    
    const startOfQuarter = new Date(today.getFullYear(), Math.floor(today.getMonth() / 3) * 3, 1);
    const endOfQuarter = new Date(today.getFullYear(), Math.floor(today.getMonth() / 3) * 3 + 3, 0);
    
    const startOfYear = new Date(today.getFullYear(), 0, 1);
    const endOfYear = new Date(today.getFullYear(), 11, 31);

    switch (presetId) {
      case 'today':
        onStartDateChange(today.toISOString().split('T')[0]);
        onEndDateChange(today.toISOString().split('T')[0]);
        break;
      case 'yesterday':
        onStartDateChange(yesterday.toISOString().split('T')[0]);
        onEndDateChange(yesterday.toISOString().split('T')[0]);
        break;
      case 'last_7_days':
        const last7Days = new Date(today);
        last7Days.setDate(last7Days.getDate() - 7);
        onStartDateChange(last7Days.toISOString().split('T')[0]);
        onEndDateChange(today.toISOString().split('T')[0]);
        break;
      case 'last_30_days':
        const last30Days = new Date(today);
        last30Days.setDate(last30Days.getDate() - 30);
        onStartDateChange(last30Days.toISOString().split('T')[0]);
        onEndDateChange(today.toISOString().split('T')[0]);
        break;
      case 'this_month':
        onStartDateChange(startOfMonth.toISOString().split('T')[0]);
        onEndDateChange(endOfMonth.toISOString().split('T')[0]);
        break;
      case 'last_month':
        onStartDateChange(startOfLastMonth.toISOString().split('T')[0]);
        onEndDateChange(endOfLastMonth.toISOString().split('T')[0]);
        break;
      case 'this_quarter':
        onStartDateChange(startOfQuarter.toISOString().split('T')[0]);
        onEndDateChange(endOfQuarter.toISOString().split('T')[0]);
        break;
      case 'this_year':
        onStartDateChange(startOfYear.toISOString().split('T')[0]);
        onEndDateChange(endOfYear.toISOString().split('T')[0]);
        break;
    }
    
    onPresetSelect(presetId);
  };

  return (
    <div className={`bg-white border border-gray-200 rounded-lg p-4 ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Calendar className="text-blue-600" size={20} />
          <h3 className="text-sm font-medium text-gray-900">Filtro por Data</h3>
        </div>
        <Filter className="text-gray-400" size={16} />
      </div>

      <div className="space-y-4">
        {/* Preset Buttons */}
        <div className="grid grid-cols-3 gap-2">
          {presets.map((preset) => (
            <button
              key={preset.id}
              onClick={() => handlePresetChange(preset.id)}
              className="px-3 py-2 text-xs border border-gray-300 rounded-lg hover:bg-gray-50 hover:border-blue-300 transition-colors"
            >
              {preset.label}
            </button>
          ))}
        </div>

        {/* Custom Date Range */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">
              Data Inicial
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => onStartDateChange(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">
              Data Final
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => onEndDateChange(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Date Range Display */}
        {startDate && endDate && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
            <div className="flex items-center space-x-2">
              <Calendar className="text-blue-600" size={14} />
              <span className="text-xs text-blue-800 font-medium">
                Período: {new Date(startDate).toLocaleDateString('pt-BR')} até {new Date(endDate).toLocaleDateString('pt-BR')}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DateFilter;