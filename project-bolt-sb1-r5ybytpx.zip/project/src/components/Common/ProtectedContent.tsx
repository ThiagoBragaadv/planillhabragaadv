import React, { ReactNode } from 'react';
import { Shield, Lock, AlertTriangle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface ProtectedContentProps {
  children: ReactNode;
  requiredPermission?: string;
  requiredRole?: string;
  fallback?: ReactNode;
  showFallback?: boolean;
}

const ProtectedContent: React.FC<ProtectedContentProps> = ({
  children,
  requiredPermission,
  requiredRole,
  fallback,
  showFallback = true
}) => {
  const { currentUser, hasPermission } = useAuth();

  // Check role-based access
  if (requiredRole && currentUser?.role !== requiredRole) {
    if (!showFallback) return null;
    
    return fallback || (
      <div className="flex items-center justify-center p-8 bg-gray-50 border border-gray-200 rounded-lg">
        <div className="text-center">
          <Shield className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Acesso Restrito</h3>
          <p className="text-sm text-gray-600 mb-4">
            Este conteúdo está disponível apenas para {requiredRole === 'admin' ? 'administradores' : requiredRole}.
          </p>
          <div className="flex items-center justify-center space-x-2 text-xs text-gray-500">
            <Lock size={12} />
            <span>Nível de acesso insuficiente</span>
          </div>
        </div>
      </div>
    );
  }

  // Check permission-based access
  if (requiredPermission && !hasPermission(requiredPermission)) {
    if (!showFallback) return null;
    
    return fallback || (
      <div className="flex items-center justify-center p-6 bg-yellow-50 border border-yellow-200 rounded-lg">
        <div className="text-center">
          <AlertTriangle className="mx-auto h-10 w-10 text-yellow-600 mb-3" />
          <h4 className="text-md font-medium text-yellow-800 mb-2">Permissão Necessária</h4>
          <p className="text-sm text-yellow-700">
            Você não possui permissão para visualizar este conteúdo.
          </p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default ProtectedContent;