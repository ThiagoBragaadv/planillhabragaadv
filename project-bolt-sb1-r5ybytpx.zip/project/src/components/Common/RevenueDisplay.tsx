import React from 'react';
import { DollarSign, Lock, Shield } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface RevenueDisplayProps {
  value: number;
  label?: string;
  className?: string;
  showIcon?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

const RevenueDisplay: React.FC<RevenueDisplayProps> = ({ 
  value, 
  label = 'Faturamento', 
  className = '',
  showIcon = true,
  size = 'md'
}) => {
  const { canViewRevenue } = useAuth();

  const sizeClasses = {
    sm: 'text-sm',
    md: 'text-lg',
    lg: 'text-2xl'
  };

  if (!canViewRevenue()) {
    return (
      <div className={`flex items-center space-x-2 ${className}`}>
        {showIcon && <Lock className="text-gray-400" size={16} />}
        <div className="flex flex-col">
          {label && <span className="text-xs text-gray-500">{label}</span>}
          <div className="flex items-center space-x-2">
            <span className={`font-bold text-gray-400 ${sizeClasses[size]}`}>
              R$ ***.**
            </span>
            <Shield className="text-gray-400" size={14} title="Acesso restrito a administradores" />
          </div>
          <span className="text-xs text-gray-400">Acesso restrito</span>
        </div>
      </div>
    );
  }

  return (
    <div className={`flex items-center space-x-2 ${className}`}>
      {showIcon && <DollarSign className="text-green-600" size={16} />}
      <div className="flex flex-col">
        {label && <span className="text-xs text-gray-600">{label}</span>}
        <span className={`font-bold text-gray-900 ${sizeClasses[size]}`}>
          R$ {value.toLocaleString('pt-BR')}
        </span>
      </div>
    </div>
  );
};

export default RevenueDisplay;