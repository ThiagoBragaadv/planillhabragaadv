export interface Lead {
  id: string;
  name: string;
  email: string;
  phone: string;
  source: string;
  campaign: string;
  status: 'novo' | 'contato' | 'proposta' | 'fechado' | 'perdido';
  assignedTo: string;
  createdAt: string;
  convertedAt?: string;
  value?: number;
}

export interface Contract {
  id: string;
  clientName: string;
  type: string;
  value: number;
  status: 'ativo' | 'concluido' | 'cancelado' | 'desistencia';
  salesPerson: string;
  createdAt: string;
  leadId?: string;
  canceledAt?: string;
  cancelReason?: string;
}

export interface ProcessDeadline {
  id: string;
  processId: string;
  type: 'recurso' | 'exigencia' | 'complementacao' | 'resposta' | 'pericia' | 'audiencia' | 'avaliacao_social';
  description: string;
  dueDate: string;
  status: 'pendente' | 'concluido' | 'vencido';
  priority: 'baixa' | 'media' | 'alta' | 'critica';
  responsibleLawyer: string;
  createdAt: string;
  completedAt?: string;
  notes?: string;
}

export interface Process {
  id: string;
  clientName: string;
  type: 'administrativo' | 'judicial';
  category: string;
  status: 'em_andamento' | 'deferido' | 'negado' | 'judicializado' | 'procedente' | 'improcedente';
  responsibleLawyer: string;
  createdAt: string;
  completedAt?: string;
  documents: Document[];
  deadlines: ProcessDeadline[];
  // New fields for tracking judicial progression
  originProcessId?: string; // ID do processo administrativo original
  judicializedAt?: string; // Data da judicialização
  clientDecision?: 'aceita_judicial' | 'desiste_judicial' | 'pendente'; // Decisão do cliente
  judicialDecisionDate?: string; // Data da decisão sobre judicialização
  judicialDecisionReason?: string; // Motivo da decisão
}

export interface Document {
  id: string;
  name: string;
  status: 'pendente' | 'completo' | 'revisado';
  uploadedAt?: string;
  processId: string;
}

export interface SalesPerson {
  id: string;
  name: string;
  email: string;
  role: 'vendedor' | 'gestor' | 'admin';
  avatar?: string;
}

export interface DashboardStats {
  totalLeads: number;
  totalContracts: number;
  conversionRate: number;
  totalRevenue: number;
  activeProcesses: number;
  adminApprovalRate: number;
  judicialSuccessRate: number;
  pendingDeadlines: number;
  overdueDeadlines: number;
  contractAbandonmentRate: number;
  abandonedContracts: number;
  // New metrics for process entries
  currentMonthAdminEntries: number;
  currentMonthJudicialEntries: number;
  totalAdminProcesses: number;
  totalJudicialProcesses: number;
  // New metrics for judicial tracking
  adminNegadosJudicializados: number;
  clientesDesistiramJudicial: number;
  taxaJudicializacaoNegados: number;
  taxaDesistenciaJudicial: number;
}

export interface MonthlyProcessEntry {
  month: string;
  administrative: number;
  judicial: number;
  total: number;
}

// New interface for judicial tracking
export interface JudicialTrackingData {
  adminNegados: number;
  judicializados: number;
  clientesAceitaram: number;
  clientesDesistiram: number;
  pendentesDecisao: number;
}