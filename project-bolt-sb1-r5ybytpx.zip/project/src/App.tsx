import React, { useState } from 'react';
import Sidebar from './components/Layout/Sidebar';
import Header from './components/Layout/Header';
import Dashboard from './pages/Dashboard';
import LeadsContracts from './pages/LeadsContracts';
import Processes from './pages/Processes';
import Documents from './pages/Documents';
import Team from './pages/Team';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import { AuthProvider } from './context/AuthContext';

function App() {
  const [activeSection, setActiveSection] = useState('dashboard');

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return <Dashboard />;
      case 'leads':
        return <LeadsContracts />;
      case 'processes':
        return <Processes />;
      case 'documents':
        return <Documents />;
      case 'team':
        return <Team />;
      case 'reports':
        return <Reports />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <AuthProvider>
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />
        <div className="flex-1 flex flex-col">
          <Header />
          <main className="flex-1">
            {renderContent()}
          </main>
        </div>
      </div>
    </AuthProvider>
  );
}

export default App;