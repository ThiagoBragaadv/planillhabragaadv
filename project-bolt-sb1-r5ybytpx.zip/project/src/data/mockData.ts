import { Lead, Contract, Process, SalesPerson, DashboardStats, ProcessDeadline, JudicialTrackingData } from '../types';

export const mockSalesTeam: SalesPerson[] = [
  { id: '1', name: 'Maria Silva', email: 'maria@braga.adv.br', role: 'vendedor' },
  { id: '2', name: 'João Santos', email: 'joao@braga.adv.br', role: 'vendedor' },
  { id: '3', name: 'Ana Costa', email: 'ana@braga.adv.br', role: 'gestor' },
  { id: '4', name: 'Carlos Braga', email: 'carlos@braga.adv.br', role: 'admin' },
];

// Mock users for settings page
export const mockUsers = [
  {
    id: '1',
    name: 'Carlos Braga',
    email: 'carlos@braga.adv.br',
    phone: '(11) 99999-0001',
    role: 'admin' as const,
    department: 'administrativo' as const,
    status: 'ativo' as const,
    createdAt: '2024-01-01',
    lastLogin: '2024-02-28',
    permissions: ['view_dashboard', 'manage_leads', 'manage_contracts', 'manage_processes', 'view_documents', 'upload_documents', 'view_reports', 'export_data', 'manage_team', 'system_settings']
  },
  {
    id: '2',
    name: 'Ana Costa',
    email: 'ana@braga.adv.br',
    phone: '(11) 99999-0002',
    role: 'gestor' as const,
    department: 'vendas' as const,
    status: 'ativo' as const,
    createdAt: '2024-01-05',
    lastLogin: '2024-02-27',
    permissions: ['view_dashboard', 'manage_leads', 'manage_contracts', 'view_documents', 'view_reports', 'export_data', 'manage_team']
  },
  {
    id: '3',
    name: 'Maria Silva',
    email: 'maria@braga.adv.br',
    phone: '(11) 99999-0003',
    role: 'vendedor' as const,
    department: 'vendas' as const,
    status: 'ativo' as const,
    createdAt: '2024-01-10',
    lastLogin: '2024-02-28',
    permissions: ['view_dashboard', 'manage_leads', 'manage_contracts', 'view_documents']
  },
  {
    id: '4',
    name: 'João Santos',
    email: 'joao@braga.adv.br',
    phone: '(11) 99999-0004',
    role: 'vendedor' as const,
    department: 'vendas' as const,
    status: 'ativo' as const,
    createdAt: '2024-01-15',
    lastLogin: '2024-02-26',
    permissions: ['view_dashboard', 'manage_leads', 'manage_contracts', 'view_documents']
  },
  {
    id: '5',
    name: 'Dr. Roberto Lima',
    email: 'roberto@braga.adv.br',
    phone: '(11) 99999-0005',
    role: 'advogado' as const,
    department: 'juridico' as const,
    status: 'ativo' as const,
    createdAt: '2024-01-20',
    lastLogin: '2024-02-28',
    permissions: ['view_dashboard', 'manage_processes', 'view_documents', 'upload_documents', 'view_reports']
  },
  {
    id: '6',
    name: 'Dra. Patricia Oliveira',
    email: 'patricia@braga.adv.br',
    phone: '(11) 99999-0006',
    role: 'advogado' as const,
    department: 'juridico' as const,
    status: 'ativo' as const,
    createdAt: '2024-02-01',
    lastLogin: '2024-02-27',
    permissions: ['view_dashboard', 'manage_processes', 'view_documents', 'upload_documents', 'view_reports']
  },
  {
    id: '7',
    name: 'Fernanda Souza',
    email: 'fernanda@braga.adv.br',
    phone: '(11) 99999-0007',
    role: 'assistente_juridico' as const,
    department: 'juridico' as const,
    status: 'ativo' as const,
    createdAt: '2024-02-05',
    lastLogin: '2024-02-25',
    permissions: ['view_dashboard', 'view_documents', 'upload_documents', 'manage_processes']
  },
  {
    id: '8',
    name: 'Lucas Pereira',
    email: 'lucas@braga.adv.br',
    phone: '(11) 99999-0008',
    role: 'assistente_administrativo' as const,
    department: 'administrativo' as const,
    status: 'ativo' as const,
    createdAt: '2024-01-25',
    lastLogin: '2024-02-28',
    permissions: ['view_dashboard', 'view_documents', 'upload_documents', 'manage_processes']
  },
  {
    id: '9',
    name: 'Carla Mendes',
    email: 'carla@braga.adv.br',
    phone: '(11) 99999-0009',
    role: 'coordenador_vendas' as const,
    department: 'vendas' as const,
    status: 'ativo' as const,
    createdAt: '2024-02-10',
    lastLogin: '2024-02-27',
    permissions: ['view_dashboard', 'manage_leads', 'manage_contracts', 'view_documents', 'view_reports', 'manage_team']
  },
  {
    id: '10',
    name: 'Ricardo Santos',
    email: 'ricardo@braga.adv.br',
    phone: '(11) 99999-0010',
    role: 'analista_processos' as const,
    department: 'administrativo' as const,
    status: 'inativo' as const,
    createdAt: '2024-01-30',
    lastLogin: '2024-02-15',
    permissions: ['view_dashboard', 'view_documents', 'manage_processes']
  }
];

export const mockLeads: Lead[] = [
  {
    id: '1',
    name: 'Pedro Oliveira',
    email: 'pedro@email.com',
    phone: '(11) 99999-9999',
    source: 'Google Ads',
    campaign: 'INSS 2024',
    status: 'fechado',
    assignedTo: 'Maria Silva',
    createdAt: '2024-01-15',
    convertedAt: '2024-01-20',
    value: 3500
  },
  {
    id: '2',
    name: 'Lucia Fernandes',
    email: 'lucia@email.com',
    phone: '(11) 88888-8888',
    source: 'Facebook',
    campaign: 'Trabalhista 2024',
    status: 'proposta',
    assignedTo: 'João Santos',
    createdAt: '2024-01-18',
  },
  {
    id: '3',
    name: 'Roberto Lima',
    email: 'roberto@email.com',
    phone: '(11) 77777-7777',
    source: 'Indicação',
    campaign: 'Previdenciário',
    status: 'novo',
    assignedTo: 'Maria Silva',
    createdAt: '2024-01-20',
  }
];

export const mockContracts: Contract[] = [
  {
    id: '1',
    clientName: 'Pedro Oliveira',
    type: 'Aposentadoria por Invalidez',
    value: 3500,
    status: 'ativo',
    salesPerson: 'Maria Silva',
    createdAt: '2024-01-20',
    leadId: '1'
  },
  {
    id: '2',
    clientName: 'Marcos Souza',
    type: 'Auxílio Doença',
    value: 2800,
    status: 'ativo',
    salesPerson: 'João Santos',
    createdAt: '2024-01-10',
  },
  {
    id: '3',
    clientName: 'Carla Santos',
    type: 'BPC/LOAS',
    value: 2200,
    status: 'ativo',
    salesPerson: 'Maria Silva',
    createdAt: '2024-02-05',
  },
  {
    id: '4',
    clientName: 'Fernando Costa',
    type: 'Aposentadoria Especial',
    value: 4200,
    status: 'desistencia',
    salesPerson: 'João Santos',
    createdAt: '2024-01-25',
    canceledAt: '2024-02-10',
    cancelReason: 'Cliente desistiu após assinar - mudança de ideia'
  },
  {
    id: '5',
    clientName: 'Ana Pereira',
    type: 'Auxílio Doença',
    value: 2500,
    status: 'desistencia',
    salesPerson: 'Maria Silva',
    createdAt: '2024-02-01',
    canceledAt: '2024-02-15',
    cancelReason: 'Cliente encontrou outro advogado'
  },
  {
    id: '6',
    clientName: 'Ricardo Alves',
    type: 'Aposentadoria por Tempo',
    value: 3800,
    status: 'cancelado',
    salesPerson: 'Ana Costa',
    createdAt: '2024-01-30',
    canceledAt: '2024-02-12',
    cancelReason: 'Não apresentou documentação necessária'
  }
];

export const mockDeadlines: ProcessDeadline[] = [
  {
    id: '1',
    processId: '1',
    type: 'exigencia',
    description: 'Responder exigência do INSS - Documentos médicos complementares',
    dueDate: '2024-02-28',
    status: 'pendente',
    priority: 'alta',
    responsibleLawyer: 'Dr. Braga',
    createdAt: '2024-02-15'
  },
  {
    id: '2',
    processId: '2',
    type: 'recurso',
    description: 'Prazo para recurso administrativo',
    dueDate: '2024-02-25',
    status: 'vencido',
    priority: 'critica',
    responsibleLawyer: 'Dra. Costa',
    createdAt: '2024-02-10'
  },
  {
    id: '3',
    processId: '3',
    type: 'complementacao',
    description: 'Envio de PPP atualizado',
    dueDate: '2024-03-05',
    status: 'pendente',
    priority: 'media',
    responsibleLawyer: 'Dr. Braga',
    createdAt: '2024-02-20'
  },
  {
    id: '4',
    processId: '1',
    type: 'pericia',
    description: 'Agendamento de perícia médica',
    dueDate: '2024-03-10',
    status: 'pendente',
    priority: 'alta',
    responsibleLawyer: 'Dr. Braga',
    createdAt: '2024-02-22'
  },
  {
    id: '5',
    processId: '4',
    type: 'avaliacao_social',
    description: 'Agendamento da avaliação social domiciliar para BPC/LOAS',
    dueDate: '2024-03-01',
    status: 'pendente',
    priority: 'alta',
    responsibleLawyer: 'Dra. Costa',
    createdAt: '2024-02-18',
    notes: 'Cliente deve estar presente no domicílio. Verificar documentos de renda familiar.'
  },
  {
    id: '6',
    processId: '4',
    type: 'complementacao',
    description: 'Envio de declaração de composição familiar atualizada',
    dueDate: '2024-02-29',
    status: 'pendente',
    priority: 'media',
    responsibleLawyer: 'Dra. Costa',
    createdAt: '2024-02-20'
  },
  {
    id: '7',
    processId: '5',
    type: 'avaliacao_social',
    description: 'Reagendamento de avaliação social - primeira visita não realizada',
    dueDate: '2024-02-26',
    status: 'vencido',
    priority: 'critica',
    responsibleLawyer: 'Dr. Braga',
    createdAt: '2024-02-12',
    notes: 'Cliente não estava presente na primeira visita. Reagendar urgentemente.'
  }
];

export const mockProcesses: Process[] = [
  {
    id: '1',
    clientName: 'Pedro Oliveira',
    type: 'administrativo',
    category: 'Aposentadoria por Invalidez',
    status: 'deferido',
    responsibleLawyer: 'Dr. Braga',
    createdAt: '2024-01-22',
    completedAt: '2024-02-15',
    documents: [
      { id: '1', name: 'Laudo Médico', status: 'completo', uploadedAt: '2024-01-22', processId: '1' },
      { id: '2', name: 'Documentos Pessoais', status: 'completo', uploadedAt: '2024-01-22', processId: '1' }
    ],
    deadlines: mockDeadlines.filter(d => d.processId === '1')
  },
  {
    id: '2',
    clientName: 'Marcos Souza',
    type: 'administrativo',
    category: 'Auxílio Doença',
    status: 'negado',
    responsibleLawyer: 'Dra. Costa',
    createdAt: '2024-01-12',
    completedAt: '2024-02-10',
    documents: [
      { id: '3', name: 'Atestados Médicos', status: 'completo', uploadedAt: '2024-01-12', processId: '2' },
      { id: '4', name: 'CTPS', status: 'revisado', uploadedAt: '2024-01-12', processId: '2' }
    ],
    deadlines: mockDeadlines.filter(d => d.processId === '2')
  },
  // Processo judicial originado de administrativo negado
  {
    id: '2j',
    clientName: 'Marcos Souza',
    type: 'judicial',
    category: 'Auxílio Doença',
    status: 'em_andamento',
    responsibleLawyer: 'Dra. Costa',
    createdAt: '2024-02-15',
    originProcessId: '2',
    judicializedAt: '2024-02-15',
    clientDecision: 'aceita_judicial',
    judicialDecisionDate: '2024-02-12',
    documents: [
      { id: '3j', name: 'Petição Inicial', status: 'completo', uploadedAt: '2024-02-15', processId: '2j' },
      { id: '4j', name: 'Documentos Administrativos', status: 'completo', uploadedAt: '2024-02-15', processId: '2j' }
    ],
    deadlines: []
  },
  {
    id: '3',
    clientName: 'Ana Rodrigues',
    type: 'judicial',
    category: 'Aposentadoria Especial',
    status: 'procedente',
    responsibleLawyer: 'Dr. Braga',
    createdAt: '2024-01-15',
    completedAt: '2024-02-20',
    documents: [
      { id: '5', name: 'PPP', status: 'completo', uploadedAt: '2024-01-15', processId: '3' },
      { id: '6', name: 'Laudos Técnicos', status: 'completo', uploadedAt: '2024-02-01', processId: '3' }
    ],
    deadlines: mockDeadlines.filter(d => d.processId === '3')
  },
  {
    id: '4',
    clientName: 'Carla Santos',
    type: 'administrativo',
    category: 'BPC/LOAS',
    status: 'em_andamento',
    responsibleLawyer: 'Dra. Costa',
    createdAt: '2024-02-05',
    documents: [
      { id: '7', name: 'Laudo Médico', status: 'completo', uploadedAt: '2024-02-05', processId: '4' },
      { id: '8', name: 'Declaração de Composição Familiar', status: 'pendente', processId: '4' },
      { id: '9', name: 'Comprovantes de Renda', status: 'completo', uploadedAt: '2024-02-06', processId: '4' }
    ],
    deadlines: mockDeadlines.filter(d => d.processId === '4')
  },
  {
    id: '5',
    clientName: 'José Silva',
    type: 'administrativo',
    category: 'BPC/LOAS',
    status: 'negado',
    responsibleLawyer: 'Dr. Braga',
    createdAt: '2024-02-10',
    completedAt: '2024-03-01',
    clientDecision: 'desiste_judicial',
    judicialDecisionDate: '2024-03-05',
    judicialDecisionReason: 'Cliente não quer prosseguir com ação judicial devido aos custos',
    documents: [
      { id: '10', name: 'Laudo Médico', status: 'completo', uploadedAt: '2024-02-10', processId: '5' },
      { id: '11', name: 'Documentos Pessoais', status: 'completo', uploadedAt: '2024-02-10', processId: '5' }
    ],
    deadlines: mockDeadlines.filter(d => d.processId === '5')
  },
  {
    id: '6',
    clientName: 'Roberto Santos',
    type: 'administrativo',
    category: 'Auxílio Doença',
    status: 'negado',
    responsibleLawyer: 'Dra. Costa',
    createdAt: '2024-01-08',
    completedAt: '2024-02-18',
    clientDecision: 'pendente',
    documents: [
      { id: '12', name: 'Atestados Médicos', status: 'completo', uploadedAt: '2024-01-08', processId: '6' },
      { id: '13', name: 'Perícia Administrativa', status: 'completo', uploadedAt: '2024-02-01', processId: '6' }
    ],
    deadlines: []
  },
  // Processo judicial originado de administrativo negado
  {
    id: '6j',
    clientName: 'Roberto Santos',
    type: 'judicial',
    category: 'Auxílio Doença',
    status: 'procedente',
    responsibleLawyer: 'Dra. Costa',
    createdAt: '2024-02-25',
    completedAt: '2024-03-15',
    originProcessId: '6',
    judicializedAt: '2024-02-25',
    clientDecision: 'aceita_judicial',
    judicialDecisionDate: '2024-02-20',
    documents: [
      { id: '12j', name: 'Petição Inicial', status: 'completo', uploadedAt: '2024-02-25', processId: '6j' },
      { id: '13j', name: 'Perícia Judicial', status: 'completo', uploadedAt: '2024-03-01', processId: '6j' }
    ],
    deadlines: []
  },
  {
    id: '7',
    clientName: 'Maria Fernandes',
    type: 'administrativo',
    category: 'Aposentadoria por Tempo',
    status: 'negado',
    responsibleLawyer: 'Dr. Braga',
    createdAt: '2024-01-20',
    completedAt: '2024-02-25',
    clientDecision: 'desiste_judicial',
    judicialDecisionDate: '2024-02-28',
    judicialDecisionReason: 'Cliente preferiu aguardar completar idade para aposentadoria por idade',
    documents: [
      { id: '14', name: 'CTPS', status: 'completo', uploadedAt: '2024-01-20', processId: '7' },
      { id: '15', name: 'Certidões de Tempo', status: 'completo', uploadedAt: '2024-01-22', processId: '7' }
    ],
    deadlines: []
  },
  {
    id: '8',
    clientName: 'Carlos Lima',
    type: 'judicial',
    category: 'BPC/LOAS',
    status: 'em_andamento',
    responsibleLawyer: 'Dra. Costa',
    createdAt: '2024-02-01',
    documents: [
      { id: '16', name: 'Laudo Social', status: 'completo', uploadedAt: '2024-02-01', processId: '8' },
      { id: '17', name: 'Documentos Médicos', status: 'pendente', processId: '8' }
    ],
    deadlines: []
  },
  {
    id: '9',
    clientName: 'Lucia Oliveira',
    type: 'judicial',
    category: 'Aposentadoria Especial',
    status: 'procedente',
    responsibleLawyer: 'Dr. Braga',
    createdAt: '2024-01-25',
    completedAt: '2024-02-28',
    documents: [
      { id: '18', name: 'PPP Completo', status: 'completo', uploadedAt: '2024-01-25', processId: '9' },
      { id: '19', name: 'Laudos Ambientais', status: 'completo', uploadedAt: '2024-02-05', processId: '9' }
    ],
    deadlines: []
  },
  {
    id: '10',
    clientName: 'Antonio Costa',
    type: 'administrativo',
    category: 'Auxílio Doença',
    status: 'negado',
    responsibleLawyer: 'Dra. Costa',
    createdAt: '2024-01-30',
    completedAt: '2024-02-22',
    clientDecision: 'pendente',
    documents: [
      { id: '20', name: 'Relatórios Médicos', status: 'completo', uploadedAt: '2024-01-30', processId: '10' },
      { id: '21', name: 'Perícia Administrativa', status: 'completo', uploadedAt: '2024-02-10', processId: '10' }
    ],
    deadlines: []
  },
  // Adicionando mais processos para análise mensal
  {
    id: '11',
    clientName: 'Sandra Pereira',
    type: 'administrativo',
    category: 'Aposentadoria por Idade',
    status: 'deferido',
    responsibleLawyer: 'Dr. Braga',
    createdAt: '2024-03-05',
    completedAt: '2024-03-20',
    documents: [],
    deadlines: []
  },
  {
    id: '12',
    clientName: 'Paulo Mendes',
    type: 'judicial',
    category: 'Auxílio Acidente',
    status: 'em_andamento',
    responsibleLawyer: 'Dra. Costa',
    createdAt: '2024-03-08',
    documents: [],
    deadlines: []
  },
  {
    id: '13',
    clientName: 'Fernanda Lima',
    type: 'administrativo',
    category: 'Salário Maternidade',
    status: 'em_andamento',
    responsibleLawyer: 'Dr. Braga',
    createdAt: '2024-03-12',
    documents: [],
    deadlines: []
  },
  {
    id: '14',
    clientName: 'Ricardo Souza',
    type: 'judicial',
    category: 'Aposentadoria por Invalidez',
    status: 'em_andamento',
    responsibleLawyer: 'Dra. Costa',
    createdAt: '2024-03-15',
    documents: [],
    deadlines: []
  },
  {
    id: '15',
    clientName: 'Mariana Santos',
    type: 'administrativo',
    category: 'Auxílio Doença',
    status: 'negado',
    responsibleLawyer: 'Dr. Braga',
    createdAt: '2024-03-18',
    completedAt: '2024-03-25',
    clientDecision: 'aceita_judicial',
    judicialDecisionDate: '2024-03-26',
    documents: [],
    deadlines: []
  },
  // Processo judicial originado do processo 15
  {
    id: '15j',
    clientName: 'Mariana Santos',
    type: 'judicial',
    category: 'Auxílio Doença',
    status: 'em_andamento',
    responsibleLawyer: 'Dr. Braga',
    createdAt: '2024-03-28',
    originProcessId: '15',
    judicializedAt: '2024-03-28',
    clientDecision: 'aceita_judicial',
    judicialDecisionDate: '2024-03-26',
    documents: [],
    deadlines: []
  }
];

// Function to get processes by month and year
export const getProcessesByMonth = (month: number, year: number) => {
  return mockProcesses.filter(process => {
    const processDate = new Date(process.createdAt);
    return processDate.getMonth() === month && processDate.getFullYear() === year;
  });
};

// Function to get monthly process entries data
export const getMonthlyProcessEntries = () => {
  const months = [
    { name: 'Jan', value: 1, year: 2024 },
    { name: 'Fev', value: 2, year: 2024 },
    { name: 'Mar', value: 3, year: 2024 },
    { name: 'Abr', value: 4, year: 2024 },
    { name: 'Mai', value: 5, year: 2024 },
    { name: 'Jun', value: 6, year: 2024 },
  ];

  return months.map(month => {
    const monthProcesses = getProcessesByMonth(month.value - 1, month.year);
    const adminProcesses = monthProcesses.filter(p => p.type === 'administrativo');
    const judicialProcesses = monthProcesses.filter(p => p.type === 'judicial');
    
    return {
      month: month.name,
      administrative: adminProcesses.length,
      judicial: judicialProcesses.length,
      total: monthProcesses.length
    };
  });
};

// Function to get judicial tracking data
export const getJudicialTrackingData = (): JudicialTrackingData => {
  // Processos administrativos negados
  const adminNegados = mockProcesses.filter(p => 
    p.type === 'administrativo' && p.status === 'negado'
  );

  // Processos que foram judicializados (têm originProcessId)
  const judicializados = mockProcesses.filter(p => 
    p.type === 'judicial' && p.originProcessId
  );

  // Clientes que aceitaram judicialização
  const clientesAceitaram = adminNegados.filter(p => 
    p.clientDecision === 'aceita_judicial'
  );

  // Clientes que desistiram da judicialização
  const clientesDesistiram = adminNegados.filter(p => 
    p.clientDecision === 'desiste_judicial'
  );

  // Clientes com decisão pendente
  const pendentesDecisao = adminNegados.filter(p => 
    p.clientDecision === 'pendente' || !p.clientDecision
  );

  return {
    adminNegados: adminNegados.length,
    judicializados: judicializados.length,
    clientesAceitaram: clientesAceitaram.length,
    clientesDesistiram: clientesDesistiram.length,
    pendentesDecisao: pendentesDecisao.length
  };
};

// Calculate metrics
const totalSignedContracts = mockContracts.length;
const abandonedContracts = mockContracts.filter(c => c.status === 'desistencia').length;
const abandonmentRate = totalSignedContracts > 0 ? (abandonedContracts / totalSignedContracts) * 100 : 0;

// Calculate judicial approval rate
const judicialProcesses = mockProcesses.filter(p => p.type === 'judicial');
const completedJudicialProcesses = judicialProcesses.filter(p => p.status === 'procedente' || p.status === 'improcedente');
const procedenteJudicialProcesses = judicialProcesses.filter(p => p.status === 'procedente');
const judicialApprovalRate = completedJudicialProcesses.length > 0 ? 
  (procedenteJudicialProcesses.length / completedJudicialProcesses.length) * 100 : 0;

// Calculate administrative approval rate
const adminProcesses = mockProcesses.filter(p => p.type === 'administrativo');
const completedAdminProcesses = adminProcesses.filter(p => p.status === 'deferido' || p.status === 'negado');
const deferredAdminProcesses = adminProcesses.filter(p => p.status === 'deferido');
const adminApprovalRate = completedAdminProcesses.length > 0 ? 
  (deferredAdminProcesses.length / completedAdminProcesses.length) * 100 : 0;

// Calculate current month entries
const currentDate = new Date();
const currentMonth = currentDate.getMonth();
const currentYear = currentDate.getFullYear();
const currentMonthProcesses = getProcessesByMonth(currentMonth, currentYear);
const currentMonthAdminEntries = currentMonthProcesses.filter(p => p.type === 'administrativo').length;
const currentMonthJudicialEntries = currentMonthProcesses.filter(p => p.type === 'judicial').length;

// Calculate judicial tracking metrics
const judicialTrackingData = getJudicialTrackingData();
const taxaJudicializacaoNegados = judicialTrackingData.adminNegados > 0 ? 
  (judicialTrackingData.judicializados / judicialTrackingData.adminNegados) * 100 : 0;
const taxaDesistenciaJudicial = judicialTrackingData.adminNegados > 0 ? 
  (judicialTrackingData.clientesDesistiram / judicialTrackingData.adminNegados) * 100 : 0;

export const mockStats: DashboardStats = {
  totalLeads: 45,
  totalContracts: totalSignedContracts,
  conversionRate: 62.2,
  totalRevenue: mockContracts.filter(c => c.status === 'ativo' || c.status === 'concluido').reduce((sum, c) => sum + c.value, 0),
  activeProcesses: mockProcesses.filter(p => p.status === 'em_andamento').length,
  adminApprovalRate: Number(adminApprovalRate.toFixed(1)),
  judicialSuccessRate: Number(judicialApprovalRate.toFixed(1)),
  pendingDeadlines: mockDeadlines.filter(d => d.status === 'pendente').length,
  overdueDeadlines: mockDeadlines.filter(d => d.status === 'vencido').length,
  contractAbandonmentRate: Number(abandonmentRate.toFixed(1)),
  abandonedContracts: abandonedContracts,
  // New metrics for process entries
  currentMonthAdminEntries: currentMonthAdminEntries,
  currentMonthJudicialEntries: currentMonthJudicialEntries,
  totalAdminProcesses: adminProcesses.length,
  totalJudicialProcesses: judicialProcesses.length,
  // New metrics for judicial tracking
  adminNegadosJudicializados: judicialTrackingData.judicializados,
  clientesDesistiramJudicial: judicialTrackingData.clientesDesistiram,
  taxaJudicializacaoNegados: Number(taxaJudicializacaoNegados.toFixed(1)),
  taxaDesistenciaJudicial: Number(taxaDesistenciaJudicial.toFixed(1))
};