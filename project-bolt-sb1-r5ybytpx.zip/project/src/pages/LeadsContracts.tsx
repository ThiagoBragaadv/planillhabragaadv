import React, { useState } from 'react';
import { Plus, Filter, Download, Eye, AlertTriangle, FileSpreadsheet, User, BarChart3, Calendar } from 'lucide-react';
import DataTable from '../components/Tables/DataTable';
import MetricCard from '../components/Charts/MetricCard';
import BarChart from '../components/Charts/BarChart';
import PieChart from '../components/Charts/PieChart';
import ExcelImport from '../components/Import/ExcelImport';
import ManualClientForm from '../components/Forms/ManualClientForm';
import MetaAdsIntegration from '../components/Analytics/MetaAdsIntegration';
import RevenueDisplay from '../components/Common/RevenueDisplay';
import ProtectedContent from '../components/Common/ProtectedContent';
import DateFilter from '../components/Common/DateFilter';
import { mockLeads, mockContracts } from '../data/mockData';
import { Target, DollarSign, TrendingUp, Users, UserX } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface ImportedClient {
  nome: string;
  email: string;
  telefone: string;
  tipoProcesso: string;
  status: string;
  valorContrato?: number;
  dataContrato?: string;
  origem?: string;
  observacoes?: string;
}

interface ManualClient {
  nome: string;
  email: string;
  telefone: string;
  cpf: string;
  endereco: string;
  cidade: string;
  estado: string;
  cep: string;
  dataNascimento: string;
  estadoCivil: string;
  profissao: string;
  tipoProcesso: string;
  status: string;
  origem: string;
  campanha?: string;
  valorContrato?: number;
  dataContrato?: string;
  observacoes?: string;
  vendedorResponsavel: string;
  prioridade: 'baixa' | 'media' | 'alta';
  comoConheceu: string;
  interesseEspecifico: string;
}

const LeadsContracts: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'leads' | 'contracts' | 'imported' | 'manual' | 'meta_ads'>('leads');
  const [showImport, setShowImport] = useState(false);
  const [showManualForm, setShowManualForm] = useState(false);
  const [showDateFilter, setShowDateFilter] = useState(false);
  const [startDate, setStartDate] = useState('2024-01-01');
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedPreset, setSelectedPreset] = useState('this_month');
  const [importedClients, setImportedClients] = useState<ImportedClient[]>([]);
  const [manualClients, setManualClients] = useState<ManualClient[]>([]);
  const [metaAdsLeads, setMetaAdsLeads] = useState<any[]>([]);
  const [showImportSuccess, setShowImportSuccess] = useState(false);
  const [showManualSuccess, setShowManualSuccess] = useState(false);
  const [showMetaAdsSuccess, setShowMetaAdsSuccess] = useState(false);
  const { canViewRevenue } = useAuth();

  // Filter data by date range
  const filterByDateRange = (data: any[], dateField: string) => {
    return data.filter(item => {
      const itemDate = new Date(item[dateField]);
      const start = new Date(startDate);
      const end = new Date(endDate);
      return itemDate >= start && itemDate <= end;
    });
  };

  const filteredLeads = filterByDateRange(mockLeads, 'createdAt');
  const filteredContracts = filterByDateRange(mockContracts, 'createdAt');

  const leadColumns = [
    { key: 'name', label: 'Nome', sortable: true },
    { key: 'email', label: 'E-mail' },
    { key: 'source', label: 'Origem', sortable: true },
    { key: 'campaign', label: 'Campanha' },
    { key: 'assignedTo', label: 'Responsável' },
    { 
      key: 'status', 
      label: 'Status',
      render: (status: string) => {
        const statusColors = {
          novo: 'bg-blue-100 text-blue-800',
          contato: 'bg-yellow-100 text-yellow-800',
          proposta: 'bg-purple-100 text-purple-800',
          fechado: 'bg-green-100 text-green-800',
          perdido: 'bg-red-100 text-red-800'
        };
        return (
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[status as keyof typeof statusColors]}`}>
            {status}
          </span>
        );
      }
    },
    { 
      key: 'createdAt', 
      label: 'Data', 
      sortable: true,
      render: (date: string) => new Date(date).toLocaleDateString('pt-BR')
    },
    {
      key: 'actions',
      label: 'Ações',
      render: () => (
        <div className="flex space-x-2">
          <button className="text-blue-600 hover:text-blue-800">
            <Eye size={16} />
          </button>
        </div>
      )
    }
  ];

  const contractColumns = [
    { key: 'clientName', label: 'Cliente', sortable: true },
    { key: 'type', label: 'Tipo de Contrato' },
    { 
      key: 'value', 
      label: 'Valor',
      render: (value: number) => (
        <ProtectedContent requiredRole="admin" showFallback={false}>
          <span>R$ {value.toLocaleString('pt-BR')}</span>
        </ProtectedContent>
      )
    },
    { key: 'salesPerson', label: 'Vendedor' },
    { 
      key: 'status', 
      label: 'Status',
      render: (status: string) => {
        const statusColors = {
          ativo: 'bg-green-100 text-green-800',
          concluido: 'bg-blue-100 text-blue-800',
          cancelado: 'bg-gray-100 text-gray-800',
          desistencia: 'bg-red-100 text-red-800'
        };
        const statusLabels = {
          ativo: 'Ativo',
          concluido: 'Concluído',
          cancelado: 'Cancelado',
          desistencia: 'Desistência'
        };
        return (
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[status as keyof typeof statusColors]}`}>
            {statusLabels[status as keyof typeof statusLabels]}
          </span>
        );
      }
    },
    { 
      key: 'createdAt', 
      label: 'Data', 
      sortable: true,
      render: (date: string) => new Date(date).toLocaleDateString('pt-BR')
    },
    {
      key: 'cancelReason',
      label: 'Observações',
      render: (reason: string, row: any) => {
        if (row.status === 'desistencia' || row.status === 'cancelado') {
          return (
            <span className="text-xs text-gray-600" title={reason}>
              {reason ? (reason.length > 30 ? `${reason.substring(0, 30)}...` : reason) : '-'}
            </span>
          );
        }
        return '-';
      }
    }
  ];

  // Columns for imported clients table
  const importedClientColumns = [
    { key: 'nome', label: 'Nome', sortable: true },
    { key: 'email', label: 'E-mail' },
    { key: 'telefone', label: 'Telefone' },
    { key: 'tipoProcesso', label: 'Tipo de Processo' },
    { 
      key: 'status', 
      label: 'Status',
      render: (status: string) => {
        const statusColors = {
          ativo: 'bg-green-100 text-green-800',
          em_andamento: 'bg-yellow-100 text-yellow-800',
          novo: 'bg-blue-100 text-blue-800',
          concluido: 'bg-blue-100 text-blue-800'
        };
        return (
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[status as keyof typeof statusColors] || 'bg-gray-100 text-gray-800'}`}>
            {status}
          </span>
        );
      }
    },
    { 
      key: 'valorContrato', 
      label: 'Valor',
      render: (value: number) => (
        <ProtectedContent requiredRole="admin" showFallback={false}>
          <span>{value ? `R$ ${value.toLocaleString('pt-BR')}` : '-'}</span>
        </ProtectedContent>
      )
    },
    { key: 'origem', label: 'Origem' },
    {
      key: 'actions',
      label: 'Ações',
      render: () => (
        <div className="flex space-x-2">
          <button className="text-blue-600 hover:text-blue-800">
            <Eye size={16} />
          </button>
        </div>
      )
    }
  ];

  // Columns for manual clients table
  const manualClientColumns = [
    { key: 'nome', label: 'Nome', sortable: true },
    { key: 'email', label: 'E-mail' },
    { key: 'telefone', label: 'Telefone' },
    { key: 'tipoProcesso', label: 'Tipo de Processo' },
    { 
      key: 'status', 
      label: 'Status',
      render: (status: string) => {
        const statusColors = {
          novo: 'bg-blue-100 text-blue-800',
          contato: 'bg-yellow-100 text-yellow-800',
          proposta: 'bg-purple-100 text-purple-800',
          ativo: 'bg-green-100 text-green-800',
          em_andamento: 'bg-yellow-100 text-yellow-800'
        };
        return (
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[status as keyof typeof statusColors] || 'bg-gray-100 text-gray-800'}`}>
            {status}
          </span>
        );
      }
    },
    { 
      key: 'prioridade', 
      label: 'Prioridade',
      render: (prioridade: string) => {
        const priorityColors = {
          baixa: 'bg-gray-100 text-gray-800',
          media: 'bg-yellow-100 text-yellow-800',
          alta: 'bg-red-100 text-red-800'
        };
        return (
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${priorityColors[prioridade as keyof typeof priorityColors]}`}>
            {prioridade}
          </span>
        );
      }
    },
    { key: 'vendedorResponsavel', label: 'Vendedor' },
    { 
      key: 'valorContrato', 
      label: 'Valor',
      render: (value: number) => (
        <ProtectedContent requiredRole="admin" showFallback={false}>
          <span>{value ? `R$ ${value.toLocaleString('pt-BR')}` : '-'}</span>
        </ProtectedContent>
      )
    },
    {
      key: 'actions',
      label: 'Ações',
      render: () => (
        <div className="flex space-x-2">
          <button className="text-blue-600 hover:text-blue-800">
            <Eye size={16} />
          </button>
        </div>
      )
    }
  ];

  const conversionBySource = [
    { label: 'Google Ads', value: 35 },
    { label: 'Facebook', value: 28 },
    { label: 'Indicação', value: 22 },
    { label: 'Instagram', value: 15 },
  ];

  const contractsByType = [
    { label: 'Aposentadoria', value: 12 },
    { label: 'Auxílio Doença', value: 8 },
    { label: 'Trabalhista', value: 5 },
    { label: 'BPC/LOAS', value: 3 },
  ];

  const contractStatusData = [
    { label: 'Ativos', value: filteredContracts.filter(c => c.status === 'ativo').length, color: '#10B981' },
    { label: 'Concluídos', value: filteredContracts.filter(c => c.status === 'concluido').length, color: '#3B82F6' },
    { label: 'Desistências', value: filteredContracts.filter(c => c.status === 'desistencia').length, color: '#EF4444' },
    { label: 'Cancelados', value: filteredContracts.filter(c => c.status === 'cancelado').length, color: '#6B7280' },
  ];

  // Calculate metrics based on filtered data
  const totalSignedContracts = filteredContracts.length;
  const abandonedContracts = filteredContracts.filter(c => c.status === 'desistencia').length;
  const abandonmentRate = totalSignedContracts > 0 ? ((abandonedContracts / totalSignedContracts) * 100).toFixed(1) : '0';
  const activeRevenue = filteredContracts.filter(c => c.status === 'ativo' || c.status === 'concluido').reduce((sum, c) => sum + c.value, 0);

  const handleImport = (clients: ImportedClient[]) => {
    setImportedClients(clients);
    setShowImportSuccess(true);
    setTimeout(() => setShowImportSuccess(false), 5000);
  };

  const handleManualSave = (client: ManualClient) => {
    setManualClients([...manualClients, client]);
    setShowManualSuccess(true);
    setTimeout(() => setShowManualSuccess(false), 5000);
  };

  const handleMetaAdsImport = (leads: any[]) => {
    setMetaAdsLeads([...metaAdsLeads, ...leads]);
    setShowMetaAdsSuccess(true);
    setTimeout(() => setShowMetaAdsSuccess(false), 5000);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Leads & Contratos</h1>
        <div className="flex space-x-3">
          <button
            onClick={() => setShowDateFilter(!showDateFilter)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg border ${
              showDateFilter 
                ? 'bg-blue-600 text-white border-blue-600' 
                : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
            }`}
          >
            <Calendar size={16} />
            <span>Filtro por Data</span>
          </button>
          <button
            onClick={() => setShowImport(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
          >
            <FileSpreadsheet size={16} />
            <span>Importar Excel</span>
          </button>
          <button
            onClick={() => setShowManualForm(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
          >
            <User size={16} />
            <span>Cadastro Manual</span>
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Filter size={16} />
            <span>Filtrar</span>
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Download size={16} />
            <span>Exportar</span>
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <Plus size={16} />
            <span>Novo Lead</span>
          </button>
        </div>
      </div>

      {/* Date Filter */}
      {showDateFilter && (
        <DateFilter
          startDate={startDate}
          endDate={endDate}
          onStartDateChange={setStartDate}
          onEndDateChange={setEndDate}
          onPresetSelect={setSelectedPreset}
        />
      )}

      {/* Success Messages */}
      {showImportSuccess && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <FileSpreadsheet className="text-green-600" size={20} />
            <div>
              <h3 className="text-sm font-medium text-green-800">
                ✅ Importação Excel realizada com sucesso!
              </h3>
              <p className="text-sm text-green-700 mt-1">
                {importedClients.length} cliente(s) foram importados e estão disponíveis na aba "Clientes Importados".
              </p>
            </div>
          </div>
        </div>
      )}

      {showManualSuccess && (
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <User className="text-purple-600" size={20} />
            <div>
              <h3 className="text-sm font-medium text-purple-800">
                ✅ Cliente cadastrado manualmente com sucesso!
              </h3>
              <p className="text-sm text-purple-700 mt-1">
                O cliente foi adicionado e está disponível na aba "Cadastros Manuais".
              </p>
            </div>
          </div>
        </div>
      )}

      {showMetaAdsSuccess && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <BarChart3 className="text-blue-600" size={20} />
            <div>
              <h3 className="text-sm font-medium text-blue-800">
                ✅ Leads do Meta Ads importados com sucesso!
              </h3>
              <p className="text-sm text-blue-700 mt-1">
                {metaAdsLeads.length} lead(s) foram importados das campanhas do Meta Ads.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Period Summary */}
      {showDateFilter && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <Calendar className="text-blue-600" size={20} />
            <div>
              <h3 className="text-sm font-medium text-blue-800">
                📊 Análise do Período: {new Date(startDate).toLocaleDateString('pt-BR')} até {new Date(endDate).toLocaleDateString('pt-BR')}
              </h3>
              <p className="text-sm text-blue-700 mt-1">
                {filteredLeads.length} leads e {filteredContracts.length} contratos no período selecionado
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Métricas de Leads e Contratos */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <MetricCard
          title="Leads Ativos"
          value={filteredLeads.filter(l => l.status !== 'fechado' && l.status !== 'perdido').length}
          icon={Target}
          color="blue"
        />
        <MetricCard
          title="Taxa Conversão"
          value={filteredLeads.length > 0 ? `${((filteredContracts.length / filteredLeads.length) * 100).toFixed(1)}%` : '0%'}
          icon={TrendingUp}
          color="green"
        />
        <MetricCard
          title="Contratos Assinados"
          value={totalSignedContracts}
          icon={Users}
          color="purple"
        />
        <MetricCard
          title="Taxa Desistência"
          value={`${abandonmentRate}%`}
          icon={UserX}
          color="red"
        />
        
        {/* Protected Revenue Metric */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-600">Receita Ativa</p>
              <div className="mt-2">
                <ProtectedContent requiredRole="admin" showFallback={true}>
                  <p className="text-2xl font-bold text-gray-900">
                    R$ {activeRevenue.toLocaleString('pt-BR')}
                  </p>
                </ProtectedContent>
              </div>
            </div>
            <div className="p-3 rounded-full bg-green-500 text-green-100">
              <DollarSign size={24} />
            </div>
          </div>
        </div>
      </div>

      {/* Alerta de Desistências */}
      {abandonedContracts > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <AlertTriangle className="text-red-600" size={20} />
            <div>
              <h3 className="text-sm font-medium text-red-800">
                Atenção: {abandonedContracts} desistência(s) de contratos assinados no período
              </h3>
              <p className="text-sm text-red-700 mt-1">
                Taxa de desistência atual: {abandonmentRate}%. Recomenda-se analisar os motivos e melhorar o processo de qualificação de leads.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Gráficos de Análise */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <BarChart
          title="Conversão por Origem"
          data={conversionBySource}
        />
        <BarChart
          title="Contratos por Tipo"
          data={contractsByType}
        />
        <PieChart
          title="Status dos Contratos"
          data={contractStatusData}
        />
      </div>

      {/* Tabs para Leads, Contratos e Clientes */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('leads')}
              className={`py-4 text-sm font-medium border-b-2 ${
                activeTab === 'leads'
                  ? 'text-blue-600 border-blue-600'
                  : 'text-gray-500 border-transparent hover:text-gray-700'
              }`}
            >
              Leads ({filteredLeads.length})
            </button>
            <button
              onClick={() => setActiveTab('contracts')}
              className={`py-4 text-sm font-medium border-b-2 ${
                activeTab === 'contracts'
                  ? 'text-blue-600 border-blue-600'
                  : 'text-gray-500 border-transparent hover:text-gray-700'
              }`}
            >
              Contratos ({filteredContracts.length})
            </button>
            <button
              onClick={() => setActiveTab('meta_ads')}
              className={`py-4 text-sm font-medium border-b-2 ${
                activeTab === 'meta_ads'
                  ? 'text-blue-600 border-blue-600'
                  : 'text-gray-500 border-transparent hover:text-gray-700'
              }`}
            >
              <div className="flex items-center space-x-2">
                <BarChart3 size={16} />
                <span>Meta Ads</span>
              </div>
            </button>
            {manualClients.length > 0 && (
              <button
                onClick={() => setActiveTab('manual')}
                className={`py-4 text-sm font-medium border-b-2 ${
                  activeTab === 'manual'
                    ? 'text-purple-600 border-purple-600'
                    : 'text-gray-500 border-transparent hover:text-gray-700'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <User size={16} />
                  <span>Cadastros Manuais ({manualClients.length})</span>
                </div>
              </button>
            )}
            {importedClients.length > 0 && (
              <button
                onClick={() => setActiveTab('imported')}
                className={`py-4 text-sm font-medium border-b-2 ${
                  activeTab === 'imported'
                    ? 'text-green-600 border-green-600'
                    : 'text-gray-500 border-transparent hover:text-gray-700'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <FileSpreadsheet size={16} />
                  <span>Clientes Importados ({importedClients.length})</span>
                </div>
              </button>
            )}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'leads' && (
            <DataTable
              data={filteredLeads}
              columns={leadColumns}
            />
          )}
          {activeTab === 'contracts' && (
            <DataTable
              data={filteredContracts}
              columns={contractColumns}
            />
          )}
          {activeTab === 'meta_ads' && (
            <MetaAdsIntegration onLeadImport={handleMetaAdsImport} />
          )}
          {activeTab === 'manual' && manualClients.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium text-gray-900">
                  Clientes Cadastrados Manualmente
                </h3>
                <div className="flex space-x-2">
                  <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                    Processar Todos
                  </button>
                  <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                    Converter em Leads
                  </button>
                </div>
              </div>
              <DataTable
                data={manualClients}
                columns={manualClientColumns}
              />
            </div>
          )}
          {activeTab === 'imported' && importedClients.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium text-gray-900">
                  Clientes Importados via Excel
                </h3>
                <div className="flex space-x-2">
                  <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                    Processar Todos
                  </button>
                  <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                    Converter em Leads
                  </button>
                </div>
              </div>
              <DataTable
                data={importedClients}
                columns={importedClientColumns}
              />
            </div>
          )}
        </div>
      </div>

      {/* Excel Import Modal */}
      {showImport && (
        <ExcelImport
          onImport={handleImport}
          onClose={() => setShowImport(false)}
        />
      )}

      {/* Manual Client Form Modal */}
      {showManualForm && (
        <ManualClientForm
          onSave={handleManualSave}
          onClose={() => setShowManualForm(false)}
        />
      )}
    </div>
  );
};

export default LeadsContracts;