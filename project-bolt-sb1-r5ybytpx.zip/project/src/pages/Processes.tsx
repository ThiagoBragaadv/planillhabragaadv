import React, { useState } from 'react';
import { Plus, Filter, Download, Eye, AlertCircle, Calendar, Clock, User, Scale } from 'lucide-react';
import DataTable from '../components/Tables/DataTable';
import MetricCard from '../components/Charts/MetricCard';
import PieChart from '../components/Charts/PieChart';
import BarChart from '../components/Charts/BarChart';
import DeadlineAlert from '../components/Alerts/DeadlineAlert';
import ManualProcessForm from '../components/Forms/ManualProcessForm';
import DateFilter from '../components/Common/DateFilter';
import { mockProcesses, mockDeadlines } from '../data/mockData';
import { Briefcase, CheckCircle, XCircle } from 'lucide-react';

interface ManualProcess {
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  clientCpf: string;
  clientAddress: string;
  clientCity: string;
  clientState: string;
  type: 'administrativo' | 'judicial';
  category: string;
  status: 'em_andamento' | 'deferido' | 'negado' | 'judicializado' | 'procedente' | 'improcedente';
  responsibleLawyer: string;
  priority: 'baixa' | 'media' | 'alta' | 'critica';
  description: string;
  expectedValue?: number;
  contractValue?: number;
  startDate: string;
  expectedDuration: number;
  originProcessId?: string;
  clientDecision?: 'aceita_judicial' | 'desiste_judicial' | 'pendente';
  judicialDecisionReason?: string;
  observations: string;
  urgentNotes?: string;
  documentsList: string[];
  hasDeadlines: boolean;
  firstDeadlineDate?: string;
  firstDeadlineType?: string;
  firstDeadlineDescription?: string;
}

const Processes: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'all' | 'admin' | 'judicial' | 'manual'>('all');
  const [showDeadlines, setShowDeadlines] = useState(false);
  const [showManualForm, setShowManualForm] = useState(false);
  const [showDateFilter, setShowDateFilter] = useState(false);
  const [startDate, setStartDate] = useState('2024-01-01');
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedPreset, setSelectedPreset] = useState('this_month');
  const [manualProcesses, setManualProcesses] = useState<ManualProcess[]>([]);
  const [showManualSuccess, setShowManualSuccess] = useState(false);

  // Filter processes by date range
  const filterByDateRange = (processes: any[]) => {
    return processes.filter(process => {
      const processDate = new Date(process.createdAt);
      const start = new Date(startDate);
      const end = new Date(endDate);
      return processDate >= start && processDate <= end;
    });
  };

  const filteredProcesses = filterByDateRange(mockProcesses);
  const filteredAdminProcesses = filteredProcesses.filter(p => p.type === 'administrativo');
  const filteredJudicialProcesses = filteredProcesses.filter(p => p.type === 'judicial');

  const displayProcesses = activeTab === 'all' ? filteredProcesses : 
                           activeTab === 'admin' ? filteredAdminProcesses : 
                           activeTab === 'judicial' ? filteredJudicialProcesses :
                           [];

  const processColumns = [
    { key: 'clientName', label: 'Cliente', sortable: true },
    { 
      key: 'type', 
      label: 'Tipo',
      render: (type: string) => (
        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
          type === 'administrativo' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'
        }`}>
          {type}
        </span>
      )
    },
    { key: 'category', label: 'Categoria' },
    { key: 'responsibleLawyer', label: 'Advogado Responsável' },
    { 
      key: 'status', 
      label: 'Status',
      render: (status: string) => {
        const statusColors = {
          em_andamento: 'bg-yellow-100 text-yellow-800',
          deferido: 'bg-green-100 text-green-800',
          negado: 'bg-red-100 text-red-800',
          judicializado: 'bg-purple-100 text-purple-800',
          procedente: 'bg-green-100 text-green-800',
          improcedente: 'bg-red-100 text-red-800'
        };
        const statusLabels = {
          em_andamento: 'Em Andamento',
          deferido: 'Deferido',
          negado: 'Negado',
          judicializado: 'Judicializado',
          procedente: 'Procedente',
          improcedente: 'Improcedente'
        };
        return (
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[status as keyof typeof statusColors]}`}>
            {statusLabels[status as keyof typeof statusLabels]}
          </span>
        );
      }
    },
    {
      key: 'deadlines',
      label: 'Prazos',
      render: (deadlines: any[], row: any) => {
        const pendingDeadlines = deadlines?.filter(d => d.status === 'pendente') || [];
        const overdueDeadlines = deadlines?.filter(d => d.status === 'vencido') || [];
        
        if (overdueDeadlines.length > 0) {
          return (
            <div className="flex items-center space-x-1">
              <AlertCircle className="text-red-500" size={16} />
              <span className="text-red-600 text-xs font-medium">
                {overdueDeadlines.length} vencido(s)
              </span>
            </div>
          );
        }
        
        if (pendingDeadlines.length > 0) {
          return (
            <div className="flex items-center space-x-1">
              <Clock className="text-yellow-500" size={16} />
              <span className="text-yellow-600 text-xs font-medium">
                {pendingDeadlines.length} pendente(s)
              </span>
            </div>
          );
        }
        
        return <span className="text-gray-400 text-xs">Nenhum</span>;
      }
    },
    { 
      key: 'createdAt', 
      label: 'Data Início', 
      sortable: true,
      render: (date: string) => new Date(date).toLocaleDateString('pt-BR')
    },
    {
      key: 'actions',
      label: 'Ações',
      render: () => (
        <div className="flex space-x-2">
          <button className="text-blue-600 hover:text-blue-800">
            <Eye size={16} />
          </button>
        </div>
      )
    }
  ];

  // Columns for manual processes table
  const manualProcessColumns = [
    { key: 'clientName', label: 'Cliente', sortable: true },
    { key: 'clientEmail', label: 'Email' },
    { key: 'clientPhone', label: 'Telefone' },
    { 
      key: 'type', 
      label: 'Tipo',
      render: (type: string) => (
        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
          type === 'administrativo' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'
        }`}>
          {type}
        </span>
      )
    },
    { key: 'category', label: 'Categoria' },
    { 
      key: 'priority', 
      label: 'Prioridade',
      render: (priority: string) => {
        const priorityColors = {
          baixa: 'bg-gray-100 text-gray-800',
          media: 'bg-yellow-100 text-yellow-800',
          alta: 'bg-orange-100 text-orange-800',
          critica: 'bg-red-100 text-red-800'
        };
        return (
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${priorityColors[priority as keyof typeof priorityColors]}`}>
            {priority}
          </span>
        );
      }
    },
    { key: 'responsibleLawyer', label: 'Advogado' },
    { 
      key: 'contractValue', 
      label: 'Valor Contrato',
      render: (value: number) => value ? `R$ ${value.toLocaleString('pt-BR')}` : '-'
    },
    { 
      key: 'hasDeadlines', 
      label: 'Prazos',
      render: (hasDeadlines: boolean) => (
        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
          hasDeadlines ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800'
        }`}>
          {hasDeadlines ? 'Sim' : 'Não'}
        </span>
      )
    },
    {
      key: 'actions',
      label: 'Ações',
      render: () => (
        <div className="flex space-x-2">
          <button className="text-blue-600 hover:text-blue-800">
            <Eye size={16} />
          </button>
        </div>
      )
    }
  ];

  const processStatusData = [
    { label: 'Em Andamento', value: filteredProcesses.filter(p => p.status === 'em_andamento').length, color: '#F59E0B' },
    { label: 'Deferidos', value: filteredProcesses.filter(p => p.status === 'deferido').length, color: '#10B981' },
    { label: 'Negados', value: filteredProcesses.filter(p => p.status === 'negado').length, color: '#EF4444' },
    { label: 'Judicializados', value: filteredProcesses.filter(p => p.status === 'judicializado').length, color: '#8B5CF6' },
  ];

  const monthlyProcesses = [
    { label: 'Jan', value: 8 },
    { label: 'Fev', value: 12 },
    { label: 'Mar', value: 15 },
    { label: 'Abr', value: 10 },
    { label: 'Mai', value: 18 },
    { label: 'Jun', value: 14 },
  ];

  const documentsPendingCount = filteredProcesses.reduce((count, process) => {
    return count + process.documents.filter(doc => doc.status === 'pendente').length;
  }, 0);

  const pendingDeadlines = mockDeadlines.filter(d => d.status === 'pendente');
  const overdueDeadlines = mockDeadlines.filter(d => d.status === 'vencido');

  const handleMarkDeadlineComplete = (deadlineId: string) => {
    console.log('Marking deadline as complete:', deadlineId);
  };

  const handleManualSave = (process: ManualProcess) => {
    setManualProcesses([...manualProcesses, process]);
    setShowManualSuccess(true);
    setTimeout(() => setShowManualSuccess(false), 5000);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Gestão de Processos</h1>
        <div className="flex space-x-3">
          <button
            onClick={() => setShowDateFilter(!showDateFilter)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg border ${
              showDateFilter 
                ? 'bg-blue-600 text-white border-blue-600' 
                : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
            }`}
          >
            <Calendar size={16} />
            <span>Filtro por Data</span>
          </button>
          <button
            onClick={() => setShowDeadlines(!showDeadlines)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg border ${
              showDeadlines 
                ? 'bg-blue-600 text-white border-blue-600' 
                : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
            }`}
          >
            <Calendar size={16} />
            <span>Prazos</span>
          </button>
          <button
            onClick={() => setShowManualForm(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
          >
            <User size={16} />
            <span>Cadastro Manual</span>
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Filter size={16} />
            <span>Filtrar</span>
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Download size={16} />
            <span>Exportar</span>
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <Plus size={16} />
            <span>Novo Processo</span>
          </button>
        </div>
      </div>

      {/* Date Filter */}
      {showDateFilter && (
        <DateFilter
          startDate={startDate}
          endDate={endDate}
          onStartDateChange={setStartDate}
          onEndDateChange={setEndDate}
          onPresetSelect={setSelectedPreset}
        />
      )}

      {/* Success Message */}
      {showManualSuccess && (
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <Scale className="text-purple-600" size={20} />
            <div>
              <h3 className="text-sm font-medium text-purple-800">
                ✅ Processo cadastrado manualmente com sucesso!
              </h3>
              <p className="text-sm text-purple-700 mt-1">
                O processo foi adicionado e está disponível na aba "Cadastros Manuais".
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Period Summary */}
      {showDateFilter && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <Calendar className="text-blue-600" size={20} />
            <div>
              <h3 className="text-sm font-medium text-blue-800">
                📊 Análise do Período: {new Date(startDate).toLocaleDateString('pt-BR')} até {new Date(endDate).toLocaleDateString('pt-BR')}
              </h3>
              <p className="text-sm text-blue-700 mt-1">
                {filteredProcesses.length} processos no período selecionado ({filteredAdminProcesses.length} administrativos, {filteredJudicialProcesses.length} judiciais)
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Métricas dos Processos */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <MetricCard
          title="Processos Ativos"
          value={filteredProcesses.filter(p => p.status === 'em_andamento').length}
          icon={Clock}
          color="yellow"
        />
        <MetricCard
          title="Taxa Aprovação Admin"
          value={filteredAdminProcesses.length > 0 ? 
            `${((filteredAdminProcesses.filter(p => p.status === 'deferido').length / filteredAdminProcesses.length) * 100).toFixed(1)}%` : '0%'}
          icon={CheckCircle}
          color="green"
        />
        <MetricCard
          title="Processos Judicializados"
          value={filteredProcesses.filter(p => p.status === 'judicializado').length}
          icon={Briefcase}
          color="purple"
        />
        <MetricCard
          title="Prazos Pendentes"
          value={pendingDeadlines.length}
          icon={Clock}
          color="blue"
        />
        <MetricCard
          title="Prazos Vencidos"
          value={overdueDeadlines.length}
          icon={AlertCircle}
          color="red"
        />
      </div>

      {/* Seção de Prazos */}
      {showDeadlines && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-gray-900">Controle de Prazos</h2>
          
          {/* Prazos Vencidos */}
          {overdueDeadlines.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-md font-medium text-red-600 flex items-center space-x-2">
                <AlertCircle size={18} />
                <span>Prazos Vencidos ({overdueDeadlines.length})</span>
              </h3>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {overdueDeadlines.map((deadline) => {
                  const process = mockProcesses.find(p => p.id === deadline.processId);
                  return (
                    <DeadlineAlert
                      key={deadline.id}
                      deadline={deadline}
                      clientName={process?.clientName || 'Cliente não encontrado'}
                      onMarkComplete={handleMarkDeadlineComplete}
                    />
                  );
                })}
              </div>
            </div>
          )}

          {/* Prazos Pendentes */}
          {pendingDeadlines.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-md font-medium text-yellow-600 flex items-center space-x-2">
                <Clock size={18} />
                <span>Prazos Pendentes ({pendingDeadlines.length})</span>
              </h3>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {pendingDeadlines.map((deadline) => {
                  const process = mockProcesses.find(p => p.id === deadline.processId);
                  return (
                    <DeadlineAlert
                      key={deadline.id}
                      deadline={deadline}
                      clientName={process?.clientName || 'Cliente não encontrado'}
                      onMarkComplete={handleMarkDeadlineComplete}
                    />
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Gráficos de Análise */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <PieChart
          title="Status dos Processos"
          data={processStatusData}
        />
        <BarChart
          title="Processos Iniciados por Mês"
          data={monthlyProcesses}
        />
      </div>

      {/* Tabs para Filtrar Processos */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('all')}
              className={`py-4 text-sm font-medium border-b-2 ${
                activeTab === 'all'
                  ? 'text-blue-600 border-blue-600'
                  : 'text-gray-500 border-transparent hover:text-gray-700'
              }`}
            >
              Todos ({filteredProcesses.length})
            </button>
            <button
              onClick={() => setActiveTab('admin')}
              className={`py-4 text-sm font-medium border-b-2 ${
                activeTab === 'admin'
                  ? 'text-blue-600 border-blue-600'
                  : 'text-gray-500 border-transparent hover:text-gray-700'
              }`}
            >
              Administrativos ({filteredAdminProcesses.length})
            </button>
            <button
              onClick={() => setActiveTab('judicial')}
              className={`py-4 text-sm font-medium border-b-2 ${
                activeTab === 'judicial'
                  ? 'text-blue-600 border-blue-600'
                  : 'text-gray-500 border-transparent hover:text-gray-700'
              }`}
            >
              Judiciais ({filteredJudicialProcesses.length})
            </button>
            {manualProcesses.length > 0 && (
              <button
                onClick={() => setActiveTab('manual')}
                className={`py-4 text-sm font-medium border-b-2 ${
                  activeTab === 'manual'
                    ? 'text-purple-600 border-purple-600'
                    : 'text-gray-500 border-transparent hover:text-gray-700'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <User size={16} />
                  <span>Cadastros Manuais ({manualProcesses.length})</span>
                </div>
              </button>
            )}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'manual' && manualProcesses.length > 0 ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium text-gray-900">
                  Processos Cadastrados Manualmente
                </h3>
                <div className="flex space-x-2">
                  <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                    Processar Todos
                  </button>
                  <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                    Integrar ao Sistema
                  </button>
                </div>
              </div>
              <DataTable
                data={manualProcesses}
                columns={manualProcessColumns}
              />
            </div>
          ) : (
            <DataTable
              data={displayProcesses}
              columns={processColumns}
            />
          )}
        </div>
      </div>

      {/* Alertas de Documentos Pendentes */}
      {documentsPendingCount > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <AlertCircle className="text-yellow-600" size={20} />
            <div>
              <h3 className="text-sm font-medium text-yellow-800">
                Atenção: {documentsPendingCount} documento(s) pendente(s) no período
              </h3>
              <p className="text-sm text-yellow-700 mt-1">
                Existem documentos aguardando envio ou revisão. Verifique os processos marcados para evitar atrasos.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Manual Process Form Modal */}
      {showManualForm && (
        <ManualProcessForm
          onSave={handleManualSave}
          onClose={() => setShowManualForm(false)}
          adminProcesses={filteredAdminProcesses}
        />
      )}
    </div>
  );
};

export default Processes;