import React, { useState } from 'react';
import { 
  TrendingUp, 
  Users, 
  FileText, 
  DollarSign,
  Target,
  CheckCircle,
  XCircle,
  Clock,
  AlertTriangle,
  UserX,
  Scale,
  Calendar,
  Filter,
  Briefcase,
  Building,
  ArrowRight,
  UserCheck,
  UserMinus,
  BarChart3
} from 'lucide-react';
import MetricCard from '../components/Charts/MetricCard';
import BarChart from '../components/Charts/BarChart';
import PieChart from '../components/Charts/PieChart';
import DeadlineAlert from '../components/Alerts/DeadlineAlert';
import GoogleCalendarIntegration from '../components/Calendar/GoogleCalendarIntegration';
import RevenueDisplay from '../components/Common/RevenueDisplay';
import ProtectedContent from '../components/Common/ProtectedContent';
import DateFilter from '../components/Common/DateFilter';
import { mockStats, mockDeadlines, mockProcesses, mockContracts, getMonthlyProcessEntries, getProcessesByMonth, getJudicialTrackingData } from '../data/mockData';
import { ProcessDeadline } from '../types';
import { useAuth } from '../context/AuthContext';

const Dashboard: React.FC = () => {
  const [showCalendar, setShowCalendar] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [showDateFilter, setShowDateFilter] = useState(false);
  const [startDate, setStartDate] = useState('2024-01-01');
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedPreset, setSelectedPreset] = useState('this_month');
  const { canViewRevenue, currentUser } = useAuth();

  const months = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  const years = [2023, 2024, 2025];

  // Get monthly data
  const monthlyData = getMonthlyProcessEntries();
  const selectedMonthProcesses = getProcessesByMonth(selectedMonth, selectedYear);
  const selectedMonthAdminEntries = selectedMonthProcesses.filter(p => p.type === 'administrativo').length;
  const selectedMonthJudicialEntries = selectedMonthProcesses.filter(p => p.type === 'judicial').length;

  // Get judicial tracking data
  const judicialTrackingData = getJudicialTrackingData();

  const conversionData = [
    { label: 'Jan', value: 23 },
    { label: 'Fev', value: 31 },
    { label: 'Mar', value: 28 },
    { label: 'Abr', value: 35 },
    { label: 'Mai', value: 42 },
    { label: 'Jun', value: 38 },
  ];

  const processStatusData = [
    { label: 'Deferidos', value: mockProcesses.filter(p => p.status === 'deferido').length, color: '#10B981' },
    { label: 'Negados', value: mockProcesses.filter(p => p.status === 'negado').length, color: '#EF4444' },
    { label: 'Em Andamento', value: mockProcesses.filter(p => p.status === 'em_andamento').length, color: '#F59E0B' },
    { label: 'Procedentes', value: mockProcesses.filter(p => p.status === 'procedente').length, color: '#3B82F6' },
    { label: 'Improcedentes', value: mockProcesses.filter(p => p.status === 'improcedente').length, color: '#8B5CF6' },
  ];

  const contractStatusData = [
    { label: 'Ativos', value: mockContracts.filter(c => c.status === 'ativo').length, color: '#10B981' },
    { label: 'Concluídos', value: mockContracts.filter(c => c.status === 'concluido').length, color: '#3B82F6' },
    { label: 'Desistências', value: mockContracts.filter(c => c.status === 'desistencia').length, color: '#EF4444' },
    { label: 'Cancelados', value: mockContracts.filter(c => c.status === 'cancelado').length, color: '#6B7280' },
  ];

  // Monthly process entries chart data
  const monthlyProcessEntriesData = monthlyData.map(item => ({
    label: item.month,
    value: item.total,
    color: 'bg-purple-500'
  }));

  const monthlyAdminVsJudicialData = [
    { label: 'Administrativos', value: selectedMonthAdminEntries, color: 'bg-blue-500' },
    { label: 'Judiciais', value: selectedMonthJudicialEntries, color: 'bg-green-500' },
  ];

  // NEW: Monthly comparison data for processes vs contracts
  const monthlyComparisonData = [
    { month: 'Jan', processes: 8, contracts: 12, processRevenue: 24000, contractRevenue: 36000 },
    { month: 'Fev', processes: 12, contracts: 15, processRevenue: 36000, contractRevenue: 45000 },
    { month: 'Mar', processes: 15, contracts: 18, processRevenue: 45000, contractRevenue: 54000 },
    { month: 'Abr', processes: 10, contracts: 14, processRevenue: 30000, contractRevenue: 42000 },
    { month: 'Mai', processes: 18, contracts: 22, processRevenue: 54000, contractRevenue: 66000 },
    { month: 'Jun', processes: 14, contracts: 16, processRevenue: 42000, contractRevenue: 48000 },
  ];

  // Chart data for monthly comparison
  const monthlyProcessesChartData = monthlyComparisonData.map(item => ({
    label: item.month,
    value: item.processes,
    color: 'bg-blue-500'
  }));

  const monthlyContractsChartData = monthlyComparisonData.map(item => ({
    label: item.month,
    value: item.contracts,
    color: 'bg-green-500'
  }));

  const monthlyRevenueComparisonData = monthlyComparisonData.map(item => ({
    label: item.month,
    value: Math.round((item.processRevenue + item.contractRevenue) / 1000), // Convert to thousands
    color: 'bg-purple-500'
  }));

  // Judicial tracking chart data
  const judicialTrackingChartData = [
    { label: 'Negados', value: judicialTrackingData.adminNegados, color: 'bg-red-500' },
    { label: 'Judicializados', value: judicialTrackingData.judicializados, color: 'bg-blue-500' },
    { label: 'Desistiram', value: judicialTrackingData.clientesDesistiram, color: 'bg-gray-500' },
    { label: 'Pendentes', value: judicialTrackingData.pendentesDecisao, color: 'bg-yellow-500' },
  ];

  const judicialDecisionData = [
    { label: 'Aceitaram Judicial', value: judicialTrackingData.clientesAceitaram, color: '#10B981' },
    { label: 'Desistiram', value: judicialTrackingData.clientesDesistiram, color: '#EF4444' },
    { label: 'Pendentes', value: judicialTrackingData.pendentesDecisao, color: '#F59E0B' },
  ];

  const judicialVsAdminData = [
    { label: 'Taxa Admin', value: mockStats.adminApprovalRate, color: 'bg-blue-500' },
    { label: 'Taxa Judicial', value: mockStats.judicialSuccessRate, color: 'bg-green-500' },
  ];

  const teamPerformance = [
    { label: 'Maria Silva', value: 12, color: 'bg-blue-500' },
    { label: 'João Santos', value: 9, color: 'bg-green-500' },
    { label: 'Ana Costa', value: 7, color: 'bg-purple-500' },
    { label: 'Paulo Lima', value: 5, color: 'bg-yellow-500' },
  ];

  // Get urgent deadlines (due in 3 days or overdue)
  const urgentDeadlines = mockDeadlines.filter(deadline => {
    const today = new Date();
    const dueDate = new Date(deadline.dueDate);
    const diffTime = dueDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return (diffDays <= 3 && deadline.status === 'pendente') || deadline.status === 'vencido';
  }).sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());

  const handleMarkDeadlineComplete = (deadlineId: string) => {
    // In a real app, this would update the deadline status
    console.log('Marking deadline as complete:', deadlineId);
  };

  const handleScheduleAppointment = (deadline: ProcessDeadline) => {
    setShowCalendar(true);
    // In a real app, this would pre-fill the calendar form with deadline data
    console.log('Scheduling appointment for deadline:', deadline);
  };

  // Get recent abandoned contracts for alerts
  const recentAbandonedContracts = mockContracts.filter(c => c.status === 'desistencia');

  // Calculate judicial metrics
  const judicialProcesses = mockProcesses.filter(p => p.type === 'judicial');
  const completedJudicial = judicialProcesses.filter(p => p.status === 'procedente' || p.status === 'improcedente');
  const procedenteJudicial = judicialProcesses.filter(p => p.status === 'procedente');

  // Get processes with client decisions about judicial action
  const processesWithJudicialDecision = mockProcesses.filter(p => 
    p.type === 'administrativo' && p.status === 'negado' && p.clientDecision
  );

  // Calculate monthly growth rates
  const currentMonthProcesses = monthlyComparisonData[monthlyComparisonData.length - 1].processes;
  const previousMonthProcesses = monthlyComparisonData[monthlyComparisonData.length - 2].processes;
  const processGrowthRate = previousMonthProcesses > 0 ? 
    (((currentMonthProcesses - previousMonthProcesses) / previousMonthProcesses) * 100).toFixed(1) : '0';

  const currentMonthContracts = monthlyComparisonData[monthlyComparisonData.length - 1].contracts;
  const previousMonthContracts = monthlyComparisonData[monthlyComparisonData.length - 2].contracts;
  const contractGrowthRate = previousMonthContracts > 0 ? 
    (((currentMonthContracts - previousMonthContracts) / previousMonthContracts) * 100).toFixed(1) : '0';

  const currentMonthRevenue = monthlyComparisonData[monthlyComparisonData.length - 1].processRevenue + 
                             monthlyComparisonData[monthlyComparisonData.length - 1].contractRevenue;
  const previousMonthRevenue = monthlyComparisonData[monthlyComparisonData.length - 2].processRevenue + 
                              monthlyComparisonData[monthlyComparisonData.length - 2].contractRevenue;
  const revenueGrowthRate = previousMonthRevenue > 0 ? 
    (((currentMonthRevenue - previousMonthRevenue) / previousMonthRevenue) * 100).toFixed(1) : '0';

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard Executivo</h1>
          <p className="text-sm text-gray-600 mt-1">
            Bem-vindo, {currentUser?.name} • {currentUser?.role === 'admin' ? 'Administrador' : 'Usuário'}
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setShowDateFilter(!showDateFilter)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg border ${
              showDateFilter 
                ? 'bg-blue-600 text-white border-blue-600' 
                : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
            }`}
          >
            <Calendar size={16} />
            <span>Filtro por Data</span>
          </button>
          <button
            onClick={() => setShowCalendar(!showCalendar)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg border ${
              showCalendar 
                ? 'bg-blue-600 text-white border-blue-600' 
                : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
            }`}
          >
            <Calendar size={16} />
            <span>Google Agenda</span>
          </button>
          <div className="flex items-center space-x-2 text-sm text-gray-500">
            <Clock size={16} />
            <span>Última atualização: {new Date().toLocaleString('pt-BR')}</span>
          </div>
        </div>
      </div>

      {/* Date Filter */}
      {showDateFilter && (
        <DateFilter
          startDate={startDate}
          endDate={endDate}
          onStartDateChange={setStartDate}
          onEndDateChange={setEndDate}
          onPresetSelect={setSelectedPreset}
        />
      )}

      {/* Access Level Indicator */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-center space-x-3">
          <div className={`p-2 rounded-full ${canViewRevenue() ? 'bg-green-100' : 'bg-yellow-100'}`}>
            {canViewRevenue() ? (
              <CheckCircle className="text-green-600" size={16} />
            ) : (
              <AlertTriangle className="text-yellow-600" size={16} />
            )}
          </div>
          <div>
            <h3 className="text-sm font-medium text-blue-900">
              {canViewRevenue() ? '🔓 Acesso Completo' : '🔒 Acesso Limitado'}
            </h3>
            <p className="text-sm text-blue-700 mt-1">
              {canViewRevenue() 
                ? 'Você tem acesso a todas as informações financeiras e métricas de faturamento.'
                : 'Algumas informações financeiras estão restritas a administradores. Entre em contato com um administrador para acesso completo.'
              }
            </p>
          </div>
        </div>
      </div>

      {/* Google Calendar Integration */}
      {showCalendar && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <GoogleCalendarIntegration />
        </div>
      )}

      {/* NEW: Monthly Comparison Section */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center space-x-3 mb-6">
          <BarChart3 className="text-purple-600" size={20} />
          <h3 className="text-lg font-semibold text-gray-900">📊 Comparação Mensal: Processos vs Contratos</h3>
        </div>

        {/* Monthly Growth Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <MetricCard
            title="Crescimento Processos"
            value={`${processGrowthRate}%`}
            icon={TrendingUp}
            trend={{ value: parseFloat(processGrowthRate), isPositive: parseFloat(processGrowthRate) >= 0 }}
            color="blue"
          />
          <MetricCard
            title="Crescimento Contratos"
            value={`${contractGrowthRate}%`}
            icon={Users}
            trend={{ value: parseFloat(contractGrowthRate), isPositive: parseFloat(contractGrowthRate) >= 0 }}
            color="green"
          />
          
          {/* Protected Revenue Growth */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-600">Crescimento Receita</p>
                <div className="mt-2">
                  <ProtectedContent requiredRole="admin" showFallback={true}>
                    <p className="text-2xl font-bold text-gray-900">
                      {revenueGrowthRate}%
                    </p>
                    <p className={`text-sm mt-2 ${parseFloat(revenueGrowthRate) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {parseFloat(revenueGrowthRate) >= 0 ? '+' : ''}{revenueGrowthRate}% vs. mês anterior
                    </p>
                  </ProtectedContent>
                </div>
              </div>
              <div className="p-3 rounded-full bg-purple-500 text-purple-100">
                <DollarSign size={24} />
              </div>
            </div>
          </div>
        </div>

        {/* Monthly Comparison Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <BarChart
            title="Processos Iniciados por Mês"
            data={monthlyProcessesChartData}
          />
          <BarChart
            title="Contratos Fechados por Mês"
            data={monthlyContractsChartData}
          />
          <BarChart
            title="Receita Total por Mês (R$ mil)"
            data={monthlyRevenueComparisonData}
          />
        </div>

        {/* Detailed Monthly Comparison Table */}
        <div className="bg-gray-50 rounded-lg p-4">
          <h4 className="text-md font-medium text-gray-900 mb-4">📋 Análise Detalhada Mensal</h4>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-white">
                <tr>
                  <th className="px-4 py-2 text-left font-medium text-gray-900">Mês</th>
                  <th className="px-4 py-2 text-left font-medium text-gray-900">Processos</th>
                  <th className="px-4 py-2 text-left font-medium text-gray-900">Contratos</th>
                  <th className="px-4 py-2 text-left font-medium text-gray-900">Taxa Conversão</th>
                  <th className="px-4 py-2 text-left font-medium text-gray-900">Receita Total</th>
                  <th className="px-4 py-2 text-left font-medium text-gray-900">Ticket Médio</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {monthlyComparisonData.map((month, index) => {
                  const conversionRate = month.processes > 0 ? ((month.contracts / month.processes) * 100).toFixed(1) : '0';
                  const totalRevenue = month.processRevenue + month.contractRevenue;
                  const avgTicket = month.contracts > 0 ? (totalRevenue / month.contracts).toFixed(0) : '0';
                  
                  return (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-4 py-2 font-medium text-gray-900">{month.month}</td>
                      <td className="px-4 py-2 text-blue-600 font-medium">{month.processes}</td>
                      <td className="px-4 py-2 text-green-600 font-medium">{month.contracts}</td>
                      <td className="px-4 py-2 text-purple-600 font-medium">{conversionRate}%</td>
                      <td className="px-4 py-2">
                        <ProtectedContent requiredRole="admin" showFallback={false}>
                          <span className="text-gray-900 font-medium">R$ {totalRevenue.toLocaleString('pt-BR')}</span>
                        </ProtectedContent>
                      </td>
                      <td className="px-4 py-2">
                        <ProtectedContent requiredRole="admin" showFallback={false}>
                          <span className="text-gray-900">R$ {parseInt(avgTicket).toLocaleString('pt-BR')}</span>
                        </ProtectedContent>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Key Insights */}
        <div className="mt-6 bg-gradient-to-r from-purple-500 to-blue-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-lg font-semibold mb-2">📈 Insights da Análise Mensal</h4>
              <div className="space-y-1 text-sm text-purple-100">
                <p>• Melhor mês em processos: <strong>Maio ({monthlyComparisonData[4].processes} processos)</strong></p>
                <p>• Melhor mês em contratos: <strong>Maio ({monthlyComparisonData[4].contracts} contratos)</strong></p>
                <p>• Tendência de crescimento: <strong>{parseFloat(processGrowthRate) >= 0 ? 'Positiva' : 'Negativa'}</strong></p>
                <p>• Taxa de conversão média: <strong>
                  {(monthlyComparisonData.reduce((sum, m) => sum + (m.processes > 0 ? (m.contracts / m.processes) * 100 : 0), 0) / monthlyComparisonData.length).toFixed(1)}%
                </strong></p>
              </div>
            </div>
            <div className="text-right">
              <div className="bg-white bg-opacity-20 rounded-lg p-4">
                <p className="text-3xl font-bold">{currentMonthProcesses + currentMonthContracts}</p>
                <p className="text-sm text-purple-100">Total Junho</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filtro de Mês para Análise de Processos */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Filter className="text-purple-600" size={20} />
            <h3 className="text-lg font-semibold text-gray-900">📊 Análise de Entradas de Processos</h3>
          </div>
          <div className="flex items-center space-x-3">
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            >
              {months.map((month, index) => (
                <option key={index} value={index}>{month}</option>
              ))}
            </select>
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(parseInt(e.target.value))}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            >
              {years.map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Métricas de Entradas de Processos do Mês Selecionado */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <MetricCard
            title="Processos Administrativos"
            value={selectedMonthAdminEntries}
            icon={Building}
            trend={{ value: 12.5, isPositive: true }}
            color="blue"
          />
          <MetricCard
            title="Processos Judiciais"
            value={selectedMonthJudicialEntries}
            icon={Scale}
            trend={{ value: 8.2, isPositive: true }}
            color="green"
          />
          <MetricCard
            title="Total de Entradas"
            value={selectedMonthAdminEntries + selectedMonthJudicialEntries}
            icon={Briefcase}
            trend={{ value: 10.3, isPositive: true }}
            color="purple"
          />
          <MetricCard
            title="% Judicialização"
            value={`${selectedMonthAdminEntries + selectedMonthJudicialEntries > 0 ? 
              ((selectedMonthJudicialEntries / (selectedMonthAdminEntries + selectedMonthJudicialEntries)) * 100).toFixed(1) : 0}%`}
            icon={TrendingUp}
            color="yellow"
          />
        </div>

        {/* Destaque do Mês Selecionado */}
        <div className="mt-6 bg-gradient-to-r from-purple-500 to-blue-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-lg font-semibold mb-2">
                📈 {months[selectedMonth]} {selectedYear} - Entradas de Processos
              </h4>
              <p className="text-purple-100">
                Análise detalhada das entradas administrativas vs judiciais
              </p>
            </div>
            <div className="text-right">
              <div className="bg-white bg-opacity-20 rounded-lg p-4">
                <p className="text-3xl font-bold">{selectedMonthAdminEntries + selectedMonthJudicialEntries}</p>
                <p className="text-sm text-purple-100">Total de Entradas</p>
              </div>
            </div>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold">{selectedMonthAdminEntries}</p>
              <p className="text-xs text-purple-100">Administrativos</p>
            </div>
            <div>
              <p className="text-2xl font-bold">{selectedMonthJudicialEntries}</p>
              <p className="text-xs text-purple-100">Judiciais</p>
            </div>
            <div>
              <p className="text-2xl font-bold">
                {selectedMonthAdminEntries + selectedMonthJudicialEntries > 0 ? 
                  ((selectedMonthJudicialEntries / (selectedMonthAdminEntries + selectedMonthJudicialEntries)) * 100).toFixed(0) : 0}%
              </p>
              <p className="text-xs text-purple-100">Taxa Judicialização</p>
            </div>
          </div>
        </div>
      </div>

      {/* Seção de Rastreamento Judicial */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center space-x-3 mb-6">
          <Scale className="text-indigo-600" size={20} />
          <h3 className="text-lg font-semibold text-gray-900">⚖️ Rastreamento de Judicialização</h3>
        </div>

        {/* Métricas de Judicialização */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <MetricCard
            title="Admin Negados → Judicial"
            value={mockStats.adminNegadosJudicializados}
            icon={ArrowRight}
            color="blue"
          />
          <MetricCard
            title="Clientes Desistiram"
            value={mockStats.clientesDesistiramJudicial}
            icon={UserMinus}
            color="red"
          />
          <MetricCard
            title="Taxa Judicialização"
            value={`${mockStats.taxaJudicializacaoNegados}%`}
            icon={TrendingUp}
            color="green"
          />
          <MetricCard
            title="Taxa Desistência"
            value={`${mockStats.taxaDesistenciaJudicial}%`}
            icon={UserX}
            color="yellow"
          />
        </div>

        {/* Destaque de Judicialização */}
        <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-lg font-semibold mb-2">
                ⚖️ Fluxo de Judicialização - Processos Negados
              </h4>
              <p className="text-indigo-100">
                Acompanhamento das decisões dos clientes após negativa administrativa
              </p>
            </div>
            <div className="text-right">
              <div className="bg-white bg-opacity-20 rounded-lg p-4">
                <p className="text-3xl font-bold">{judicialTrackingData.adminNegados}</p>
                <p className="text-sm text-indigo-100">Admin Negados</p>
              </div>
            </div>
          </div>
          <div className="mt-4 grid grid-cols-4 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold">{judicialTrackingData.judicializados}</p>
              <p className="text-xs text-indigo-100">Judicializados</p>
            </div>
            <div>
              <p className="text-2xl font-bold">{judicialTrackingData.clientesAceitaram}</p>
              <p className="text-xs text-indigo-100">Aceitaram</p>
            </div>
            <div>
              <p className="text-2xl font-bold">{judicialTrackingData.clientesDesistiram}</p>
              <p className="text-xs text-indigo-100">Desistiram</p>
            </div>
            <div>
              <p className="text-2xl font-bold">{judicialTrackingData.pendentesDecisao}</p>
              <p className="text-xs text-indigo-100">Pendentes</p>
            </div>
          </div>
        </div>

        {/* Lista de Processos com Decisões Pendentes */}
        {processesWithJudicialDecision.length > 0 && (
          <div className="mt-6">
            <h4 className="text-md font-medium text-gray-900 mb-4">
              📋 Decisões dos Clientes sobre Judicialização
            </h4>
            <div className="space-y-3">
              {processesWithJudicialDecision.slice(0, 3).map((process) => (
                <div key={process.id} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{process.clientName}</p>
                      <p className="text-xs text-gray-600">{process.category}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        Negado em: {process.completedAt ? new Date(process.completedAt).toLocaleDateString('pt-BR') : '-'}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        process.clientDecision === 'aceita_judicial' ? 'bg-green-100 text-green-800' :
                        process.clientDecision === 'desiste_judicial' ? 'bg-red-100 text-red-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {process.clientDecision === 'aceita_judicial' ? '✅ Aceitou Judicial' :
                         process.clientDecision === 'desiste_judicial' ? '❌ Desistiu' :
                         '⏳ Pendente'}
                      </span>
                      {process.judicialDecisionReason && (
                        <p className="text-xs text-gray-500 mt-1 max-w-48">
                          {process.judicialDecisionReason}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Métricas Principais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Total de Leads"
          value={mockStats.totalLeads}
          icon={Target}
          trend={{ value: 12.5, isPositive: true }}
          color="blue"
        />
        <MetricCard
          title="Contratos Fechados"
          value={mockStats.totalContracts}
          icon={CheckCircle}
          trend={{ value: 8.2, isPositive: true }}
          color="green"
        />
        <MetricCard
          title="Taxa de Conversão"
          value={`${mockStats.conversionRate}%`}
          icon={TrendingUp}
          trend={{ value: 3.1, isPositive: true }}
          color="blue"
        />
        
        {/* Protected Revenue Card */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-600">Faturamento Total</p>
              <div className="mt-2">
                <ProtectedContent requiredRole="admin" showFallback={true}>
                  <div className="flex items-center space-x-2">
                    <p className="text-2xl font-bold text-gray-900">
                      R$ {mockStats.totalRevenue.toLocaleString('pt-BR')}
                    </p>
                    <div className="text-sm text-green-600">
                      +15.7% vs. mês anterior
                    </div>
                  </div>
                </ProtectedContent>
              </div>
            </div>
            <div className="p-3 rounded-full bg-green-500 text-green-100">
              <DollarSign size={24} />
            </div>
          </div>
        </div>
      </div>

      {/* Métricas Totais de Processos */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <MetricCard
          title="Total Proc. Administrativos"
          value={mockStats.totalAdminProcesses}
          icon={Building}
          color="blue"
        />
        <MetricCard
          title="Total Proc. Judiciais"
          value={mockStats.totalJudicialProcesses}
          icon={Scale}
          color="green"
        />
        <MetricCard
          title="Processos Ativos"
          value={mockStats.activeProcesses}
          icon={Clock}
          color="yellow"
        />
        <MetricCard
          title="Taxa Judicialização Geral"
          value={`${((mockStats.totalJudicialProcesses / (mockStats.totalAdminProcesses + mockStats.totalJudicialProcesses)) * 100).toFixed(1)}%`}
          icon={TrendingUp}
          color="purple"
        />
      </div>

      {/* Métricas de Contratos e Desistência */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <MetricCard
          title="Contratos Ativos"
          value={mockContracts.filter(c => c.status === 'ativo').length}
          icon={Users}
          color="green"
        />
        <MetricCard
          title="Taxa de Desistência"
          value={`${mockStats.contractAbandonmentRate}%`}
          icon={UserX}
          trend={{ value: -2.3, isPositive: false }}
          color="red"
        />
        <MetricCard
          title="Desistências Este Mês"
          value={mockStats.abandonedContracts}
          icon={XCircle}
          color="red"
        />
        <MetricCard
          title="Taxa Aprovação Admin"
          value={`${mockStats.adminApprovalRate}%`}
          icon={CheckCircle}
          color="green"
        />
      </div>

      {/* Métricas de Processo e Aprovação Judicial */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <MetricCard
          title="Prazos Pendentes"
          value={mockStats.pendingDeadlines}
          icon={Clock}
          color="blue"
        />
        <MetricCard
          title="Prazos Vencidos"
          value={mockStats.overdueDeadlines}
          icon={AlertTriangle}
          color="red"
        />
        <MetricCard
          title="Taxa Aprovação Judicial"
          value={`${mockStats.judicialSuccessRate}%`}
          icon={Scale}
          trend={{ value: 5.2, isPositive: true }}
          color="blue"
        />
        <MetricCard
          title="Processos Judicializados"
          value={mockProcesses.filter(p => p.status === 'judicializado').length}
          icon={Briefcase}
          color="purple"
        />
      </div>

      {/* Destaque da Taxa de Aprovação Judicial */}
      <div className="bg-gradient-to-r from-blue-500 to-green-600 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold mb-2">⚖️ Performance Judicial</h3>
            <p className="text-2xl font-bold">{mockStats.judicialSuccessRate}%</p>
            <p className="text-blue-100">Taxa de aprovação em processos judiciais</p>
          </div>
          <div className="text-right">
            <div className="bg-white bg-opacity-20 rounded-lg p-4">
              <p className="text-3xl font-bold">{procedenteJudicial.length}/{completedJudicial.length}</p>
              <p className="text-sm text-blue-100">Procedentes/Total</p>
            </div>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-2xl font-bold">{procedenteJudicial.length}</p>
            <p className="text-xs text-blue-100">Procedentes</p>
          </div>
          <div>
            <p className="text-2xl font-bold">{judicialProcesses.filter(p => p.status === 'improcedente').length}</p>
            <p className="text-xs text-blue-100">Improcedentes</p>
          </div>
          <div>
            <p className="text-2xl font-bold">{judicialProcesses.filter(p => p.status === 'em_andamento').length}</p>
            <p className="text-xs text-blue-100">Em Andamento</p>
          </div>
        </div>
      </div>

      {/* Alerta de Desistências Recentes */}
      {recentAbandonedContracts.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center space-x-3 mb-3">
            <UserX className="text-red-600" size={20} />
            <h3 className="text-sm font-medium text-red-800">
              Atenção: {recentAbandonedContracts.length} desistência(s) recente(s)
            </h3>
          </div>
          <div className="space-y-2">
            {recentAbandonedContracts.map((contract) => (
              <div key={contract.id} className="bg-white rounded-md p-3 border border-red-100">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{contract.clientName}</p>
                    <p className="text-xs text-gray-600">{contract.type}</p>
                    <div className="mt-1">
                      <ProtectedContent requiredRole="admin" showFallback={false}>
                        <p className="text-xs text-gray-600">
                          Valor: R$ {contract.value.toLocaleString('pt-BR')}
                        </p>
                      </ProtectedContent>
                    </div>
                    <p className="text-xs text-red-600 mt-1">
                      <strong>Motivo:</strong> {contract.cancelReason}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-500">Vendedor: {contract.salesPerson}</p>
                    <p className="text-xs text-gray-500">
                      Desistiu em: {contract.canceledAt ? new Date(contract.canceledAt).toLocaleDateString('pt-BR') : '-'}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 text-xs text-red-700">
            <strong>Recomendação:</strong> Analisar os motivos das desistências para melhorar o processo de vendas e qualificação de leads.
          </div>
        </div>
      )}

      {/* Alertas de Prazos Urgentes */}
      {urgentDeadlines.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="text-red-600" size={20} />
            <h2 className="text-lg font-semibold text-gray-900">
              Prazos Urgentes ({urgentDeadlines.length})
            </h2>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {urgentDeadlines.slice(0, 4).map((deadline) => {
              const process = mockProcesses.find(p => p.id === deadline.processId);
              return (
                <DeadlineAlert
                  key={deadline.id}
                  deadline={deadline}
                  clientName={process?.clientName || 'Cliente não encontrado'}
                  onMarkComplete={handleMarkDeadlineComplete}
                  onScheduleAppointment={handleScheduleAppointment}
                />
              );
            })}
          </div>
          {urgentDeadlines.length > 4 && (
            <div className="text-center">
              <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                Ver todos os {urgentDeadlines.length} prazos urgentes
              </button>
            </div>
          )}
        </div>
      )}

      {/* Gráficos e Visualizações */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <BarChart
          title="Entradas de Processos por Mês"
          data={monthlyProcessEntriesData}
        />
        <BarChart
          title={`${months[selectedMonth]} ${selectedYear} - Admin vs Judicial`}
          data={monthlyAdminVsJudicialData}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <BarChart
          title="Fluxo de Judicialização"
          data={judicialTrackingChartData}
        />
        <BarChart
          title="Comparativo: Taxa de Aprovação (%)"
          data={judicialVsAdminData}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <PieChart
          title="Status dos Processos"
          data={processStatusData}
        />
        <PieChart
          title="Decisões sobre Judicialização"
          data={judicialDecisionData}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <BarChart
          title="Conversão de Leads por Mês"
          data={conversionData}
        />
        <PieChart
          title="Status dos Contratos"
          data={contractStatusData}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <BarChart
          title="Desempenho da Equipe (Contratos/Mês)"
          data={teamPerformance}
        />
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Análise Comparativa</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <CheckCircle className="text-blue-600" size={20} />
                <span className="font-medium text-gray-900">Taxa Aprovação Administrativa</span>
              </div>
              <span className="text-xl font-bold text-blue-600">{mockStats.adminApprovalRate}%</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <Scale className="text-green-600" size={20} />
                <span className="font-medium text-gray-900">Taxa Aprovação Judicial</span>
              </div>
              <span className="text-xl font-bold text-green-600">{mockStats.judicialSuccessRate}%</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-indigo-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <ArrowRight className="text-indigo-600" size={20} />
                <span className="font-medium text-gray-900">Taxa Judicialização</span>
              </div>
              <span className="text-xl font-bold text-indigo-600">{mockStats.taxaJudicializacaoNegados}%</span>
            </div>
            <div className="mt-4 p-3 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-600">
                <strong>Insight:</strong> A taxa judicial está {mockStats.judicialSuccessRate > mockStats.adminApprovalRate ? 'superior' : 'inferior'} à administrativa, 
                indicando {mockStats.judicialSuccessRate > mockStats.adminApprovalRate ? 'boa estratégia de judicialização' : 'necessidade de revisar critérios de judicialização'}.
                {mockStats.taxaDesistenciaJudicial > 20 && (
                  <span className="text-red-600"> Atenção: Taxa de desistência judicial alta ({mockStats.taxaDesistenciaJudicial}%).</span>
                )}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Resumo de Alertas */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Resumo de Alertas</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
          <div className="flex items-center space-x-3 p-3 bg-red-50 rounded-lg">
            <AlertTriangle className="text-red-500" size={20} />
            <div>
              <p className="text-sm font-medium text-gray-900">{mockStats.overdueDeadlines} prazos vencidos</p>
              <p className="text-xs text-gray-600">Requer ação imediata</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 p-3 bg-yellow-50 rounded-lg">
            <Clock className="text-yellow-500" size={20} />
            <div>
              <p className="text-sm font-medium text-gray-900">{mockStats.pendingDeadlines} prazos pendentes</p>
              <p className="text-xs text-gray-600">Acompanhar de perto</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 p-3 bg-red-50 rounded-lg">
            <UserX className="text-red-500" size={20} />
            <div>
              <p className="text-sm font-medium text-gray-900">{mockStats.abandonedContracts} desistências</p>
              <p className="text-xs text-gray-600">Taxa: {mockStats.contractAbandonmentRate}%</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
            <CheckCircle className="text-green-500" size={20} />
            <div>
              <p className="text-sm font-medium text-gray-900">{mockProcesses.filter(p => p.status === 'deferido').length} deferidos</p>
              <p className="text-xs text-gray-600">Administrativos</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
            <Scale className="text-blue-500" size={20} />
            <div>
              <p className="text-sm font-medium text-gray-900">{procedenteJudicial.length} procedentes</p>
              <p className="text-xs text-gray-600">Judiciais</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
            <UserMinus className="text-purple-500" size={20} />
            <div>
              <p className="text-sm font-medium text-gray-900">{judicialTrackingData.clientesDesistiram} desistiram</p>
              <p className="text-xs text-gray-600">Ação judicial</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;