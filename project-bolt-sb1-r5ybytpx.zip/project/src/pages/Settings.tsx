import React, { useState } from 'react';
import { Users, Settings as SettingsIcon, Database, Shield, Bell, Globe, Calendar } from 'lucide-react';
import UserManagement from '../components/Settings/UserManagement';
import SystemSettings from '../components/Settings/SystemSettings';
import GoogleCalendarIntegration from '../components/Calendar/GoogleCalendarIntegration';
import { mockUsers } from '../data/mockData';

const Settings: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'users' | 'system' | 'security' | 'integrations' | 'calendar'>('users');
  const [users, setUsers] = useState(mockUsers);

  const tabs = [
    { id: 'users', label: 'Usuários & Equipes', icon: Users },
    { id: 'system', label: 'Sistema', icon: SettingsIcon },
    { id: 'calendar', label: 'Google Agenda', icon: Calendar },
    { id: 'security', label: 'Segurança', icon: Shield },
    { id: 'integrations', label: 'Integrações', icon: Globe },
  ];

  const renderSecuritySettings = () => (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-gray-900">Configurações de Segurança</h3>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <div className="flex items-center space-x-2 mb-4">
            <Shield className="text-red-600" size={20} />
            <h4 className="text-md font-medium text-gray-900">Autenticação</h4>
          </div>
          
          <div className="space-y-4">
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                defaultChecked
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">Autenticação de dois fatores (2FA)</span>
            </label>
            
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                defaultChecked
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">Login único (SSO)</span>
            </label>
            
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">Permitir login via Google</span>
            </label>
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <div className="flex items-center space-x-2 mb-4">
            <Database className="text-blue-600" size={20} />
            <h4 className="text-md font-medium text-gray-900">Logs de Auditoria</h4>
          </div>
          
          <div className="space-y-4">
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                defaultChecked
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">Registrar logins</span>
            </label>
            
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                defaultChecked
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">Registrar alterações de dados</span>
            </label>
            
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">Registrar acessos a documentos</span>
            </label>
          </div>
        </div>
      </div>
    </div>
  );

  const renderIntegrationsSettings = () => (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-gray-900">Integrações</h3>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">CRM</span>
              </div>
              <div>
                <h4 className="text-md font-medium text-gray-900">Sistema CRM</h4>
                <p className="text-sm text-gray-500">Integração com CRM externo</p>
              </div>
            </div>
            <button className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
              Conectado
            </button>
          </div>
          <button className="w-full px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            Configurar
          </button>
        </div>

        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 bg-green-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">WA</span>
              </div>
              <div>
                <h4 className="text-md font-medium text-gray-900">WhatsApp Business</h4>
                <p className="text-sm text-gray-500">Envio de mensagens automáticas</p>
              </div>
            </div>
            <button className="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-medium">
              Desconectado
            </button>
          </div>
          <button className="w-full px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
            Conectar
          </button>
        </div>

        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 bg-red-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">GM</span>
              </div>
              <div>
                <h4 className="text-md font-medium text-gray-900">Gmail</h4>
                <p className="text-sm text-gray-500">Sincronização de emails</p>
              </div>
            </div>
            <button className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
              Conectado
            </button>
          </div>
          <button className="w-full px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            Configurar
          </button>
        </div>

        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 bg-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">PJ</span>
              </div>
              <div>
                <h4 className="text-md font-medium text-gray-900">PJe - Processo Judicial</h4>
                <p className="text-sm text-gray-500">Consulta automática de processos</p>
              </div>
            </div>
            <button className="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-medium">
              Desconectado
            </button>
          </div>
          <button className="w-full px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700">
            Conectar
          </button>
        </div>

        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 bg-blue-500 rounded-lg flex items-center justify-center">
                <Calendar className="text-white" size={20} />
              </div>
              <div>
                <h4 className="text-md font-medium text-gray-900">Google Agenda</h4>
                <p className="text-sm text-gray-500">Agendamento de perícias e avaliações</p>
              </div>
            </div>
            <button className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
              Conectado
            </button>
          </div>
          <button className="w-full px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            Configurar
          </button>
        </div>

        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 bg-indigo-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">ZP</span>
              </div>
              <div>
                <h4 className="text-md font-medium text-gray-900">Zapier</h4>
                <p className="text-sm text-gray-500">Automação de workflows</p>
              </div>
            </div>
            <button className="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-medium">
              Desconectado
            </button>
          </div>
          <button className="w-full px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
            Conectar
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Configurações</h1>
        <div className="flex items-center space-x-2 text-sm text-gray-500">
          <SettingsIcon size={16} />
          <span>Painel de Administração</span>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Users className="text-blue-600" size={20} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Total de Usuários</p>
              <p className="text-2xl font-bold text-gray-900">{users.length}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-green-100 rounded-lg">
              <Users className="text-green-600" size={20} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Usuários Ativos</p>
              <p className="text-2xl font-bold text-gray-900">
                {users.filter(u => u.status === 'ativo').length}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Shield className="text-purple-600" size={20} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Administradores</p>
              <p className="text-2xl font-bold text-gray-900">
                {users.filter(u => u.role === 'admin').length}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-yellow-100 rounded-lg">
              <Globe className="text-yellow-600" size={20} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Integrações Ativas</p>
              <p className="text-2xl font-bold text-gray-900">3</p>
            </div>
          </div>
        </div>
      </div>

      {/* Settings Tabs */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 text-sm font-medium border-b-2 ${
                    activeTab === tab.id
                      ? 'text-blue-600 border-blue-600'
                      : 'text-gray-500 border-transparent hover:text-gray-700'
                  }`}
                >
                  <Icon size={16} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'users' && (
            <UserManagement users={users} onUpdateUsers={setUsers} />
          )}
          {activeTab === 'system' && <SystemSettings />}
          {activeTab === 'calendar' && <GoogleCalendarIntegration />}
          {activeTab === 'security' && renderSecuritySettings()}
          {activeTab === 'integrations' && renderIntegrationsSettings()}
        </div>
      </div>
    </div>
  );
};

export default Settings;