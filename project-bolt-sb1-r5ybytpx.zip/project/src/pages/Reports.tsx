import React, { useState } from 'react';
import { Download, Filter, Calendar, BarChart3, PieChart as PieChartIcon, FileText } from 'lucide-react';
import MetricCard from '../components/Charts/MetricCard';
import BarChart from '../components/Charts/BarChart';
import PieChart from '../components/Charts/PieChart';
import ProtectedContent from '../components/Common/ProtectedContent';
import DateFilter from '../components/Common/DateFilter';
import { mockLeads, mockContracts, mockProcesses } from '../data/mockData';
import { useAuth } from '../context/AuthContext';

const Reports: React.FC = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('month');
  const [selectedReport, setSelectedReport] = useState('overview');
  const [showDateFilter, setShowDateFilter] = useState(false);
  const [startDate, setStartDate] = useState('2024-01-01');
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedPreset, setSelectedPreset] = useState('this_month');
  const { canViewRevenue } = useAuth();

  const reportTypes = [
    { id: 'overview', label: 'Visão Geral', icon: BarChart3 },
    { id: 'sales', label: 'Vendas & Conversão', icon: PieChartIcon },
    { id: 'processes', label: 'Processos', icon: FileText },
  ];

  // Filter data by date range
  const filterByDateRange = (data: any[], dateField: string) => {
    return data.filter(item => {
      const itemDate = new Date(item[dateField]);
      const start = new Date(startDate);
      const end = new Date(endDate);
      return itemDate >= start && itemDate <= end;
    });
  };

  const filteredLeads = filterByDateRange(mockLeads, 'createdAt');
  const filteredContracts = filterByDateRange(mockContracts, 'createdAt');
  const filteredProcesses = filterByDateRange(mockProcesses, 'createdAt');

  // Sales funnel data
  const salesFunnelData = [
    { label: 'Leads Gerados', value: filteredLeads.length },
    { label: 'Contatos Realizados', value: Math.floor(filteredLeads.length * 0.84) },
    { label: 'Propostas Enviadas', value: Math.floor(filteredLeads.length * 0.71) },
    { label: 'Contratos Fechados', value: filteredContracts.length },
  ];

  // Process success rates
  const processSuccessData = [
    { label: 'Administrativos Deferidos', value: filteredProcesses.filter(p => p.type === 'administrativo' && p.status === 'deferido').length, color: '#10B981' },
    { label: 'Administrativos Negados', value: filteredProcesses.filter(p => p.type === 'administrativo' && p.status === 'negado').length, color: '#EF4444' },
    { label: 'Judiciais Procedentes', value: filteredProcesses.filter(p => p.type === 'judicial' && p.status === 'procedente').length, color: '#3B82F6' },
    { label: 'Judiciais Improcedentes', value: filteredProcesses.filter(p => p.type === 'judicial' && p.status === 'improcedente').length, color: '#F59E0B' },
  ];

  // Monthly performance
  const monthlyPerformance = [
    { label: 'Jan', value: 85000 },
    { label: 'Fev', value: 92000 },
    { label: 'Mar', value: 78000 },
    { label: 'Abr', value: 105000 },
    { label: 'Mai', value: 118000 },
    { label: 'Jun', value: 98000 },
  ];

  // Lead sources
  const leadSourcesData = [
    { label: 'Google Ads', value: Math.floor(filteredLeads.length * 0.35), color: '#3B82F6' },
    { label: 'Facebook', value: Math.floor(filteredLeads.length * 0.28), color: '#1877F2' },
    { label: 'Instagram', value: Math.floor(filteredLeads.length * 0.15), color: '#E4405F' },
    { label: 'Indicações', value: Math.floor(filteredLeads.length * 0.22), color: '#10B981' },
  ];

  // Calculate judicial metrics
  const judicialProcesses = filteredProcesses.filter(p => p.type === 'judicial');
  const completedJudicial = judicialProcesses.filter(p => p.status === 'procedente' || p.status === 'improcedente');
  const procedenteJudicial = judicialProcesses.filter(p => p.status === 'procedente');
  const judicialApprovalRate = completedJudicial.length > 0 ? 
    ((procedenteJudicial.length / completedJudicial.length) * 100).toFixed(1) : '0';

  // Calculate administrative metrics
  const adminProcesses = filteredProcesses.filter(p => p.type === 'administrativo');
  const completedAdmin = adminProcesses.filter(p => p.status === 'deferido' || p.status === 'negado');
  const deferredAdmin = adminProcesses.filter(p => p.status === 'deferido');
  const adminApprovalRate = completedAdmin.length > 0 ? 
    ((deferredAdmin.length / completedAdmin.length) * 100).toFixed(1) : '0';

  const totalRevenue = filteredContracts.reduce((sum, c) => sum + c.value, 0);
  const conversionRate = filteredLeads.length > 0 ? ((filteredContracts.length / filteredLeads.length) * 100).toFixed(1) : '0';

  const renderOverviewReport = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <MetricCard
          title="Leads Totais"
          value={filteredLeads.length}
          icon={BarChart3}
          color="blue"
        />
        <MetricCard
          title="Taxa Conversão"
          value={`${conversionRate}%`}
          icon={PieChartIcon}
          color="green"
        />
        
        {/* Protected Revenue Metric */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-600">Receita Total</p>
              <div className="mt-2">
                <ProtectedContent requiredRole="admin" showFallback={true}>
                  <p className="text-2xl font-bold text-gray-900">
                    R$ {totalRevenue.toLocaleString('pt-BR')}
                  </p>
                  <p className="text-sm text-green-600 mt-2">
                    Período selecionado
                  </p>
                </ProtectedContent>
              </div>
            </div>
            <div className="p-3 rounded-full bg-green-500 text-green-100">
              <FileText size={24} />
            </div>
          </div>
        </div>
        
        <MetricCard
          title="Processos Ativos"
          value={filteredProcesses.filter(p => p.status === 'em_andamento').length}
          icon={Calendar}
          color="yellow"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Protected Revenue Chart */}
        <ProtectedContent requiredRole="admin" showFallback={true}>
          <BarChart
            title="Performance Mensal (R$ em milhares)"
            data={monthlyPerformance.map(item => ({ 
              ...item, 
              value: Math.round(item.value / 1000) // Convert to thousands
            }))}
          />
        </ProtectedContent>
        
        <PieChart
          title="Origem dos Leads"
          data={leadSourcesData}
        />
      </div>
    </div>
  );

  const renderSalesReport = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <BarChart
          title="Funil de Vendas"
          data={salesFunnelData}
        />
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Métricas de Conversão</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Lead → Contato</span>
              <span className="font-medium">
                {filteredLeads.length > 0 ? ((salesFunnelData[1].value / salesFunnelData[0].value) * 100).toFixed(1) : '0'}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Contato → Proposta</span>
              <span className="font-medium">
                {salesFunnelData[1].value > 0 ? ((salesFunnelData[2].value / salesFunnelData[1].value) * 100).toFixed(1) : '0'}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Proposta → Fechamento</span>
              <span className="font-medium">
                {salesFunnelData[2].value > 0 ? ((salesFunnelData[3].value / salesFunnelData[2].value) * 100).toFixed(1) : '0'}%
              </span>
            </div>
            <div className="border-t pt-4">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-900">Conversão Geral</span>
                <span className="font-bold text-green-600">{conversionRate}%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <PieChart
        title="Distribuição de Origem dos Leads"
        data={leadSourcesData}
      />
    </div>
  );

  const renderProcessesReport = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <MetricCard
          title="Taxa Sucesso Admin"
          value={`${adminApprovalRate}%`}
          icon={BarChart3}
          color="green"
        />
        <MetricCard
          title="Taxa Sucesso Judicial"
          value={`${judicialApprovalRate}%`}
          icon={PieChartIcon}
          color="blue"
        />
        <MetricCard
          title="Processos Judiciais"
          value={judicialProcesses.length}
          icon={FileText}
          color="purple"
        />
        <MetricCard
          title="Média Duração (dias)"
          value="45"
          icon={Calendar}
          color="yellow"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <PieChart
          title="Resultados dos Processos"
          data={processSuccessData}
        />
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Análise Detalhada por Tipo</h3>
          <div className="space-y-4">
            <div className="bg-blue-50 rounded-lg p-4">
              <h4 className="font-medium text-blue-900 mb-2">Processos Administrativos</h4>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-blue-700">Total de Processos</span>
                  <span className="font-medium text-blue-900">{adminProcesses.length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-blue-700">Deferidos</span>
                  <span className="font-medium text-green-600">{deferredAdmin.length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-blue-700">Negados</span>
                  <span className="font-medium text-red-600">{adminProcesses.filter(p => p.status === 'negado').length}</span>
                </div>
                <div className="flex justify-between items-center border-t pt-2">
                  <span className="text-sm font-medium text-blue-900">Taxa de Aprovação</span>
                  <span className="font-bold text-green-600">{adminApprovalRate}%</span>
                </div>
              </div>
            </div>

            <div className="bg-green-50 rounded-lg p-4">
              <h4 className="font-medium text-green-900 mb-2">Processos Judiciais</h4>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-green-700">Total de Processos</span>
                  <span className="font-medium text-green-900">{judicialProcesses.length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-green-700">Procedentes</span>
                  <span className="font-medium text-green-600">{procedenteJudicial.length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-green-700">Improcedentes</span>
                  <span className="font-medium text-red-600">{judicialProcesses.filter(p => p.status === 'improcedente').length}</span>
                </div>
                <div className="flex justify-between items-center border-t pt-2">
                  <span className="text-sm font-medium text-green-900">Taxa de Aprovação</span>
                  <span className="font-bold text-blue-600">{judicialApprovalRate}%</span>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-2">Comparativo de Performance</h4>
              <p className="text-sm text-gray-600">
                {parseFloat(judicialApprovalRate) > parseFloat(adminApprovalRate) ? (
                  <>
                    <strong className="text-green-600">✓ Judicial superior:</strong> A taxa judicial ({judicialApprovalRate}%) 
                    está {(parseFloat(judicialApprovalRate) - parseFloat(adminApprovalRate)).toFixed(1)} pontos acima da administrativa, 
                    indicando boa estratégia de judicialização.
                  </>
                ) : (
                  <>
                    <strong className="text-yellow-600">⚠ Revisar estratégia:</strong> A taxa administrativa ({adminApprovalRate}%) 
                    está superior à judicial ({judicialApprovalRate}%), sugerindo revisão dos critérios de judicialização.
                  </>
                )}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Relatórios e Análises</h1>
        <div className="flex space-x-3">
          <button
            onClick={() => setShowDateFilter(!showDateFilter)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg border ${
              showDateFilter 
                ? 'bg-blue-600 text-white border-blue-600' 
                : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
            }`}
          >
            <Calendar size={16} />
            <span>Filtro por Data</span>
          </button>
          <select
            value={selectedPeriod}
            onChange={(e) => setSelectedPeriod(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            <option value="week">Esta Semana</option>
            <option value="month">Este Mês</option>
            <option value="quarter">Este Trimestre</option>
            <option value="year">Este Ano</option>
          </select>
          <button className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Filter size={16} />
            <span>Filtros</span>
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <Download size={16} />
            <span>Exportar PDF</span>
          </button>
        </div>
      </div>

      {/* Date Filter */}
      {showDateFilter && (
        <DateFilter
          startDate={startDate}
          endDate={endDate}
          onStartDateChange={setStartDate}
          onEndDateChange={setEndDate}
          onPresetSelect={setSelectedPreset}
        />
      )}

      {/* Period Summary */}
      {showDateFilter && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <Calendar className="text-blue-600" size={20} />
            <div>
              <h3 className="text-sm font-medium text-blue-800">
                📊 Relatório do Período: {new Date(startDate).toLocaleDateString('pt-BR')} até {new Date(endDate).toLocaleDateString('pt-BR')}
              </h3>
              <p className="text-sm text-blue-700 mt-1">
                {filteredLeads.length} leads, {filteredContracts.length} contratos e {filteredProcesses.length} processos no período
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Access Level Notice */}
      {!canViewRevenue() && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-yellow-100 rounded-full">
              <FileText className="text-yellow-600" size={16} />
            </div>
            <div>
              <h3 className="text-sm font-medium text-yellow-800">
                📊 Relatórios com Acesso Limitado
              </h3>
              <p className="text-sm text-yellow-700 mt-1">
                Alguns dados financeiros estão ocultos. Para acesso completo aos relatórios de faturamento, 
                entre em contato com um administrador do sistema.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Report Type Selector */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {reportTypes.map((report) => {
              const Icon = report.icon;
              return (
                <button
                  key={report.id}
                  onClick={() => setSelectedReport(report.id)}
                  className={`flex items-center space-x-2 py-4 text-sm font-medium border-b-2 ${
                    selectedReport === report.id
                      ? 'text-blue-600 border-blue-600'
                      : 'text-gray-500 border-transparent hover:text-gray-700'
                  }`}
                >
                  <Icon size={16} />
                  <span>{report.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {selectedReport === 'overview' && renderOverviewReport()}
          {selectedReport === 'sales' && renderSalesReport()}
          {selectedReport === 'processes' && renderProcessesReport()}
        </div>
      </div>

      {/* Export Options */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Opções de Exportação</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="flex items-center justify-center space-x-2 px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50">
            <FileText size={20} />
            <span>Relatório PDF</span>
          </button>
          <button className="flex items-center justify-center space-x-2 px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50">
            <Download size={20} />
            <span>Planilha Excel</span>
          </button>
          <button className="flex items-center justify-center space-x-2 px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50">
            <BarChart3 size={20} />
            <span>Dashboard Executivo</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Reports;