import React, { useState } from 'react';
import { Upload, Download, Eye, AlertTriangle, CheckCircle, Clock, Edit, Plus, Filter, FileText, Tag, Calendar, TrendingUp, ArrowRight, Target } from 'lucide-react';
import DataTable from '../components/Tables/DataTable';
import MetricCard from '../components/Charts/MetricCard';
import BarChart from '../components/Charts/BarChart';
import PieChart from '../components/Charts/PieChart';
import DocumentEditForm from '../components/Forms/DocumentEditForm';
import { mockProcesses } from '../data/mockData';

interface ExtendedDocument {
  id: string;
  name: string;
  status: 'pendente' | 'completo' | 'revisado';
  uploadedAt?: string;
  processId: string;
  clientName: string;
  processType: string;
  processCategory: string;
  reviewedBy?: string;
  reviewedAt?: string;
  notes?: string;
  priority?: 'baixa' | 'media' | 'alta' | 'critica';
  expirationDate?: string;
  fileSize?: string;
  fileType?: string;
  version?: number;
  tags?: string[];
  // New fields for effectiveness tracking
  processStarted?: boolean;
  processStartDate?: string;
  effectivenessStatus?: 'aguardando' | 'efetivado' | 'nao_efetivado' | 'em_analise';
  daysToProcess?: number;
}

const Documents: React.FC = () => {
  const [selectedStatus, setSelectedStatus] = useState<'all' | 'pendente' | 'completo' | 'revisado'>('all');
  const [selectedPriority, setSelectedPriority] = useState<'all' | 'baixa' | 'media' | 'alta' | 'critica'>('all');
  const [selectedEffectiveness, setSelectedEffectiveness] = useState<'all' | 'aguardando' | 'efetivado' | 'nao_efetivado' | 'em_analise'>('all');
  const [editingDocument, setEditingDocument] = useState<ExtendedDocument | null>(null);
  const [showBulkActions, setShowBulkActions] = useState(false);
  const [selectedDocuments, setSelectedDocuments] = useState<string[]>([]);

  // Flatten all documents from all processes with extended information including effectiveness tracking
  const allDocuments: ExtendedDocument[] = mockProcesses.flatMap(process => 
    process.documents.map(doc => {
      // Simulate effectiveness data based on document status and process status
      const isProcessStarted = process.status !== 'em_andamento' || Math.random() > 0.3;
      const effectivenessStatus = doc.status === 'pendente' ? 'aguardando' :
                                 doc.status === 'completo' && !isProcessStarted ? 'em_analise' :
                                 doc.status === 'completo' && isProcessStarted ? 'efetivado' :
                                 doc.status === 'revisado' && isProcessStarted ? 'efetivado' :
                                 'nao_efetivado';
      
      const daysToProcess = isProcessStarted && doc.uploadedAt ? 
        Math.floor(Math.random() * 30) + 1 : undefined;

      return {
        ...doc,
        clientName: process.clientName,
        processType: process.type,
        processCategory: process.category,
        // Add mock extended data
        reviewedBy: doc.status === 'revisado' ? 'Dr. Braga' : undefined,
        reviewedAt: doc.status === 'revisado' ? '2024-03-01' : undefined,
        notes: doc.status === 'revisado' ? 'Documento aprovado após análise' : 
               doc.status === 'pendente' ? 'Aguardando envio pelo cliente' : 
               'Documento recebido e validado',
        priority: doc.status === 'pendente' ? 'alta' : 'media',
        expirationDate: doc.name.includes('Laudo') ? '2024-12-31' : undefined,
        fileSize: doc.status !== 'pendente' ? '2.5 MB' : undefined,
        fileType: doc.name.includes('Laudo') || doc.name.includes('Atestado') ? 'PDF' : 
                  doc.name.includes('CTPS') ? 'JPG' : 'PDF',
        version: 1,
        tags: doc.name.includes('Laudo') ? ['Médico', 'Urgente'] :
              doc.name.includes('CTPS') ? ['Trabalhista', 'Comprovante'] :
              doc.name.includes('PPP') ? ['Trabalhista', 'Especial'] :
              ['Administrativo'],
        // New effectiveness tracking fields
        processStarted: isProcessStarted,
        processStartDate: isProcessStarted ? '2024-03-01' : undefined,
        effectivenessStatus: effectivenessStatus as ExtendedDocument['effectivenessStatus'],
        daysToProcess: daysToProcess
      };
    })
  );

  const [documents, setDocuments] = useState<ExtendedDocument[]>(allDocuments);

  const filteredDocuments = documents.filter(doc => {
    const statusMatch = selectedStatus === 'all' || doc.status === selectedStatus;
    const priorityMatch = selectedPriority === 'all' || doc.priority === selectedPriority;
    const effectivenessMatch = selectedEffectiveness === 'all' || doc.effectivenessStatus === selectedEffectiveness;
    return statusMatch && priorityMatch && effectivenessMatch;
  });

  const documentColumns = [
    { 
      key: 'select', 
      label: '',
      render: (value: any, row: ExtendedDocument) => (
        <input
          type="checkbox"
          checked={selectedDocuments.includes(row.id)}
          onChange={(e) => {
            if (e.target.checked) {
              setSelectedDocuments([...selectedDocuments, row.id]);
            } else {
              setSelectedDocuments(selectedDocuments.filter(id => id !== row.id));
            }
          }}
          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
        />
      )
    },
    { key: 'clientName', label: 'Cliente', sortable: true },
    { 
      key: 'name', 
      label: 'Documento', 
      sortable: true,
      render: (name: string, row: ExtendedDocument) => (
        <div>
          <div className="font-medium text-gray-900">{name}</div>
          <div className="text-xs text-gray-500">
            {row.fileType} • v{row.version} • {row.fileSize || 'Tamanho não definido'}
          </div>
        </div>
      )
    },
    { key: 'processCategory', label: 'Categoria do Processo' },
    { 
      key: 'processType', 
      label: 'Tipo',
      render: (type: string) => (
        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
          type === 'administrativo' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'
        }`}>
          {type}
        </span>
      )
    },
    { 
      key: 'priority', 
      label: 'Prioridade',
      render: (priority: string) => {
        const priorityColors = {
          baixa: 'bg-gray-100 text-gray-800',
          media: 'bg-yellow-100 text-yellow-800',
          alta: 'bg-orange-100 text-orange-800',
          critica: 'bg-red-100 text-red-800'
        };
        return (
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${priorityColors[priority as keyof typeof priorityColors] || 'bg-gray-100 text-gray-800'}`}>
            {priority || 'média'}
          </span>
        );
      }
    },
    { 
      key: 'status', 
      label: 'Status',
      render: (status: string, row: ExtendedDocument) => {
        const statusConfig = {
          pendente: { color: 'bg-yellow-100 text-yellow-800', icon: Clock, label: 'Pendente' },
          completo: { color: 'bg-green-100 text-green-800', icon: CheckCircle, label: 'Completo' },
          revisado: { color: 'bg-blue-100 text-blue-800', icon: Eye, label: 'Revisado' }
        };
        const config = statusConfig[status as keyof typeof statusConfig];
        const Icon = config.icon;
        return (
          <div className="flex items-center space-x-2">
            <Icon size={16} className={status === 'pendente' ? 'text-yellow-600' : status === 'completo' ? 'text-green-600' : 'text-blue-600'} />
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${config.color}`}>
              {config.label}
            </span>
            {row.expirationDate && new Date(row.expirationDate) < new Date() && (
              <AlertTriangle size={14} className="text-red-500" title="Documento expirado" />
            )}
          </div>
        );
      }
    },
    {
      key: 'effectivenessStatus',
      label: 'Efetivação',
      render: (effectivenessStatus: string, row: ExtendedDocument) => {
        const effectivenessConfig = {
          aguardando: { color: 'bg-gray-100 text-gray-800', icon: Clock, label: 'Aguardando' },
          em_analise: { color: 'bg-yellow-100 text-yellow-800', icon: Eye, label: 'Em Análise' },
          efetivado: { color: 'bg-green-100 text-green-800', icon: CheckCircle, label: 'Efetivado' },
          nao_efetivado: { color: 'bg-red-100 text-red-800', icon: AlertTriangle, label: 'Não Efetivado' }
        };
        const config = effectivenessConfig[effectivenessStatus as keyof typeof effectivenessConfig];
        if (!config) return <span className="text-gray-400 text-xs">-</span>;
        
        const Icon = config.icon;
        return (
          <div className="flex items-center space-x-2">
            <Icon size={14} className={
              effectivenessStatus === 'efetivado' ? 'text-green-600' :
              effectivenessStatus === 'em_analise' ? 'text-yellow-600' :
              effectivenessStatus === 'nao_efetivado' ? 'text-red-600' :
              'text-gray-600'
            } />
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${config.color}`}>
              {config.label}
            </span>
            {row.daysToProcess && effectivenessStatus === 'efetivado' && (
              <span className="text-xs text-gray-500">({row.daysToProcess}d)</span>
            )}
          </div>
        );
      }
    },
    { 
      key: 'tags', 
      label: 'Tags',
      render: (tags: string[]) => (
        <div className="flex flex-wrap gap-1">
          {(tags || []).slice(0, 2).map((tag, index) => (
            <span key={index} className="px-2 py-1 bg-gray-100 text-gray-700 rounded-full text-xs">
              {tag}
            </span>
          ))}
          {(tags || []).length > 2 && (
            <span className="text-xs text-gray-500">+{(tags || []).length - 2}</span>
          )}
        </div>
      )
    },
    { 
      key: 'uploadedAt', 
      label: 'Data Upload',
      render: (date: string) => date ? new Date(date).toLocaleDateString('pt-BR') : '-'
    },
    { 
      key: 'processStartDate', 
      label: 'Entrada Processo',
      render: (date: string, row: ExtendedDocument) => {
        if (!date) return <span className="text-gray-400 text-xs">-</span>;
        return (
          <div className="flex items-center space-x-1">
            <ArrowRight size={12} className="text-green-600" />
            <span className="text-xs text-gray-900">{new Date(date).toLocaleDateString('pt-BR')}</span>
          </div>
        );
      }
    },
    {
      key: 'actions',
      label: 'Ações',
      render: (value: any, row: ExtendedDocument) => (
        <div className="flex space-x-2">
          <button
            onClick={() => setEditingDocument(row)}
            className="text-blue-600 hover:text-blue-800"
            title="Editar documento"
          >
            <Edit size={16} />
          </button>
          {row.status === 'pendente' ? (
            <button className="flex items-center space-x-1 text-blue-600 hover:text-blue-800 text-sm">
              <Upload size={14} />
              <span>Upload</span>
            </button>
          ) : (
            <>
              <button className="text-green-600 hover:text-green-800" title="Visualizar">
                <Eye size={16} />
              </button>
              <button className="text-purple-600 hover:text-purple-800" title="Download">
                <Download size={16} />
              </button>
            </>
          )}
        </div>
      )
    }
  ];

  const handleSaveDocument = (updatedDocument: ExtendedDocument) => {
    setDocuments(docs => 
      docs.map(doc => doc.id === updatedDocument.id ? updatedDocument : doc)
    );
    setEditingDocument(null);
  };

  const handleBulkStatusUpdate = (newStatus: 'pendente' | 'completo' | 'revisado') => {
    setDocuments(docs => 
      docs.map(doc => 
        selectedDocuments.includes(doc.id) 
          ? { ...doc, status: newStatus, uploadedAt: newStatus !== 'pendente' ? new Date().toISOString().split('T')[0] : doc.uploadedAt }
          : doc
      )
    );
    setSelectedDocuments([]);
    setShowBulkActions(false);
  };

  const handleSelectAll = () => {
    if (selectedDocuments.length === filteredDocuments.length) {
      setSelectedDocuments([]);
    } else {
      setSelectedDocuments(filteredDocuments.map(doc => doc.id));
    }
  };

  // Calculate effectiveness metrics
  const pendingCount = documents.filter(doc => doc.status === 'pendente').length;
  const completeCount = documents.filter(doc => doc.status === 'completo').length;
  const reviewedCount = documents.filter(doc => doc.status === 'revisado').length;
  const expiredCount = documents.filter(doc => 
    doc.expirationDate && new Date(doc.expirationDate) < new Date()
  ).length;
  const completionRate = ((completeCount + reviewedCount) / documents.length * 100).toFixed(1);

  // New effectiveness metrics
  const completedDocuments = documents.filter(doc => doc.status === 'completo' || doc.status === 'revisado');
  const effectivatedDocuments = documents.filter(doc => doc.effectivenessStatus === 'efetivado');
  const effectivenessRate = completedDocuments.length > 0 ? 
    ((effectivatedDocuments.length / completedDocuments.length) * 100).toFixed(1) : '0';
  
  const inAnalysisCount = documents.filter(doc => doc.effectivenessStatus === 'em_analise').length;
  const notEffectivatedCount = documents.filter(doc => doc.effectivenessStatus === 'nao_efetivado').length;
  const avgDaysToProcess = effectivatedDocuments.filter(doc => doc.daysToProcess).length > 0 ?
    Math.round(effectivatedDocuments.filter(doc => doc.daysToProcess).reduce((sum, doc) => sum + (doc.daysToProcess || 0), 0) / 
    effectivatedDocuments.filter(doc => doc.daysToProcess).length) : 0;

  // Chart data for effectiveness analysis
  const effectivenessChartData = [
    { label: 'Efetivados', value: effectivatedDocuments.length, color: 'bg-green-500' },
    { label: 'Em Análise', value: inAnalysisCount, color: 'bg-yellow-500' },
    { label: 'Não Efetivados', value: notEffectivatedCount, color: 'bg-red-500' },
    { label: 'Aguardando', value: documents.filter(doc => doc.effectivenessStatus === 'aguardando').length, color: 'bg-gray-500' }
  ];

  const effectivenessPieData = [
    { label: 'Efetivados', value: effectivatedDocuments.length, color: '#10B981' },
    { label: 'Em Análise', value: inAnalysisCount, color: '#F59E0B' },
    { label: 'Não Efetivados', value: notEffectivatedCount, color: '#EF4444' },
    { label: 'Aguardando', value: documents.filter(doc => doc.effectivenessStatus === 'aguardando').length, color: '#6B7280' }
  ];

  const monthlyEffectivenessData = [
    { label: 'Jan', value: 85 },
    { label: 'Fev', value: 92 },
    { label: 'Mar', value: 78 },
    { label: 'Abr', value: 88 },
    { label: 'Mai', value: 95 },
    { label: 'Jun', value: 82 }
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Gestão de Documentos</h1>
        <div className="flex space-x-3">
          {selectedDocuments.length > 0 && (
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-600">{selectedDocuments.length} selecionado(s)</span>
              <button
                onClick={() => setShowBulkActions(!showBulkActions)}
                className="flex items-center space-x-2 px-3 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200"
              >
                <Edit size={16} />
                <span>Ações em Lote</span>
              </button>
            </div>
          )}
          <button className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Download size={16} />
            <span>Exportar Lista</span>
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <Upload size={16} />
            <span>Upload em Lote</span>
          </button>
        </div>
      </div>

      {/* Bulk Actions Panel */}
      {showBulkActions && selectedDocuments.length > 0 && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-medium text-blue-800">
                Ações em Lote - {selectedDocuments.length} documento(s) selecionado(s)
              </h3>
              <p className="text-sm text-blue-700 mt-1">
                Escolha uma ação para aplicar a todos os documentos selecionados
              </p>
            </div>
            <div className="flex space-x-2">
              <button
                onClick={() => handleBulkStatusUpdate('completo')}
                className="px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm"
              >
                Marcar como Completo
              </button>
              <button
                onClick={() => handleBulkStatusUpdate('revisado')}
                className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm"
              >
                Marcar como Revisado
              </button>
              <button
                onClick={() => handleBulkStatusUpdate('pendente')}
                className="px-3 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 text-sm"
              >
                Marcar como Pendente
              </button>
              <button
                onClick={() => setShowBulkActions(false)}
                className="px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 text-sm"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Métricas de Documentos Expandidas */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-6">
        <MetricCard
          title="Documentos Pendentes"
          value={pendingCount}
          icon={Clock}
          color="yellow"
        />
        <MetricCard
          title="Documentos Completos"
          value={completeCount}
          icon={CheckCircle}
          color="green"
        />
        <MetricCard
          title="Taxa de Completude"
          value={`${completionRate}%`}
          icon={TrendingUp}
          color="blue"
        />
        <MetricCard
          title="Taxa de Efetivação"
          value={`${effectivenessRate}%`}
          icon={Target}
          color="purple"
        />
        <MetricCard
          title="Processos Efetivados"
          value={effectivatedDocuments.length}
          icon={ArrowRight}
          color="green"
        />
        <MetricCard
          title="Tempo Médio (dias)"
          value={avgDaysToProcess}
          icon={Calendar}
          color="blue"
        />
      </div>

      {/* Destaque da Taxa de Efetivação */}
      <div className="bg-gradient-to-r from-green-500 to-blue-600 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold mb-2">📄➡️⚖️ Efetivação de Documentos</h3>
            <p className="text-2xl font-bold">{effectivenessRate}%</p>
            <p className="text-green-100">dos documentos completos resultaram em entrada de processo</p>
          </div>
          <div className="text-right">
            <div className="bg-white bg-opacity-20 rounded-lg p-4">
              <p className="text-3xl font-bold">{effectivatedDocuments.length}/{completedDocuments.length}</p>
              <p className="text-sm text-green-100">Efetivados/Completos</p>
            </div>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-4 gap-4 text-center">
          <div>
            <p className="text-2xl font-bold">{effectivatedDocuments.length}</p>
            <p className="text-xs text-green-100">Efetivados</p>
          </div>
          <div>
            <p className="text-2xl font-bold">{inAnalysisCount}</p>
            <p className="text-xs text-green-100">Em Análise</p>
          </div>
          <div>
            <p className="text-2xl font-bold">{notEffectivatedCount}</p>
            <p className="text-xs text-green-100">Não Efetivados</p>
          </div>
          <div>
            <p className="text-2xl font-bold">{avgDaysToProcess}</p>
            <p className="text-xs text-green-100">Dias Médios</p>
          </div>
        </div>
      </div>

      {/* Gráficos de Análise de Efetivação */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <BarChart
          title="Status de Efetivação"
          data={effectivenessChartData}
        />
        <PieChart
          title="Distribuição de Efetivação"
          data={effectivenessPieData}
        />
        <BarChart
          title="Taxa de Efetivação Mensal (%)"
          data={monthlyEffectivenessData}
        />
      </div>

      {/* Alertas */}
      {pendingCount > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <AlertTriangle className="text-yellow-600" size={20} />
            <div>
              <h3 className="text-sm font-medium text-yellow-800">
                Atenção: {pendingCount} documento(s) pendente(s) de upload
              </h3>
              <p className="text-sm text-yellow-700 mt-1">
                Existem documentos aguardando envio pelos clientes ou pela equipe. Priorize o acompanhamento para evitar atrasos nos processos.
              </p>
            </div>
          </div>
        </div>
      )}

      {inAnalysisCount > 0 && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <Eye className="text-blue-600" size={20} />
            <div>
              <h3 className="text-sm font-medium text-blue-800">
                📋 {inAnalysisCount} documento(s) em análise para entrada de processo
              </h3>
              <p className="text-sm text-blue-700 mt-1">
                Documentos completos que estão sendo analisados pela equipe jurídica para dar entrada no processo.
              </p>
            </div>
          </div>
        </div>
      )}

      {notEffectivatedCount > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <AlertTriangle className="text-red-600" size={20} />
            <div>
              <h3 className="text-sm font-medium text-red-800">
                ⚠️ {notEffectivatedCount} documento(s) não resultaram em processo
              </h3>
              <p className="text-sm text-red-700 mt-1">
                Documentos completos que não resultaram em entrada de processo. Revisar motivos e melhorar qualificação.
              </p>
            </div>
          </div>
        </div>
      )}

      {expiredCount > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <AlertTriangle className="text-red-600" size={20} />
            <div>
              <h3 className="text-sm font-medium text-red-800">
                Alerta: {expiredCount} documento(s) expirado(s)
              </h3>
              <p className="text-sm text-red-700 mt-1">
                Alguns documentos passaram da data de validade. Solicite versões atualizadas aos clientes.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Filtros Expandidos */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <div className="flex items-center justify-between px-6 py-4">
            <nav className="flex space-x-8">
              <button
                onClick={() => setSelectedStatus('all')}
                className={`py-2 text-sm font-medium border-b-2 ${
                  selectedStatus === 'all'
                    ? 'text-blue-600 border-blue-600'
                    : 'text-gray-500 border-transparent hover:text-gray-700'
                }`}
              >
                Todos ({documents.length})
              </button>
              <button
                onClick={() => setSelectedStatus('pendente')}
                className={`py-2 text-sm font-medium border-b-2 ${
                  selectedStatus === 'pendente'
                    ? 'text-blue-600 border-blue-600'
                    : 'text-gray-500 border-transparent hover:text-gray-700'
                }`}
              >
                Pendentes ({pendingCount})
              </button>
              <button
                onClick={() => setSelectedStatus('completo')}
                className={`py-2 text-sm font-medium border-b-2 ${
                  selectedStatus === 'completo'
                    ? 'text-blue-600 border-blue-600'
                    : 'text-gray-500 border-transparent hover:text-gray-700'
                }`}
              >
                Completos ({completeCount})
              </button>
              <button
                onClick={() => setSelectedStatus('revisado')}
                className={`py-2 text-sm font-medium border-b-2 ${
                  selectedStatus === 'revisado'
                    ? 'text-blue-600 border-blue-600'
                    : 'text-gray-500 border-transparent hover:text-gray-700'
                }`}
              >
                Revisados ({reviewedCount})
              </button>
            </nav>

            <div className="flex items-center space-x-3">
              <select
                value={selectedPriority}
                onChange={(e) => setSelectedPriority(e.target.value as any)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">Todas as prioridades</option>
                <option value="critica">Crítica</option>
                <option value="alta">Alta</option>
                <option value="media">Média</option>
                <option value="baixa">Baixa</option>
              </select>

              <select
                value={selectedEffectiveness}
                onChange={(e) => setSelectedEffectiveness(e.target.value as any)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
              >
                <option value="all">Todas as efetivações</option>
                <option value="efetivado">Efetivados</option>
                <option value="em_analise">Em Análise</option>
                <option value="nao_efetivado">Não Efetivados</option>
                <option value="aguardando">Aguardando</option>
              </select>
              
              <button
                onClick={handleSelectAll}
                className="flex items-center space-x-2 px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                <input
                  type="checkbox"
                  checked={selectedDocuments.length === filteredDocuments.length && filteredDocuments.length > 0}
                  onChange={() => {}}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm">Selecionar Todos</span>
              </button>
            </div>
          </div>
        </div>

        <div className="p-6">
          <DataTable
            data={filteredDocuments}
            columns={documentColumns}
          />
        </div>
      </div>

      {/* Área de Upload Rápido */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Upload Rápido de Documentos</h3>
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors">
          <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <p className="text-sm text-gray-600 mb-2">
            Arraste e solte os arquivos aqui ou clique para selecionar
          </p>
          <p className="text-xs text-gray-500">
            Suporte para PDF, DOC, DOCX, JPG, PNG (máx. 10MB por arquivo)
          </p>
          <button className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            Selecionar Arquivos
          </button>
        </div>
      </div>

      {/* Quick Actions Expandidas */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Ações Rápidas</h3>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <button className="flex items-center justify-center space-x-2 px-4 py-3 border border-blue-300 text-blue-700 rounded-lg hover:bg-blue-50">
            <Plus size={20} />
            <span>Novo Documento</span>
          </button>
          <button className="flex items-center justify-center space-x-2 px-4 py-3 border border-green-300 text-green-700 rounded-lg hover:bg-green-50">
            <CheckCircle size={20} />
            <span>Aprovar Pendentes</span>
          </button>
          <button className="flex items-center justify-center space-x-2 px-4 py-3 border border-purple-300 text-purple-700 rounded-lg hover:bg-purple-50">
            <Target size={20} />
            <span>Analisar Efetivação</span>
          </button>
          <button className="flex items-center justify-center space-x-2 px-4 py-3 border border-orange-300 text-orange-700 rounded-lg hover:bg-orange-50">
            <TrendingUp size={20} />
            <span>Relatório Efetivação</span>
          </button>
          <button className="flex items-center justify-center space-x-2 px-4 py-3 border border-red-300 text-red-700 rounded-lg hover:bg-red-50">
            <Calendar size={20} />
            <span>Verificar Expirados</span>
          </button>
        </div>
      </div>

      {/* Document Edit Modal */}
      {editingDocument && (
        <DocumentEditForm
          document={editingDocument}
          onSave={handleSaveDocument}
          onClose={() => setEditingDocument(null)}
        />
      )}
    </div>
  );
};

export default Documents;