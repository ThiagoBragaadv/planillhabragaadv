import React, { createContext, useContext, useState, ReactNode } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'gestor' | 'vendedor' | 'advogado' | 'assistente_juridico' | 'assistente_administrativo' | 'coordenador_vendas' | 'analista_processos';
  department: 'vendas' | 'juridico' | 'administrativo';
  permissions: string[];
}

interface AuthContextType {
  currentUser: User | null;
  hasPermission: (permission: string) => boolean;
  canViewRevenue: () => boolean;
  isAdmin: () => boolean;
  login: (user: User) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  // Simulating logged in admin user - in real app this would come from authentication
  const [currentUser, setCurrentUser] = useState<User | null>({
    id: '1',
    name: 'Carlos Braga',
    email: 'carlos@braga.adv.br',
    role: 'admin',
    department: 'administrativo',
    permissions: [
      'view_dashboard',
      'manage_leads',
      'manage_contracts',
      'manage_processes',
      'view_documents',
      'upload_documents',
      'view_reports',
      'export_data',
      'manage_team',
      'system_settings',
      'view_revenue',
      'view_financial_data'
    ]
  });

  const hasPermission = (permission: string): boolean => {
    return currentUser?.permissions.includes(permission) || false;
  };

  const canViewRevenue = (): boolean => {
    return currentUser?.role === 'admin' && hasPermission('view_revenue');
  };

  const isAdmin = (): boolean => {
    return currentUser?.role === 'admin';
  };

  const login = (user: User) => {
    setCurrentUser(user);
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const value: AuthContextType = {
    currentUser,
    hasPermission,
    canViewRevenue,
    isAdmin,
    login,
    logout
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};